"""Trust-domain bootstrap and root-authority issuance operations."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from .canonical import dumps
from .container import Signer, parse_artifact
from .errors import FileSafetyError, TrustError
from .files import read_bytes_limited
from .identifiers import (
    derive_evidence_id,
    format_k1_allocation_number,
    new_rid,
    new_trust_domain_id,
    new_uuid7_urn,
)
from .kos_profile import validate_kos_entity_profile
from .lineage import issue_successor
from .manifest import create_draft, issue_genesis, load_draft, write_artifact
from .models import ExternalIdentifierBinding, ManifestDraft, Revision, SignatureMetadata
from .policy import evaluate_revision_policy
from .registry import Registry
from .relationships import required_relationship_scope
from .revocation import (
    RevocationSet,
    RevocationTargetType,
    VerifiedRevocation,
    create_revocation_statement,
    sign_revocation,
    verify_revocation,
    write_revocation,
)
from .timeutil import now_utc
from .trust import (
    KeyDelegation,
    TrustAnchor,
    TrustBundle,
    encode_delegation,
    encode_public_key,
    load_trust_bundle,
    write_trust_bundle,
)
from .vault import decrypt_key, encrypt_key, generate_key, read_key_file, write_key_file
from .verification import VerificationReport, verify_artifact

ROOT_KEY_RELATIVE_PATH = Path("keys/root.idmk")
ISSUANCE_KEY_RELATIVE_PATH = Path("keys/issuance.idmk")
ALLOCATION_KEY_RELATIVE_PATH = Path("keys/allocation.idmk")
REVOCATION_KEY_RELATIVE_PATH = Path("keys/revocation.idmk")
REGISTRY_KEY_RELATIVE_PATH = Path("keys/registry.idmk")
TRUST_BUNDLE_FILENAME = "trust-bundle.json"
AUTHORITY_ARTIFACT_FILENAME = "authority.idm"
ALLOCATION_REGISTRY_FILENAME = "allocation-registry.db"


@dataclass(frozen=True, slots=True)
class AuthorityInitialization:
    directory: Path
    trust_domain_id: str
    authority_eid: str
    authority_mid: str
    authority_vid: str
    root_kid: str


@dataclass(frozen=True, slots=True)
class AuthorityPassphrases:
    root: str
    issuance: str
    allocation: str
    revocation: str
    registry: str

    def validate_separation(self) -> None:
        values = {
            self.root,
            self.issuance,
            self.allocation,
            self.revocation,
            self.registry,
        }
        if len(values) != 5:
            raise TrustError("separated authority custody requires five distinct passphrases")


def _allocation_intent_id(draft_or_revision: ManifestDraft | Revision) -> str:
    """Hash every caller-controlled genesis field, excluding allocated identifiers."""

    entity = draft_or_revision.entity.model_copy(update={"external_identifiers": []})
    origin = draft_or_revision.origin
    payload = {
        "schema": "idm-kos-allocation-intent-v1",
        "schema_version": draft_or_revision.schema_version,
        "manifest_id": draft_or_revision.manifest_id,
        "entity_id": draft_or_revision.entity_id,
        "entity": entity.model_dump(mode="python"),
        "keys": [item.model_dump(mode="python") for item in draft_or_revision.keys],
        "origin": {
            "originator_eid": origin.originator_eid,
            "originator_mid": origin.originator_mid,
            "enrollment_profile": origin.enrollment_profile,
        },
        "relationships": draft_or_revision.relationships.model_dump(mode="python"),
        "authority": draft_or_revision.authority.model_dump(mode="python"),
        "capabilities": draft_or_revision.capabilities.model_dump(mode="python"),
        "extensions": draft_or_revision.extensions,
    }
    return derive_evidence_id(b"idm-kos-allocation-intent-v1\0" + dumps(payload))


def _root_anchor(*, kid: str, public_key: bytes, eid: str, mid: str, timestamp: str) -> TrustAnchor:
    return TrustAnchor(
        kid=kid,
        public_key=encode_public_key(public_key),
        signer_eid=eid,
        signer_mid=mid,
        roles=["root_authority", "identity_authority"],
        scopes=["identity.issue", "trust.delegate"],
        valid_from=timestamp,
    )


def _delegation(
    *,
    root_kid: str,
    root_eid: str,
    root_mid: str,
    delegated_kid: str,
    delegated_public_key: bytes,
    roles: list[str],
    scopes: list[str],
    timestamp: str,
) -> KeyDelegation:
    return KeyDelegation(
        delegation_id=new_rid(),
        issuer_eid=root_eid,
        issuer_mid=root_mid,
        issuer_kid=root_kid,
        delegated_kid=delegated_kid,
        delegated_public_key=encode_public_key(delegated_public_key),
        signer_eid=root_eid,
        signer_mid=root_mid,
        roles=roles,
        scopes=scopes,
        valid_from=timestamp,
        issued_at=timestamp,
    )


def initialize_authority(
    directory: Path,
    *,
    canonical_name: str,
    passphrase: str | None = None,
    passphrases: AuthorityPassphrases | None = None,
    timestamp: str | None = None,
) -> AuthorityInitialization:
    if (passphrase is None) == (passphrases is None):
        raise TrustError("provide either one legacy passphrase or separated role passphrases")
    if passphrases is None:
        assert passphrase is not None
        role_passphrases = AuthorityPassphrases(
            root=passphrase,
            issuance=passphrase,
            allocation=passphrase,
            revocation=passphrase,
            registry=passphrase,
        )
    else:
        passphrases.validate_separation()
        role_passphrases = passphrases
    issued_at = timestamp or now_utc()
    root_key = generate_key()
    issuance_key = generate_key()
    allocation_key = generate_key()
    revocation_key = generate_key()
    registry_key = generate_key()
    encrypted_root_key = encrypt_key(root_key, role_passphrases.root)
    encrypted_issuance_key = encrypt_key(issuance_key, role_passphrases.issuance)
    encrypted_allocation_key = encrypt_key(allocation_key, role_passphrases.allocation)
    encrypted_revocation_key = encrypt_key(revocation_key, role_passphrases.revocation)
    encrypted_registry_key = encrypt_key(registry_key, role_passphrases.registry)
    authority_draft = create_draft(
        entity_type="identity_authority",
        canonical_name=canonical_name,
        enrollment_profile="komistry-root-authority-v1",
    )
    anchor = _root_anchor(
        kid=root_key.kid,
        public_key=root_key.public_key,
        eid=authority_draft.entity_id,
        mid=authority_draft.manifest_id,
        timestamp=issued_at,
    )
    delegations = [
        _delegation(
            root_kid=root_key.kid,
            root_eid=authority_draft.entity_id,
            root_mid=authority_draft.manifest_id,
            delegated_kid=issuance_key.kid,
            delegated_public_key=issuance_key.public_key,
            roles=["identity_authority"],
            scopes=[
                "identity.issue",
                "identity.core.change",
                "manifest.revise",
                "relationship.manage",
                "relationship.ownership",
                "relationship.provenance",
                "relationship.governance",
                "relationship.stewardship",
                "relationship.supervision",
                "relationship.affiliation",
                "relationship.operations",
                "relationship.custody",
                "relationship.hosting",
                "relationship.authorization",
                "relationship.dependency",
                "capability.declare",
                "capability.grant",
                "lifecycle.change",
                "policy.manage",
                "protected.write",
            ],
            timestamp=issued_at,
        ),
        _delegation(
            root_kid=root_key.kid,
            root_eid=authority_draft.entity_id,
            root_mid=authority_draft.manifest_id,
            delegated_kid=allocation_key.kid,
            delegated_public_key=allocation_key.public_key,
            roles=["identity_authority"],
            scopes=["identity.issue", "identity.allocate"],
            timestamp=issued_at,
        ),
        _delegation(
            root_kid=root_key.kid,
            root_eid=authority_draft.entity_id,
            root_mid=authority_draft.manifest_id,
            delegated_kid=revocation_key.kid,
            delegated_public_key=revocation_key.public_key,
            roles=["identity_authority"],
            scopes=["revocation.issue"],
            timestamp=issued_at,
        ),
        _delegation(
            root_kid=root_key.kid,
            root_eid=authority_draft.entity_id,
            root_mid=authority_draft.manifest_id,
            delegated_kid=registry_key.kid,
            delegated_public_key=registry_key.public_key,
            roles=["registry_authority"],
            scopes=["registry.snapshot", "audit.sign"],
            timestamp=issued_at,
        ),
    ]
    bundle = TrustBundle(
        trust_domain_id=new_trust_domain_id(),
        generated_at=issued_at,
        anchors=[anchor],
        delegations=[
            encode_delegation(
                delegation,
                root_private_key=root_key.private_key,
                root_kid=root_key.kid,
            )
            for delegation in delegations
        ],
    )
    artifact = issue_genesis(
        authority_draft,
        private_key=root_key.private_key,
        kid=root_key.kid,
        signer_eid=authority_draft.entity_id,
        signer_mid=authority_draft.manifest_id,
        issued_at=issued_at,
        scope=["identity.issue"],
        policy_ref="komistry-root-bootstrap-v1",
    )
    report = verify_artifact(artifact, bundle)
    if not report.trusted or report.vid is None:
        raise TrustError("refusing to persist a root authority that does not self-verify")

    directory = directory.resolve()
    try:
        os.mkdir(directory, 0o700)
    except FileExistsError as exc:
        raise FileSafetyError(f"refusing to initialize existing directory {directory}") from exc
    except OSError as exc:
        raise FileSafetyError(f"cannot create authority directory {directory}") from exc

    write_key_file(directory / ROOT_KEY_RELATIVE_PATH, encrypted_root_key)
    write_key_file(directory / ISSUANCE_KEY_RELATIVE_PATH, encrypted_issuance_key)
    write_key_file(directory / ALLOCATION_KEY_RELATIVE_PATH, encrypted_allocation_key)
    write_key_file(directory / REVOCATION_KEY_RELATIVE_PATH, encrypted_revocation_key)
    write_key_file(directory / REGISTRY_KEY_RELATIVE_PATH, encrypted_registry_key)
    write_trust_bundle(directory / TRUST_BUNDLE_FILENAME, bundle)
    write_artifact(directory / AUTHORITY_ARTIFACT_FILENAME, artifact)
    with Registry(directory / ALLOCATION_REGISTRY_FILENAME) as registry:
        registry.add(artifact, bundle)
    return AuthorityInitialization(
        directory=directory,
        trust_domain_id=bundle.trust_domain_id,
        authority_eid=authority_draft.entity_id,
        authority_mid=authority_draft.manifest_id,
        authority_vid=report.vid,
        root_kid=root_key.kid,
    )


def issue_from_authority(
    draft_path: Path,
    authority_directory: Path,
    *,
    passphrase: str,
    output_path: Path,
    timestamp: str | None = None,
    revocations: RevocationSet | None = None,
    allocate_kos: bool = False,
) -> VerificationReport:
    bundle = load_trust_bundle(authority_directory / TRUST_BUNDLE_FILENAME)
    if len(bundle.anchors) != 1:
        raise TrustError("gate-1 issuance requires exactly one configured root anchor")
    draft = load_draft(draft_path)
    if draft.entity.external_identifiers:
        raise TrustError(
            "authority convenience issuance rejects caller-supplied external identifiers"
        )
    needs_allocation_scope = allocate_kos
    key_path = (
        ALLOCATION_KEY_RELATIVE_PATH if needs_allocation_scope else ISSUANCE_KEY_RELATIVE_PATH
    )
    key = decrypt_key(read_key_file(authority_directory / key_path), passphrase)
    delegated = bundle.find_anchor(key.kid)
    if delegated is None or "identity.issue" not in delegated.scopes:
        raise TrustError("authority issuance key lacks a valid root delegation")
    issued_at = timestamp or now_utc()
    registry_path = authority_directory / ALLOCATION_REGISTRY_FILENAME
    if allocate_kos:
        with Registry(registry_path) as registry:
            committed = registry.latest_artifact(eid=draft.entity_id)
            if committed is not None:
                recovered = parse_artifact(committed)
                if recovered.revision.revision != 1 or _allocation_intent_id(
                    recovered.revision
                ) != _allocation_intent_id(draft):
                    raise TrustError(
                        "registry contains a conflicting identity for the allocation draft"
                    )
                binding = validate_kos_entity_profile(recovered.revision.entity)
                if binding is None:
                    raise TrustError("committed identity has no KOS UUIDv7/K1 allocation pair")
                integrity_errors = registry.verify(bundle, evaluation_time=issued_at)
                if integrity_errors:
                    raise TrustError(
                        f"committed allocation registry failed integrity audit: {integrity_errors}"
                    )
                event = registry.connection.execute(
                    """
                    SELECT canonical_id, allocation_number, subject_eid, subject_mid, first_vid
                    FROM allocation_events WHERE rid = ?
                    """,
                    (binding.canonical.allocation_event_id,),
                ).fetchone()
                expected_event = (
                    binding.canonical.value,
                    binding.allocation.value,
                    recovered.revision.entity_id,
                    recovered.revision.manifest_id,
                    recovered.vid,
                )
                if event is None or tuple(event) != expected_event:
                    raise TrustError("committed identity lacks its exact allocation-ledger event")
                recovered_report = verify_artifact(
                    committed,
                    bundle,
                    revocations=revocations,
                    evaluation_time=issued_at,
                )
                if not recovered_report.trusted:
                    raise TrustError(
                        "committed allocation cannot be recovered under current trust state"
                    )
                write_artifact(output_path, committed)
                return recovered_report
            allocation_number = format_k1_allocation_number(registry.next_k1_ordinal())
        allocation_rid = new_rid()
        bindings = [
            ExternalIdentifierBinding(
                scheme="kos-canonical-id",
                value=new_uuid7_urn(),
                allocation_event_id=allocation_rid,
                allocation_authority_eid=delegated.signer_eid,
                allocation_authority_mid=delegated.signer_mid,
            ),
            ExternalIdentifierBinding(
                scheme="kos-allocation-number",
                value=allocation_number,
                allocation_event_id=allocation_rid,
                allocation_authority_eid=delegated.signer_eid,
                allocation_authority_mid=delegated.signer_mid,
            ),
        ]
        draft = draft.model_copy(
            update={"entity": draft.entity.model_copy(update={"external_identifiers": bindings})}
        )
    scopes = ["identity.issue"]
    if draft.relationships.authoritative or draft.relationships.references:
        scopes.append("relationship.manage")
        scopes.extend(
            required_relationship_scope(item.type) for item in draft.relationships.authoritative
        )
        scopes.extend(
            required_relationship_scope(item.local_role) for item in draft.relationships.references
        )
        scopes = list(dict.fromkeys(scopes))
    if draft.capabilities.declared:
        scopes.append("capability.declare")
    if draft.capabilities.grants or draft.capabilities.denials:
        scopes.append("capability.grant")
    if draft.extensions:
        scopes.append("manifest.revise")
    if allocate_kos:
        scopes.append("identity.allocate")
    if not set(scopes).issubset(delegated.scopes):
        raise TrustError("authority issuance key lacks a scope required by the draft")
    artifact = issue_genesis(
        draft,
        private_key=key.private_key,
        kid=key.kid,
        signer_eid=delegated.signer_eid,
        signer_mid=delegated.signer_mid,
        issued_at=issued_at,
        scope=scopes,
        policy_ref=(
            "komistry-kos-allocation-v1"
            if needs_allocation_scope
            else "komistry-institutional-issuance-v1"
        ),
    )
    report = verify_artifact(
        artifact,
        bundle,
        revocations=revocations,
        evaluation_time=issued_at,
    )
    decision = evaluate_revision_policy(None, parse_artifact(artifact), report)
    if not report.trusted or not decision.allowed:
        raise TrustError(
            "refusing to write an artifact that failed trust or policy: "
            f"trust={report.errors}; policy={decision.errors}"
        )
    with Registry(registry_path) as registry:
        registry.add(
            artifact,
            bundle,
            revocations=revocations,
            evaluation_time=issued_at,
        )
    write_artifact(output_path, artifact)
    return report


def verify_artifact_file(path: Path, bundle_path: Path) -> VerificationReport:
    artifact = read_bytes_limited(path, max_bytes=1024 * 1024)
    return verify_artifact(artifact, load_trust_bundle(bundle_path))


def create_revocation_from_authority(
    authority_directory: Path,
    *,
    passphrase: str,
    target_type: RevocationTargetType,
    target_id: str,
    reason_code: str,
    output_path: Path,
    effective_at: str | None = None,
    timestamp: str | None = None,
    replacement_ref: str | None = None,
    revocations: RevocationSet | None = None,
) -> VerifiedRevocation:
    bundle = load_trust_bundle(authority_directory / TRUST_BUNDLE_FILENAME)
    key = decrypt_key(read_key_file(authority_directory / REVOCATION_KEY_RELATIVE_PATH), passphrase)
    delegated = bundle.find_anchor(key.kid)
    if delegated is None or "revocation.issue" not in delegated.scopes:
        raise TrustError("authority revocation key lacks a valid root delegation")
    issued_at = timestamp or now_utc()
    if revocations is not None:
        revoked_targets = [
            (RevocationTargetType.KEY, key.kid),
            *(
                [(RevocationTargetType.DELEGATION, delegated.delegation_id)]
                if delegated.delegation_id is not None
                else []
            ),
        ]
        if any(
            revocations.matches(target_type, target_id, at_time=issued_at)
            for target_type, target_id in revoked_targets
        ):
            raise TrustError("authority revocation key or delegation is revoked")
    statement = create_revocation_statement(
        target_type=target_type,
        target_id=target_id,
        reason_code=reason_code,
        effective_at=effective_at or issued_at,
        issued_at=issued_at,
        issuer_eid=delegated.signer_eid,
        issuer_mid=delegated.signer_mid,
        replacement_ref=replacement_ref,
    )
    data = sign_revocation(statement, private_key=key.private_key, kid=key.kid)
    verified = verify_revocation(data, bundle)
    write_revocation(output_path, data)
    return verified


def sign_successor_from_authority(
    predecessor_bytes: bytes,
    successor: Revision,
    authority_directory: Path,
    *,
    passphrase: str,
    required_scopes: list[str],
    output_path: Path,
    revocations: RevocationSet | None = None,
) -> VerificationReport:
    bundle = load_trust_bundle(authority_directory / TRUST_BUNDLE_FILENAME)
    key = decrypt_key(read_key_file(authority_directory / ISSUANCE_KEY_RELATIVE_PATH), passphrase)
    delegated = bundle.find_anchor(key.kid)
    if delegated is None:
        raise TrustError("authority revision key lacks a valid root delegation")
    scopes = ["manifest.revise", *required_scopes]
    if not set(scopes).issubset(delegated.scopes):
        raise TrustError("authority revision key lacks one or more required scopes")
    signer = Signer(
        private_key=key.private_key,
        kid=key.kid,
        metadata=SignatureMetadata(
            signer_eid=delegated.signer_eid,
            signer_mid=delegated.signer_mid,
            role="identity_authority",
            scope=scopes,
            signed_at=successor.issued_at,
            policy_ref="komistry-policy-v1",
        ),
    )
    artifact = issue_successor(predecessor_bytes, successor, [signer])
    report = verify_artifact(
        artifact,
        bundle,
        revocations=revocations,
        evaluation_time=successor.issued_at,
    )
    decision = evaluate_revision_policy(
        parse_artifact(predecessor_bytes), parse_artifact(artifact), report
    )
    if not report.trusted or not decision.allowed:
        raise TrustError(
            "refusing to write successor that failed trust or policy: "
            f"trust={report.errors}; policy={decision.errors}"
        )
    with Registry(authority_directory / ALLOCATION_REGISTRY_FILENAME) as registry:
        registry.add(
            artifact,
            bundle,
            revocations=revocations,
            evaluation_time=successor.issued_at,
        )
    write_artifact(output_path, artifact)
    return report
