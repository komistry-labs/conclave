"""Wrappers around audited cryptographic library primitives."""

from __future__ import annotations

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    NoEncryption,
    PrivateFormat,
    PublicFormat,
)

from .errors import SignatureError


def generate_ed25519_private_key() -> bytes:
    key = Ed25519PrivateKey.generate()
    return key.private_bytes(Encoding.Raw, PrivateFormat.Raw, NoEncryption())


def public_key_from_private(private_key_bytes: bytes) -> bytes:
    try:
        key = Ed25519PrivateKey.from_private_bytes(private_key_bytes)
    except ValueError as exc:
        raise SignatureError("invalid Ed25519 private key") from exc
    return key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)


def sign(private_key_bytes: bytes, message: bytes) -> bytes:
    try:
        key = Ed25519PrivateKey.from_private_bytes(private_key_bytes)
    except ValueError as exc:
        raise SignatureError("invalid Ed25519 private key") from exc
    return key.sign(message)


def verify(public_key_bytes: bytes, signature: bytes, message: bytes) -> None:
    try:
        key = Ed25519PublicKey.from_public_bytes(public_key_bytes)
        key.verify(signature, message)
    except (ValueError, InvalidSignature) as exc:
        raise SignatureError("Ed25519 signature verification failed") from exc
