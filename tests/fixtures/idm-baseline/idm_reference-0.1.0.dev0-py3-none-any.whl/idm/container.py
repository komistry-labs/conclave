"""Strict IDM profile over RFC 9052 COSE_Sign."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import cbor2
from pydantic import ValidationError

from . import canonical
from .crypto import sign as ed25519_sign
from .crypto import verify as ed25519_verify
from .errors import CanonicalEncodingError, ManifestSchemaError, SignatureError
from .identifiers import derive_vid, validate_kid
from .models import Revision, SignatureMetadata

COSE_SIGN_TAG = 98
COSE_ALG = 1
COSE_CONTENT_TYPE = 3
COSE_KID = 4
COSE_EDDSA = -8
CONTENT_TYPE = "application/idm+cbor"
IDM_FORMAT = 1
IDM_CONTEXT = "idm/v1/revision"
MAX_SIGNATURES = 8
CBOR_ARRAY_TYPES = (list, tuple)

_BODY_KEYS: set[int | str] = {COSE_CONTENT_TYPE, "idm_format", "idm_context"}
_SIGNATURE_KEYS: set[int | str] = {
    COSE_ALG,
    COSE_KID,
    "signer_eid",
    "signer_mid",
    "role",
    "scope",
    "signed_at",
    "policy_ref",
}


@dataclass(frozen=True, slots=True)
class Signer:
    private_key: bytes
    kid: str
    metadata: SignatureMetadata


@dataclass(frozen=True, slots=True)
class ParsedSignature:
    protected: bytes
    signature: bytes
    kid: str
    metadata: SignatureMetadata


@dataclass(frozen=True, slots=True)
class ParsedArtifact:
    exact_bytes: bytes
    vid: str
    body_protected: bytes
    payload_bytes: bytes
    revision: Revision
    signatures: tuple[ParsedSignature, ...]


def _body_protected() -> bytes:
    return canonical.dumps(
        {
            COSE_CONTENT_TYPE: CONTENT_TYPE,
            "idm_format": IDM_FORMAT,
            "idm_context": IDM_CONTEXT,
        }
    )


def _signature_protected(signer: Signer) -> bytes:
    validate_kid(signer.kid)
    metadata = signer.metadata
    return canonical.dumps(
        {
            COSE_ALG: COSE_EDDSA,
            COSE_KID: signer.kid.encode("ascii"),
            "signer_eid": metadata.signer_eid,
            "signer_mid": metadata.signer_mid,
            "role": metadata.role,
            "scope": metadata.scope,
            "signed_at": metadata.signed_at,
            "policy_ref": metadata.policy_ref,
        }
    )


def _sig_structure(body_protected: bytes, sign_protected: bytes, payload: bytes) -> bytes:
    return canonical.dumps(["Signature", body_protected, sign_protected, b"", payload])


def encode_signed_revision(revision: Revision, signers: list[Signer]) -> bytes:
    if not signers or len(signers) > MAX_SIGNATURES:
        raise SignatureError(f"IDM artifacts require 1 to {MAX_SIGNATURES} signatures")
    payload_obj = revision.model_dump(mode="python")
    canonical.validate_profile(payload_obj)
    payload = canonical.dumps(payload_obj)
    body_protected = _body_protected()

    entries: list[tuple[tuple[bytes, bytes, bytes], list[Any]]] = []
    for signer in signers:
        sign_protected = _signature_protected(signer)
        signature = ed25519_sign(
            signer.private_key, _sig_structure(body_protected, sign_protected, payload)
        )
        sort_key = (
            signer.metadata.signer_eid.encode("utf-8"),
            signer.metadata.role.encode("utf-8"),
            signer.kid.encode("ascii"),
        )
        entries.append((sort_key, [sign_protected, {}, signature]))

    entries.sort(key=lambda item: item[0])
    structure = cbor2.CBORTag(
        COSE_SIGN_TAG,
        [body_protected, {}, payload, [entry for _, entry in entries]],
    )
    canonical.validate_profile(structure, allow_tags={COSE_SIGN_TAG}, allow_integer_keys=True)
    return canonical.dumps(structure)


def _decode_protected(data: bytes, *, expected_keys: set[int | str]) -> dict[int | str, Any]:
    value = canonical.load_canonical(data, allow_integer_keys=True, max_bytes=64 * 1024)
    if not isinstance(value, dict) or set(value) != expected_keys:
        raise SignatureError("protected header set is not the IDM v1 profile")
    return value


def parse_artifact(data: bytes) -> ParsedArtifact:
    top = canonical.load_canonical(
        data,
        allow_tags={COSE_SIGN_TAG},
        allow_integer_keys=True,
        max_bytes=canonical.MAX_ARTIFACT_BYTES,
    )
    if not isinstance(top, cbor2.CBORTag) or top.tag != COSE_SIGN_TAG:
        raise SignatureError("artifact is not a tagged COSE_Sign structure")
    if not isinstance(top.value, CBOR_ARRAY_TYPES) or len(top.value) != 4:
        raise SignatureError("malformed COSE_Sign structure")
    body_protected, body_unprotected, payload, signature_values = top.value
    if not isinstance(body_protected, bytes) or body_unprotected != {}:
        raise SignatureError("IDM v1 requires protected body headers and no unprotected headers")
    body_headers = _decode_protected(body_protected, expected_keys=_BODY_KEYS)
    if (
        body_headers[COSE_CONTENT_TYPE] != CONTENT_TYPE
        or body_headers["idm_format"] != IDM_FORMAT
        or body_headers["idm_context"] != IDM_CONTEXT
    ):
        raise SignatureError("unsupported IDM body profile")
    if not isinstance(payload, bytes):
        raise SignatureError("detached payloads are not allowed")
    payload_obj = canonical.load_canonical(payload)
    if not isinstance(payload_obj, dict):
        raise ManifestSchemaError("revision payload must be a map")
    try:
        revision = Revision.model_validate(payload_obj)
    except ValidationError as exc:
        raise ManifestSchemaError("revision payload failed schema validation") from exc
    if (
        not isinstance(signature_values, CBOR_ARRAY_TYPES)
        or not 1 <= len(signature_values) <= MAX_SIGNATURES
    ):
        raise SignatureError(f"artifact must contain 1 to {MAX_SIGNATURES} signatures")

    parsed: list[ParsedSignature] = []
    observed_sort_keys: list[tuple[bytes, bytes, bytes]] = []
    for value in signature_values:
        if not isinstance(value, CBOR_ARRAY_TYPES) or len(value) != 3:
            raise SignatureError("malformed COSE_Signature")
        sign_protected, sign_unprotected, signature = value
        if not isinstance(sign_protected, bytes) or sign_unprotected != {}:
            raise SignatureError("IDM v1 signatures cannot use unprotected headers")
        if not isinstance(signature, bytes) or len(signature) != 64:
            raise SignatureError("Ed25519 signature must be 64 bytes")
        headers = _decode_protected(sign_protected, expected_keys=_SIGNATURE_KEYS)
        if headers[COSE_ALG] != COSE_EDDSA or not isinstance(headers[COSE_KID], bytes):
            raise SignatureError("unsupported signature algorithm or KID type")
        try:
            kid = headers[COSE_KID].decode("ascii")
        except UnicodeDecodeError as exc:
            raise SignatureError("KID must contain ASCII") from exc
        validate_kid(kid)
        try:
            metadata = SignatureMetadata.model_validate(
                {
                    "signer_eid": headers["signer_eid"],
                    "signer_mid": headers["signer_mid"],
                    "role": headers["role"],
                    "scope": headers["scope"],
                    "signed_at": headers["signed_at"],
                    "policy_ref": headers["policy_ref"],
                }
            )
        except ValidationError as exc:
            raise SignatureError("signature metadata failed schema validation") from exc
        observed_sort_keys.append(
            (
                metadata.signer_eid.encode("utf-8"),
                metadata.role.encode("utf-8"),
                kid.encode("ascii"),
            )
        )
        parsed.append(
            ParsedSignature(
                protected=sign_protected,
                signature=signature,
                kid=kid,
                metadata=metadata,
            )
        )
    if observed_sort_keys != sorted(observed_sort_keys):
        raise SignatureError("signatures are not in deterministic order")
    if len(set(observed_sort_keys)) != len(observed_sort_keys):
        raise SignatureError("duplicate signature identity")

    return ParsedArtifact(
        exact_bytes=data,
        vid=derive_vid(data),
        body_protected=body_protected,
        payload_bytes=payload,
        revision=revision,
        signatures=tuple(parsed),
    )


def verify_parsed_signature(
    artifact: ParsedArtifact, signature: ParsedSignature, public_key: bytes
) -> None:
    try:
        ed25519_verify(
            public_key,
            signature.signature,
            _sig_structure(artifact.body_protected, signature.protected, artifact.payload_bytes),
        )
    except SignatureError:
        raise
    except CanonicalEncodingError as exc:
        raise SignatureError("could not reconstruct signature input") from exc
