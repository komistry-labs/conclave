"""Public subject-key bindings kept separate from private vault material."""

from __future__ import annotations

import base64

from .container import ParsedArtifact
from .errors import PolicyError
from .identifiers import derive_kid
from .lineage import build_successor
from .models import KeyPurpose, PublicKeyBinding, Revision


def create_public_key_binding(
    public_key: bytes,
    *,
    purposes: list[KeyPurpose],
    valid_from: str,
    valid_until: str | None = None,
) -> PublicKeyBinding:
    return PublicKeyBinding(
        kid=derive_kid(public_key),
        public_key=base64.b64encode(public_key).decode("ascii"),
        purposes=purposes,
        valid_from=valid_from,
        valid_until=valid_until,
    )


def decode_bound_public_key(binding: PublicKeyBinding) -> bytes:
    return base64.b64decode(binding.public_key, validate=True)


def rotate_public_key_revision(
    predecessor: ParsedArtifact,
    *,
    retiring_kid: str,
    replacement_public_key: bytes,
    purposes: list[KeyPurpose],
    issued_by_eid: str,
    issued_by_mid: str,
    timestamp: str,
) -> Revision:
    """Retire one public binding and append its governed replacement."""

    prior = predecessor.revision
    matches = [binding for binding in prior.keys if binding.kid == retiring_kid]
    if len(matches) != 1:
        raise PolicyError("retiring key must be uniquely bound in the current revision")
    replacement = create_public_key_binding(
        replacement_public_key,
        purposes=purposes,
        valid_from=timestamp,
    )
    if replacement.kid == retiring_kid or any(
        binding.kid == replacement.kid for binding in prior.keys
    ):
        raise PolicyError("replacement public key is already bound to the manifest")
    bindings: list[PublicKeyBinding] = []
    for binding in prior.keys:
        if binding.kid != retiring_kid:
            bindings.append(binding)
            continue
        if binding.valid_until is not None and binding.valid_until <= timestamp:
            raise PolicyError("retiring key is already outside its validity interval")
        values = binding.model_dump(mode="python")
        values["valid_until"] = timestamp
        bindings.append(PublicKeyBinding.model_validate(values))
    bindings.append(replacement)
    return build_successor(
        predecessor,
        issued_by_eid=issued_by_eid,
        issued_by_mid=issued_by_mid,
        issued_at=timestamp,
        updates={"keys": bindings},
    )
