"""Transactional SQLite index derived only from verified IDM evidence."""

from __future__ import annotations

import os
import sqlite3
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

from .canonical import MAX_ARTIFACT_BYTES, dumps
from .container import ParsedArtifact, parse_artifact
from .errors import GraphError, IDMError, LineageError, PolicyError, RegistryError
from .files import read_bytes_limited
from .identifiers import (
    derive_checkpoint_id,
    derive_root_fingerprint,
    derive_vid,
    validate_checkpoint_id,
)
from .kos_profile import kos_allocation_binding, validate_kos_entity_profile
from .lineage import validate_successor
from .models import Relationship
from .policy import evaluate_revision_policy
from .relationships import (
    CYCLE_CONTROLLED_RELATIONSHIPS,
    validate_revision_relationships,
)
from .revocation import RevocationSet
from .trust import TrustBundle
from .verification import verify_artifact

SCHEMA_VERSION = 4


@dataclass(frozen=True, slots=True)
class RegistryAddResult:
    vid: str
    entity_id: str
    manifest_id: str
    revision: int


@dataclass(frozen=True, slots=True)
class RegistryCheckpoint:
    trust_domain_id: str
    root_fingerprint: str
    schema_version: int
    allocation_high_water: int
    allocation_count: int
    artifact_count: int
    lineage_count: int
    digest: str


def _hierarchy_arc(relationship_type: str, source: str, target: str) -> tuple[str, str]:
    parent_to_child = {"owns", "governs", "stewards", "supervises", "has_member"}
    if relationship_type in parent_to_child:
        return source, target
    return target, source


class Registry:
    def __init__(self, path: Path) -> None:
        self.path = path.resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        new_file = not self.path.exists()
        self.connection = sqlite3.connect(self.path)
        self.connection.row_factory = sqlite3.Row
        self.connection.execute("PRAGMA foreign_keys = ON")
        self.connection.execute("PRAGMA journal_mode = WAL")
        self.connection.execute("PRAGMA synchronous = FULL")
        self._migrate()
        if new_file:
            os.chmod(self.path, 0o600)

    def __enter__(self) -> Registry:
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def close(self) -> None:
        self.connection.close()

    def _migrate(self) -> None:
        version = int(self.connection.execute("PRAGMA user_version").fetchone()[0])
        if version not in {0, 1, 2, 3, SCHEMA_VERSION}:
            raise RegistryError(f"unsupported registry schema version {version}")
        if version == SCHEMA_VERSION:
            return
        if version == 1:
            with self.connection:
                self.connection.execute(
                    "ALTER TABLE relationships ADD COLUMN edge_hash TEXT NOT NULL DEFAULT ''"
                )
                rows = self.connection.execute(
                    """
                    SELECT r.rid, a.artifact FROM relationships r
                    JOIN artifacts a ON a.vid = r.source_vid
                    """
                ).fetchall()
                for row in rows:
                    artifact = parse_artifact(bytes(row["artifact"]))
                    edges = [
                        edge
                        for edge in artifact.revision.relationships.authoritative
                        if edge.relationship_id == row["rid"]
                    ]
                    if len(edges) != 1:
                        raise RegistryError(
                            "cannot migrate relationship without exact signed evidence"
                        )
                    edge_hash = derive_vid(dumps(edges[0].model_dump(mode="python")))
                    self.connection.execute(
                        "UPDATE relationships SET edge_hash = ? WHERE rid = ?",
                        (edge_hash, row["rid"]),
                    )
                self.connection.execute("PRAGMA user_version = 2")
            version = 2
        if version == 2:
            with self.connection:
                self.connection.execute(
                    """
                    CREATE TABLE external_identifiers (
                        scheme TEXT NOT NULL,
                        value TEXT NOT NULL,
                        eid TEXT NOT NULL,
                        mid TEXT NOT NULL,
                        allocation_event_id TEXT NOT NULL,
                        allocation_authority_eid TEXT NOT NULL,
                        allocation_authority_mid TEXT NOT NULL,
                        first_vid TEXT NOT NULL,
                        PRIMARY KEY(scheme, value),
                        FOREIGN KEY(first_vid) REFERENCES artifacts(vid)
                    )
                    """
                )
                rows = self.connection.execute(
                    """
                    SELECT artifact FROM artifacts
                    ORDER BY revision, mid
                    """
                ).fetchall()
                for row in rows:
                    artifact = parse_artifact(bytes(row["artifact"]))
                    for binding in artifact.revision.entity.external_identifiers:
                        existing = self.connection.execute(
                            """
                            SELECT eid, mid FROM external_identifiers
                            WHERE scheme = ? AND value = ?
                            """,
                            (binding.scheme, binding.value),
                        ).fetchone()
                        if existing is not None:
                            if (
                                existing["eid"] != artifact.revision.entity_id
                                or existing["mid"] != artifact.revision.manifest_id
                            ):
                                raise RegistryError("cannot migrate a reused external identifier")
                            continue
                        self.connection.execute(
                            """
                            INSERT INTO external_identifiers(
                                scheme, value, eid, mid, allocation_event_id,
                                allocation_authority_eid, allocation_authority_mid, first_vid
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                            """,
                            (
                                binding.scheme,
                                binding.value,
                                artifact.revision.entity_id,
                                artifact.revision.manifest_id,
                                binding.allocation_event_id,
                                binding.allocation_authority_eid,
                                binding.allocation_authority_mid,
                                artifact.vid,
                            ),
                        )
                self.connection.execute("PRAGMA user_version = 3")
            version = 3
        if version == 3:
            try:
                self.connection.execute("BEGIN IMMEDIATE")
                for statement in (
                    """
                    CREATE TABLE registry_identity (
                        singleton INTEGER PRIMARY KEY CHECK(singleton = 1),
                        trust_domain_id TEXT NOT NULL,
                        root_fingerprint TEXT NOT NULL
                    )
                    """,
                    """
                    CREATE TABLE allocation_state (
                        singleton INTEGER PRIMARY KEY CHECK(singleton = 1),
                        high_water TEXT NOT NULL
                    )
                    """,
                    "INSERT INTO allocation_state(singleton, high_water) VALUES (1, '0')",
                    """
                    CREATE TABLE allocation_events (
                        rid TEXT PRIMARY KEY,
                        canonical_id TEXT NOT NULL UNIQUE,
                        allocation_number TEXT NOT NULL UNIQUE,
                        ordinal TEXT NOT NULL UNIQUE,
                        subject_eid TEXT NOT NULL,
                        subject_mid TEXT NOT NULL,
                        authority_eid TEXT NOT NULL,
                        authority_mid TEXT NOT NULL,
                        allocated_at TEXT NOT NULL,
                        first_vid TEXT NOT NULL UNIQUE,
                        FOREIGN KEY(first_vid) REFERENCES artifacts(vid)
                    )
                    """,
                ):
                    self.connection.execute(statement)
                events: dict[str, tuple[str, ...]] = {}
                rows = self.connection.execute(
                    "SELECT artifact FROM artifacts ORDER BY revision, mid"
                ).fetchall()
                for row in rows:
                    artifact = parse_artifact(bytes(row["artifact"]))
                    kos_binding = validate_kos_entity_profile(artifact.revision.entity)
                    if kos_binding is None:
                        continue
                    event = (
                        kos_binding.canonical.value,
                        kos_binding.allocation.value,
                        str(kos_binding.ordinal),
                        artifact.revision.entity_id,
                        artifact.revision.manifest_id,
                        kos_binding.canonical.allocation_authority_eid,
                        kos_binding.canonical.allocation_authority_mid,
                    )
                    existing = events.get(kos_binding.canonical.allocation_event_id)
                    if existing is not None and existing[:7] != event:
                        raise RegistryError("cannot migrate a reused KOS allocation RID")
                    events.setdefault(
                        kos_binding.canonical.allocation_event_id,
                        (*event, artifact.revision.issued_at, artifact.vid),
                    )
                ordered_events = sorted(events.items(), key=lambda item: int(item[1][2]))
                for expected, (rid, event_values) in enumerate(ordered_events, start=1):
                    if int(event_values[2]) != expected:
                        raise RegistryError(
                            "cannot migrate a non-contiguous K1 allocation sequence"
                        )
                    self.connection.execute(
                        """
                        INSERT INTO allocation_events(
                            rid, canonical_id, allocation_number, ordinal,
                            subject_eid, subject_mid, authority_eid, authority_mid,
                            allocated_at, first_vid
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (rid, *event_values),
                    )
                self.connection.execute(
                    "UPDATE allocation_state SET high_water = ? WHERE singleton = 1",
                    (str(len(ordered_events)),),
                )
                self.connection.execute("PRAGMA user_version = 4")
                self.connection.commit()
            except (sqlite3.Error, RegistryError, IDMError):
                self.connection.rollback()
                raise
            return
        with self.connection:
            self.connection.executescript(
                """
                CREATE TABLE artifacts (
                    vid TEXT PRIMARY KEY,
                    eid TEXT NOT NULL,
                    mid TEXT NOT NULL,
                    revision INTEGER NOT NULL,
                    predecessor_vid TEXT,
                    issued_at TEXT NOT NULL,
                    entity_type TEXT NOT NULL,
                    lifecycle_state TEXT NOT NULL,
                    artifact BLOB NOT NULL,
                    UNIQUE(mid, revision),
                    FOREIGN KEY(predecessor_vid) REFERENCES artifacts(vid)
                );
                CREATE INDEX artifacts_eid ON artifacts(eid);
                CREATE INDEX artifacts_mid ON artifacts(mid);
                CREATE TABLE heads (
                    mid TEXT PRIMARY KEY,
                    eid TEXT NOT NULL UNIQUE,
                    vid TEXT NOT NULL UNIQUE,
                    FOREIGN KEY(vid) REFERENCES artifacts(vid)
                );
                CREATE TABLE relationships (
                    rid TEXT PRIMARY KEY,
                    source_eid TEXT NOT NULL,
                    source_mid TEXT NOT NULL,
                    source_vid TEXT NOT NULL,
                    relationship_type TEXT NOT NULL,
                    target_eid TEXT NOT NULL,
                    target_mid TEXT NOT NULL,
                    effective_from TEXT NOT NULL,
                    effective_until TEXT,
                    status TEXT NOT NULL,
                    edge_hash TEXT NOT NULL,
                    FOREIGN KEY(source_vid) REFERENCES artifacts(vid)
                );
                CREATE INDEX relationships_source ON relationships(source_eid);
                CREATE INDEX relationships_target ON relationships(target_eid);
                CREATE TABLE relationship_references (
                    rid TEXT NOT NULL,
                    target_eid TEXT NOT NULL,
                    target_mid TEXT NOT NULL,
                    target_vid TEXT NOT NULL,
                    authoritative_mid TEXT NOT NULL,
                    authoritative_vid TEXT,
                    local_role TEXT NOT NULL,
                    PRIMARY KEY(rid, target_mid),
                    FOREIGN KEY(target_vid) REFERENCES artifacts(vid)
                );
                CREATE INDEX references_authority ON relationship_references(authoritative_mid);
                CREATE TABLE external_identifiers (
                    scheme TEXT NOT NULL,
                    value TEXT NOT NULL,
                    eid TEXT NOT NULL,
                    mid TEXT NOT NULL,
                    allocation_event_id TEXT NOT NULL,
                    allocation_authority_eid TEXT NOT NULL,
                    allocation_authority_mid TEXT NOT NULL,
                    first_vid TEXT NOT NULL,
                    PRIMARY KEY(scheme, value),
                    FOREIGN KEY(first_vid) REFERENCES artifacts(vid)
                );
                CREATE TABLE registry_identity (
                    singleton INTEGER PRIMARY KEY CHECK(singleton = 1),
                    trust_domain_id TEXT NOT NULL,
                    root_fingerprint TEXT NOT NULL
                );
                CREATE TABLE allocation_state (
                    singleton INTEGER PRIMARY KEY CHECK(singleton = 1),
                    high_water TEXT NOT NULL
                );
                INSERT INTO allocation_state(singleton, high_water) VALUES (1, '0');
                CREATE TABLE allocation_events (
                    rid TEXT PRIMARY KEY,
                    canonical_id TEXT NOT NULL UNIQUE,
                    allocation_number TEXT NOT NULL UNIQUE,
                    ordinal TEXT NOT NULL UNIQUE,
                    subject_eid TEXT NOT NULL,
                    subject_mid TEXT NOT NULL,
                    authority_eid TEXT NOT NULL,
                    authority_mid TEXT NOT NULL,
                    allocated_at TEXT NOT NULL,
                    first_vid TEXT NOT NULL UNIQUE,
                    FOREIGN KEY(first_vid) REFERENCES artifacts(vid)
                );
                PRAGMA user_version = 4;
                """
            )

    @staticmethod
    def _root_fingerprint(bundle: TrustBundle) -> str:
        anchors = sorted(
            (anchor.model_dump(mode="python") for anchor in bundle.anchors),
            key=lambda item: str(item["kid"]),
        )
        return derive_root_fingerprint(dumps(anchors))

    def _pin_bundle(self, bundle: TrustBundle) -> None:
        expected = (bundle.trust_domain_id, self._root_fingerprint(bundle))
        row = self.connection.execute(
            "SELECT trust_domain_id, root_fingerprint FROM registry_identity WHERE singleton = 1"
        ).fetchone()
        if row is None:
            self.connection.execute(
                """
                INSERT INTO registry_identity(singleton, trust_domain_id, root_fingerprint)
                VALUES (1, ?, ?)
                """,
                expected,
            )
            return
        if (row["trust_domain_id"], row["root_fingerprint"]) != expected:
            raise RegistryError("registry is pinned to another trust-domain genesis")

    def _record_kos_allocation(self, candidate: ParsedArtifact) -> None:
        binding = validate_kos_entity_profile(candidate.revision.entity)
        if binding is None:
            return
        rid = binding.canonical.allocation_event_id
        event = (
            binding.canonical.value,
            binding.allocation.value,
            str(binding.ordinal),
            candidate.revision.entity_id,
            candidate.revision.manifest_id,
            binding.canonical.allocation_authority_eid,
            binding.canonical.allocation_authority_mid,
        )
        existing = self.connection.execute(
            """
            SELECT canonical_id, allocation_number, ordinal, subject_eid,
                   subject_mid, authority_eid, authority_mid
            FROM allocation_events WHERE rid = ?
            """,
            (rid,),
        ).fetchone()
        if existing is not None:
            if tuple(existing) != event:
                raise RegistryError("KOS allocation RID is already bound to another event")
            return
        high_water_row = self.connection.execute(
            "SELECT high_water FROM allocation_state WHERE singleton = 1"
        ).fetchone()
        if high_water_row is None:
            raise RegistryError("registry allocation state is missing")
        expected_ordinal = int(high_water_row["high_water"]) + 1
        collision = self.connection.execute(
            """
            SELECT rid FROM allocation_events
            WHERE canonical_id = ? OR allocation_number = ?
            """,
            (binding.canonical.value, binding.allocation.value),
        ).fetchone()
        if collision is not None:
            raise RegistryError("external identifier is already allocated to another identity")
        if binding.ordinal != expected_ordinal:
            raise RegistryError(
                f"K1 allocation must be the next ordinal {expected_ordinal}, not {binding.ordinal}"
            )
        self.connection.execute(
            """
            INSERT INTO allocation_events(
                rid, canonical_id, allocation_number, ordinal,
                subject_eid, subject_mid, authority_eid, authority_mid,
                allocated_at, first_vid
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                rid,
                *event,
                candidate.revision.issued_at,
                candidate.vid,
            ),
        )
        self.connection.execute(
            "UPDATE allocation_state SET high_water = ? WHERE singleton = 1",
            (str(binding.ordinal),),
        )

    def next_k1_ordinal(self) -> int:
        """Return a non-authoritative allocation hint.

        Admission under ``BEGIN IMMEDIATE`` decides the authoritative next
        value; concurrent callers must rebuild and retry if another allocation
        commits first.
        """

        row = self.connection.execute(
            "SELECT high_water FROM allocation_state WHERE singleton = 1"
        ).fetchone()
        if row is None:
            raise RegistryError("registry allocation state is missing")
        return int(row["high_water"]) + 1

    def pin_trust_domain(self, bundle: TrustBundle) -> None:
        """Explicitly pin a migrated or empty registry to one trust-domain genesis."""

        try:
            self.connection.execute("BEGIN IMMEDIATE")
            self._pin_bundle(bundle)
            errors = self.verify(bundle)
            if errors:
                raise RegistryError(f"registry cannot be pinned: {errors}")
            self.connection.commit()
        except (sqlite3.Error, RegistryError):
            self.connection.rollback()
            raise

    def checkpoint(self, bundle: TrustBundle) -> RegistryCheckpoint:
        try:
            self.connection.execute("BEGIN")
            errors = self.verify(bundle)
            if errors:
                raise RegistryError(f"refusing checkpoint of invalid registry: {errors}")
            identity = self.connection.execute(
                """
                SELECT trust_domain_id, root_fingerprint
                FROM registry_identity WHERE singleton = 1
                """
            ).fetchone()
            state = self.connection.execute(
                "SELECT high_water FROM allocation_state WHERE singleton = 1"
            ).fetchone()
            if identity is None or state is None:
                raise RegistryError(
                    "registry checkpoint requires pinned identity and allocation state"
                )
            events = [
                tuple(row)
                for row in self.connection.execute(
                    """
                    SELECT rid, canonical_id, allocation_number, ordinal,
                           subject_eid, subject_mid, authority_eid, authority_mid,
                           allocated_at, first_vid
                    FROM allocation_events ORDER BY allocation_number
                    """
                ).fetchall()
            ]
            artifacts = [
                tuple(row)
                for row in self.connection.execute(
                    """
                    SELECT vid, eid, mid, revision, predecessor_vid
                    FROM artifacts ORDER BY mid, revision
                    """
                ).fetchall()
            ]
            heads = [
                tuple(row)
                for row in self.connection.execute(
                    "SELECT mid, eid, vid FROM heads ORDER BY mid"
                ).fetchall()
            ]
            self.connection.commit()
        except (sqlite3.Error, RegistryError):
            self.connection.rollback()
            raise
        payload = {
            "schema": "idm-registry-checkpoint-v1",
            "schema_version": SCHEMA_VERSION,
            "trust_domain_id": str(identity["trust_domain_id"]),
            "root_fingerprint": str(identity["root_fingerprint"]),
            "allocation_high_water": str(state["high_water"]),
            "allocation_events": events,
            "artifacts": artifacts,
            "heads": heads,
        }
        return RegistryCheckpoint(
            trust_domain_id=str(identity["trust_domain_id"]),
            root_fingerprint=str(identity["root_fingerprint"]),
            schema_version=SCHEMA_VERSION,
            allocation_high_water=int(state["high_water"]),
            allocation_count=len(events),
            artifact_count=len(artifacts),
            lineage_count=len(heads),
            digest=derive_checkpoint_id(dumps(payload)),
        )

    def assert_checkpoint(self, bundle: TrustBundle, expected_digest: str) -> RegistryCheckpoint:
        """Fail closed unless the current snapshot matches independently retained evidence."""

        validate_checkpoint_id(expected_digest)
        checkpoint = self.checkpoint(bundle)
        if checkpoint.digest != expected_digest:
            raise RegistryError("registry checkpoint does not match expected recovery evidence")
        return checkpoint

    def _artifact_by_vid(self, vid: str) -> bytes | None:
        row = self.connection.execute(
            "SELECT artifact FROM artifacts WHERE vid = ?", (vid,)
        ).fetchone()
        return None if row is None else bytes(row["artifact"])

    def latest_artifact(self, *, eid: str | None = None, mid: str | None = None) -> bytes | None:
        if (eid is None) == (mid is None):
            raise RegistryError("specify exactly one of EID or MID")
        if eid is not None:
            row = self.connection.execute(
                """
                SELECT h.mid, h.vid, a.artifact FROM heads h
                JOIN artifacts a ON a.vid = h.vid WHERE h.eid = ?
                """,
                (eid,),
            ).fetchone()
        else:
            row = self.connection.execute(
                """
                SELECT h.mid, h.vid, a.artifact FROM heads h
                JOIN artifacts a ON a.vid = h.vid WHERE h.mid = ?
                """,
                (mid,),
            ).fetchone()
        if row is None:
            return None
        artifact_bytes = bytes(row["artifact"])
        try:
            artifact = parse_artifact(artifact_bytes)
        except IDMError as exc:
            raise RegistryError("registry head contains an invalid artifact") from exc
        greatest = self.connection.execute(
            "SELECT vid FROM artifacts WHERE mid = ? ORDER BY revision DESC LIMIT 1",
            (row["mid"],),
        ).fetchone()
        if (
            greatest is None
            or greatest["vid"] != row["vid"]
            or artifact.vid != row["vid"]
            or artifact.revision.manifest_id != row["mid"]
        ):
            raise RegistryError("registry head is not the greatest admitted revision")
        return artifact_bytes

    def _assert_no_hierarchy_cycle(
        self,
        candidate: ParsedArtifact,
        *,
        excluded_lineages: set[str] | None = None,
    ) -> None:
        excluded = excluded_lineages or set()
        rows = self.connection.execute(
            """
            SELECT relationship_type, source_eid, source_mid, target_eid, target_mid
            FROM relationships
            WHERE status = 'active' AND source_mid != ?
            """,
            (candidate.revision.manifest_id,),
        ).fetchall()
        adjacency: dict[str, set[str]] = {}
        for row in rows:
            if row["source_mid"] in excluded or row["target_mid"] in excluded:
                continue
            if row["relationship_type"] not in CYCLE_CONTROLLED_RELATIONSHIPS:
                continue
            parent, child = _hierarchy_arc(
                row["relationship_type"], row["source_eid"], row["target_eid"]
            )
            adjacency.setdefault(parent, set()).add(child)

        def reaches(start: str, target: str) -> bool:
            pending = [start]
            seen: set[str] = set()
            while pending:
                current = pending.pop()
                if current == target:
                    return True
                if current in seen:
                    continue
                seen.add(current)
                pending.extend(adjacency.get(current, set()))
            return False

        for edge in candidate.revision.relationships.authoritative:
            if edge.status.value != "active" or edge.type not in CYCLE_CONTROLLED_RELATIONSHIPS:
                continue
            parent, child = _hierarchy_arc(edge.type, edge.source_eid, edge.target_eid)
            if reaches(child, parent):
                raise GraphError("relationship would create a circular authority hierarchy")
            adjacency.setdefault(parent, set()).add(child)

    def add(
        self,
        artifact_bytes: bytes,
        bundle: TrustBundle,
        *,
        revocations: RevocationSet | None = None,
        evaluation_time: str | None = None,
        _manage_transaction: bool = True,
    ) -> RegistryAddResult:
        report = verify_artifact(
            artifact_bytes,
            bundle,
            revocations=revocations,
            evaluation_time=evaluation_time,
        )
        if not report.trusted:
            raise RegistryError(f"registry rejected untrusted artifact: {report.errors}")
        candidate = parse_artifact(artifact_bytes)
        validate_revision_relationships(candidate.revision)
        validate_kos_entity_profile(candidate.revision.entity)

        try:
            if _manage_transaction:
                self.connection.execute("BEGIN IMMEDIATE")
            self._pin_bundle(bundle)
            existing_errors = self.verify(
                bundle,
                evaluation_time=evaluation_time,
            )
            if existing_errors:
                raise RegistryError(
                    f"registry integrity audit failed before admission: {existing_errors}"
                )
            revoked_lineages = self.revoked_lineages(
                bundle,
                revocations=revocations,
                evaluation_time=evaluation_time,
            )
            if candidate.revision.manifest_id in revoked_lineages:
                raise RegistryError("candidate belongs to a revoked lineage")
            duplicate = self.connection.execute(
                "SELECT 1 FROM artifacts WHERE vid = ?", (candidate.vid,)
            ).fetchone()
            if duplicate is not None:
                raise LineageError("duplicate artifact VID")
            same_revision = self.connection.execute(
                "SELECT vid FROM artifacts WHERE mid = ? AND revision = ?",
                (candidate.revision.manifest_id, candidate.revision.revision),
            ).fetchone()
            if same_revision is not None:
                raise LineageError("duplicate revision number or divergent fork")
            head = self.connection.execute(
                "SELECT vid, eid FROM heads WHERE mid = ?", (candidate.revision.manifest_id,)
            ).fetchone()
            eid_owner = self.connection.execute(
                "SELECT mid FROM heads WHERE eid = ?",
                (candidate.revision.entity_id,),
            ).fetchone()
            if eid_owner is not None and eid_owner["mid"] != candidate.revision.manifest_id:
                raise RegistryError("entity ID is already allocated to another lineage")
            predecessor: ParsedArtifact | None = None
            if candidate.revision.revision == 1:
                if head is not None:
                    raise LineageError("genesis conflicts with an existing lineage")
            else:
                predecessor_bytes = self._artifact_by_vid(candidate.revision.predecessor_vid or "")
                if predecessor_bytes is None:
                    raise LineageError("unknown predecessor")
                predecessor = parse_artifact(predecessor_bytes)
                validate_successor(predecessor, candidate.revision)
                if head is None or head["vid"] != predecessor.vid:
                    raise LineageError("rollback or divergent branch detected")
            decision = evaluate_revision_policy(predecessor, candidate, report)
            if not decision.allowed:
                raise PolicyError(f"revision policy denied: {decision.errors}")
            self._assert_no_hierarchy_cycle(
                candidate,
                excluded_lineages=revoked_lineages,
            )
            revision = candidate.revision
            self.connection.execute(
                """
                INSERT INTO artifacts(
                    vid, eid, mid, revision, predecessor_vid, issued_at,
                    entity_type, lifecycle_state, artifact
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    candidate.vid,
                    revision.entity_id,
                    revision.manifest_id,
                    revision.revision,
                    revision.predecessor_vid,
                    revision.issued_at,
                    revision.entity.type,
                    revision.lifecycle.state.value,
                    artifact_bytes,
                ),
            )
            self._record_kos_allocation(candidate)
            self.connection.execute(
                """
                INSERT INTO heads(mid, eid, vid) VALUES (?, ?, ?)
                ON CONFLICT(mid) DO UPDATE SET eid = excluded.eid, vid = excluded.vid
                """,
                (revision.manifest_id, revision.entity_id, candidate.vid),
            )
            for binding in revision.entity.external_identifiers:
                existing = self.connection.execute(
                    """
                    SELECT eid, mid FROM external_identifiers
                    WHERE scheme = ? AND value = ?
                    """,
                    (binding.scheme, binding.value),
                ).fetchone()
                if existing is not None:
                    if (
                        existing["eid"] != revision.entity_id
                        or existing["mid"] != revision.manifest_id
                    ):
                        raise RegistryError(
                            "external identifier is already allocated to another identity"
                        )
                    continue
                self.connection.execute(
                    """
                    INSERT INTO external_identifiers(
                        scheme, value, eid, mid, allocation_event_id,
                        allocation_authority_eid, allocation_authority_mid, first_vid
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        binding.scheme,
                        binding.value,
                        revision.entity_id,
                        revision.manifest_id,
                        binding.allocation_event_id,
                        binding.allocation_authority_eid,
                        binding.allocation_authority_mid,
                        candidate.vid,
                    ),
                )
            prior_edge_rows = self.connection.execute(
                """
                SELECT rid, source_vid, edge_hash
                FROM relationships WHERE source_mid = ?
                """,
                (revision.manifest_id,),
            ).fetchall()
            prior_edges = {row["rid"]: row for row in prior_edge_rows}

            def evidence_vid(edge: Relationship) -> str:
                prior = prior_edges.get(edge.relationship_id)
                if prior is None:
                    return candidate.vid
                current_hash = derive_vid(dumps(edge.model_dump(mode="python")))
                unchanged = prior["edge_hash"] == current_hash
                return str(prior["source_vid"]) if unchanged else candidate.vid

            self.connection.execute(
                "DELETE FROM relationships WHERE source_mid = ?", (revision.manifest_id,)
            )
            self.connection.execute(
                "DELETE FROM relationship_references WHERE target_mid = ?",
                (revision.manifest_id,),
            )
            self.connection.executemany(
                """
                INSERT INTO relationships(
                    rid, source_eid, source_mid, source_vid, relationship_type,
                    target_eid, target_mid, effective_from, effective_until, status
                    , edge_hash
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                [
                    (
                        edge.relationship_id,
                        edge.source_eid,
                        edge.source_mid,
                        evidence_vid(edge),
                        edge.type,
                        edge.target_eid,
                        edge.target_mid,
                        edge.effective_from,
                        edge.effective_until,
                        edge.status.value,
                        derive_vid(dumps(edge.model_dump(mode="python"))),
                    )
                    for edge in revision.relationships.authoritative
                ],
            )
            self.connection.executemany(
                """
                INSERT INTO relationship_references(
                    rid, target_eid, target_mid, target_vid,
                    authoritative_mid, authoritative_vid, local_role
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                [
                    (
                        reference.relationship_id,
                        revision.entity_id,
                        revision.manifest_id,
                        candidate.vid,
                        reference.authoritative_mid,
                        reference.authoritative_vid,
                        reference.local_role,
                    )
                    for reference in revision.relationships.references
                ],
            )
            if _manage_transaction:
                self.connection.commit()
        except (sqlite3.Error, LineageError, PolicyError, GraphError, RegistryError):
            if _manage_transaction:
                self.connection.rollback()
            raise
        return RegistryAddResult(
            vid=candidate.vid,
            entity_id=candidate.revision.entity_id,
            manifest_id=candidate.revision.manifest_id,
            revision=candidate.revision.revision,
        )

    def add_file(
        self,
        path: Path,
        bundle: TrustBundle,
        *,
        revocations: RevocationSet | None = None,
        evaluation_time: str | None = None,
    ) -> RegistryAddResult:
        return self.add(
            read_bytes_limited(path, max_bytes=MAX_ARTIFACT_BYTES),
            bundle,
            revocations=revocations,
            evaluation_time=evaluation_time,
        )

    def sync(
        self,
        paths: Iterable[Path],
        bundle: TrustBundle,
        *,
        revocations: RevocationSet | None = None,
        evaluation_time: str | None = None,
    ) -> list[RegistryAddResult]:
        candidates = [read_bytes_limited(path, max_bytes=MAX_ARTIFACT_BYTES) for path in paths]

        def sync_order(data: bytes) -> tuple[object, ...]:
            artifact = parse_artifact(data)
            binding = kos_allocation_binding(artifact.revision.entity)
            if binding is not None:
                return (0, binding.ordinal, artifact.revision.revision)
            return (
                1,
                artifact.revision.manifest_id,
                artifact.revision.revision,
            )

        candidates.sort(key=sync_order)
        try:
            self.connection.execute("BEGIN IMMEDIATE")
            results = [
                self.add(
                    data,
                    bundle,
                    revocations=revocations,
                    evaluation_time=evaluation_time,
                    _manage_transaction=False,
                )
                for data in candidates
            ]
            self.connection.commit()
            return results
        except (sqlite3.Error, LineageError, PolicyError, GraphError, RegistryError):
            self.connection.rollback()
            raise

    def verify(
        self,
        bundle: TrustBundle,
        *,
        evaluation_time: str | None = None,
    ) -> list[str]:
        errors: list[str] = []
        identity = self.connection.execute(
            "SELECT trust_domain_id, root_fingerprint FROM registry_identity WHERE singleton = 1"
        ).fetchone()
        artifact_count = int(
            self.connection.execute("SELECT COUNT(*) FROM artifacts").fetchone()[0]
        )
        expected_identity = (bundle.trust_domain_id, self._root_fingerprint(bundle))
        if identity is None:
            if artifact_count:
                errors.append("registry with admitted artifacts has no trust-domain pin")
        elif tuple(identity) != expected_identity:
            errors.append("registry trust-domain genesis does not match the supplied bundle")
        rows = self.connection.execute(
            "SELECT vid, eid, mid, revision, artifact FROM artifacts ORDER BY mid, revision"
        ).fetchall()
        grouped: dict[str, list[ParsedArtifact]] = {}
        for row in rows:
            artifact_bytes = bytes(row["artifact"])
            try:
                artifact = parse_artifact(artifact_bytes)
            except IDMError:
                errors.append(f"artifact {row['vid']} cannot be parsed")
                continue
            if (
                artifact.vid != row["vid"]
                or artifact.revision.entity_id != row["eid"]
                or artifact.revision.manifest_id != row["mid"]
                or artifact.revision.revision != row["revision"]
            ):
                errors.append(f"artifact {row['vid']} disagrees with its registry metadata")
                continue
            report = verify_artifact(
                artifact_bytes,
                bundle,
                evaluation_time=evaluation_time,
            )
            if not report.trusted or report.vid != row["vid"]:
                errors.append(f"artifact {row['vid']} failed evidence verification")
            grouped.setdefault(artifact.revision.manifest_id, []).append(artifact)
        heads = {
            str(row["mid"]): (str(row["eid"]), str(row["vid"]))
            for row in self.connection.execute("SELECT mid, eid, vid FROM heads")
        }
        for mid, lineage in grouped.items():
            lineage.sort(key=lambda item: item.revision.revision)
            if lineage[0].revision.revision != 1:
                errors.append(f"lineage {mid} has no genesis revision")
                continue
            predecessor: ParsedArtifact | None = None
            for artifact in lineage:
                report = verify_artifact(
                    artifact.exact_bytes,
                    bundle,
                    evaluation_time=evaluation_time,
                )
                try:
                    if predecessor is not None:
                        validate_successor(predecessor, artifact.revision)
                    decision = evaluate_revision_policy(predecessor, artifact, report)
                    if not decision.allowed:
                        errors.append(
                            f"artifact {artifact.vid} failed revision policy: {decision.errors}"
                        )
                except (LineageError, PolicyError) as exc:
                    errors.append(f"artifact {artifact.vid} failed lineage audit: {exc}")
                predecessor = artifact
            expected = lineage[-1]
            head = heads.pop(mid, None)
            if head is None:
                errors.append(f"lineage {mid} has no current head")
            elif head != (expected.revision.entity_id, expected.vid):
                errors.append(f"head {mid} is not the greatest admitted revision")
        for mid in heads:
            errors.append(f"head {mid} does not resolve to an audited lineage")

        expected_relationships: list[tuple[object, ...]] = []
        expected_references: list[tuple[object, ...]] = []
        expected_identifiers: dict[tuple[str, str], tuple[object, ...]] = {}
        expected_allocation_events: dict[str, tuple[object, ...]] = {}
        for mid, lineage in grouped.items():
            lineage.sort(key=lambda item: item.revision.revision)
            retained_edges: dict[str, tuple[str, str]] = {}
            for artifact in lineage:
                next_edges: dict[str, tuple[str, str]] = {}
                for edge in artifact.revision.relationships.authoritative:
                    edge_hash = derive_vid(dumps(edge.model_dump(mode="python")))
                    prior = retained_edges.get(edge.relationship_id)
                    source_vid = (
                        prior[1] if prior is not None and prior[0] == edge_hash else artifact.vid
                    )
                    next_edges[edge.relationship_id] = (edge_hash, source_vid)
                retained_edges = next_edges

            head_artifact = lineage[-1]
            for artifact in lineage:
                for binding in artifact.revision.entity.external_identifiers:
                    key = (binding.scheme, binding.value)
                    expected_identifiers.setdefault(
                        key,
                        (
                            binding.scheme,
                            binding.value,
                            artifact.revision.entity_id,
                            artifact.revision.manifest_id,
                            binding.allocation_event_id,
                            binding.allocation_authority_eid,
                            binding.allocation_authority_mid,
                            artifact.vid,
                        ),
                    )
                kos_binding = kos_allocation_binding(artifact.revision.entity)
                if kos_binding is not None:
                    event = (
                        kos_binding.canonical.allocation_event_id,
                        kos_binding.canonical.value,
                        kos_binding.allocation.value,
                        str(kos_binding.ordinal),
                        artifact.revision.entity_id,
                        artifact.revision.manifest_id,
                        kos_binding.canonical.allocation_authority_eid,
                        kos_binding.canonical.allocation_authority_mid,
                        artifact.revision.issued_at,
                        artifact.vid,
                    )
                    prior_event = expected_allocation_events.setdefault(event[0], event)
                    if prior_event[:8] != event[:8]:
                        errors.append(
                            f"allocation RID {event[0]} is reused by conflicting signed evidence"
                        )
            for edge in head_artifact.revision.relationships.authoritative:
                edge_hash, source_vid = retained_edges[edge.relationship_id]
                expected_relationships.append(
                    (
                        edge.relationship_id,
                        edge.source_eid,
                        edge.source_mid,
                        source_vid,
                        edge.type,
                        edge.target_eid,
                        edge.target_mid,
                        edge.effective_from,
                        edge.effective_until,
                        edge.status.value,
                        edge_hash,
                    )
                )
            for reference in head_artifact.revision.relationships.references:
                expected_references.append(
                    (
                        reference.relationship_id,
                        head_artifact.revision.entity_id,
                        mid,
                        head_artifact.vid,
                        reference.authoritative_mid,
                        reference.authoritative_vid,
                        reference.local_role,
                    )
                )

        actual_relationships = [
            tuple(row)
            for row in self.connection.execute(
                """
                SELECT
                    rid, source_eid, source_mid, source_vid, relationship_type,
                    target_eid, target_mid, effective_from, effective_until,
                    status, edge_hash
                FROM relationships
                ORDER BY rid
                """
            ).fetchall()
        ]
        actual_references = [
            tuple(row)
            for row in self.connection.execute(
                """
                SELECT
                    rid, target_eid, target_mid, target_vid,
                    authoritative_mid, authoritative_vid, local_role
                FROM relationship_references
                ORDER BY rid, target_mid
                """
            ).fetchall()
        ]
        actual_identifiers = [
            tuple(row)
            for row in self.connection.execute(
                """
                SELECT
                    scheme, value, eid, mid, allocation_event_id,
                    allocation_authority_eid, allocation_authority_mid, first_vid
                FROM external_identifiers
                ORDER BY scheme, value
                """
            ).fetchall()
        ]
        actual_allocation_events = sorted(
            [
                tuple(row)
                for row in self.connection.execute(
                    """
                SELECT rid, canonical_id, allocation_number, ordinal,
                       subject_eid, subject_mid, authority_eid, authority_mid,
                       allocated_at, first_vid
                FROM allocation_events
                """
                ).fetchall()
            ],
            key=lambda item: int(str(item[3])),
        )
        if actual_relationships != sorted(expected_relationships):
            errors.append("relationship index does not match exact signed artifact evidence")
        if actual_references != sorted(expected_references):
            errors.append(
                "relationship-reference index does not match exact signed artifact evidence"
            )
        if actual_identifiers != sorted(expected_identifiers.values()):
            errors.append("external-identifier allocation index does not match signed evidence")
        expected_events = sorted(
            expected_allocation_events.values(), key=lambda item: int(str(item[3]))
        )
        if actual_allocation_events != expected_events:
            errors.append("allocation-event ledger does not match signed evidence")
        expected_ordinals = [int(str(item[3])) for item in expected_events]
        if expected_ordinals != list(range(1, len(expected_ordinals) + 1)):
            errors.append("K1 allocation ledger is not one contiguous monotonic sequence")
        state = self.connection.execute(
            "SELECT high_water FROM allocation_state WHERE singleton = 1"
        ).fetchone()
        expected_high_water = str(len(expected_events))
        if state is None or str(state["high_water"]) != expected_high_water:
            errors.append("K1 allocation high-water mark does not match signed evidence")
        return errors

    def revoked_lineages(
        self,
        bundle: TrustBundle,
        *,
        revocations: RevocationSet | None,
        evaluation_time: str | None = None,
    ) -> set[str]:
        if revocations is None:
            return set()
        revoked: set[str] = set()
        rows = self.connection.execute("SELECT mid, artifact FROM artifacts").fetchall()
        for row in rows:
            report = verify_artifact(
                bytes(row["artifact"]),
                bundle,
                revocations=revocations,
                evaluation_time=evaluation_time,
            )
            if report.revoked:
                revoked.add(str(row["mid"]))
        return revoked
