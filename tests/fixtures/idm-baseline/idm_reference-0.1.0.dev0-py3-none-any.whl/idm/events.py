"""Hash-linked signed local event journals for bounded offline operation."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator

from .attestation import encode_attestation, parse_attestation, verify_attestation
from .capabilities import EffectiveCapability
from .container import ParsedArtifact
from .errors import OfflineError, SignatureError
from .files import read_bytes_limited, write_bytes_exclusive
from .identifiers import (
    derive_vid,
    new_rid,
    validate_eid,
    validate_evidence_id,
    validate_mid,
    validate_rid,
    validate_vid,
)
from .keybindings import decode_bound_public_key
from .lifecycle import OPERABLE_STATES
from .models import KeyPurpose, StrictModel
from .offline import VerifiedOfflineBundle, authorize_offline_capability
from .registry import Registry
from .revocation import RevocationTargetType
from .timeutil import validate_timestamp

OFFLINE_EVENT_CONTEXT = "idm/v1/offline-event"


class OfflineEventPayload(StrictModel):
    schema_name: Literal["idm-offline-event"] = Field(default="idm-offline-event", alias="schema")
    version: Literal[1] = 1
    event_id: str
    sequence: int = Field(ge=1)
    previous_evidence_id: str | None
    base_vid: str
    actor_eid: str
    actor_mid: str
    session_id: str
    action: str = Field(min_length=1, max_length=256)
    capability: str = Field(min_length=1, max_length=256)
    resource: str = Field(min_length=1, max_length=1024)
    operation: str = Field(min_length=1, max_length=256)
    payload_hash: str
    payload_size: int = Field(ge=0, le=1024 * 1024 * 1024)
    signed_at: str

    @field_validator("event_id", "session_id")
    @classmethod
    def check_rid(cls, value: str) -> str:
        return validate_rid(value)

    @field_validator("base_vid", "payload_hash")
    @classmethod
    def check_vid(cls, value: str) -> str:
        return validate_vid(value)

    @field_validator("actor_eid")
    @classmethod
    def check_eid(cls, value: str) -> str:
        return validate_eid(value)

    @field_validator("actor_mid")
    @classmethod
    def check_mid(cls, value: str) -> str:
        return validate_mid(value)

    @field_validator("signed_at")
    @classmethod
    def check_time(cls, value: str) -> str:
        return validate_timestamp(value)

    @field_validator("previous_evidence_id")
    @classmethod
    def check_evidence_id(cls, value: str | None) -> str | None:
        return None if value is None else validate_evidence_id(value)


@dataclass(frozen=True, slots=True)
class VerifiedOfflineEvent:
    payload: OfflineEventPayload
    evidence_id: str
    signer_kid: str
    capability: EffectiveCapability
    exact_bytes: bytes


def _head_artifact(bundle: VerifiedOfflineBundle, mid: str) -> ParsedArtifact:
    head_vid = bundle.payload.heads.get(mid)
    matches = [artifact for artifact in bundle.artifacts if artifact.vid == head_vid]
    if len(matches) != 1:
        raise OfflineError("offline event actor head is absent or ambiguous")
    return matches[0]


def create_offline_event(
    *,
    bundle: VerifiedOfflineBundle,
    actor: ParsedArtifact,
    private_key: bytes,
    kid: str,
    sequence: int,
    previous_evidence_id: str | None,
    session_id: str,
    action: str,
    capability: str,
    resource: str,
    operation: str,
    event_data: bytes,
    signed_at: str,
) -> bytes:
    if bundle.payload.heads.get(actor.revision.manifest_id) != actor.vid:
        raise OfflineError("offline event must be based on the packaged current head")
    if actor.revision.lifecycle.state not in OPERABLE_STATES:
        raise OfflineError("offline event actor is not in an operable lifecycle state")
    authorize_offline_capability(
        bundle,
        actor.revision,
        capability=capability,
        resource=resource,
        operation=operation,
        evaluation_time=signed_at,
        input_bytes=len(event_data),
    )
    payload = OfflineEventPayload(
        event_id=new_rid(),
        sequence=sequence,
        previous_evidence_id=previous_evidence_id,
        base_vid=actor.vid,
        actor_eid=actor.revision.entity_id,
        actor_mid=actor.revision.manifest_id,
        session_id=session_id,
        action=action,
        capability=capability,
        resource=resource,
        operation=operation,
        payload_hash=derive_vid(event_data),
        payload_size=len(event_data),
        signed_at=signed_at,
    )
    return encode_attestation(
        payload.model_dump(mode="python"),
        context=OFFLINE_EVENT_CONTEXT,
        private_key=private_key,
        kid=kid,
    )


def verify_offline_event(data: bytes, *, bundle: VerifiedOfflineBundle) -> VerifiedOfflineEvent:
    try:
        attestation = parse_attestation(data, expected_context=OFFLINE_EVENT_CONTEXT)
        payload = OfflineEventPayload.model_validate(attestation.payload)
        actor = _head_artifact(bundle, payload.actor_mid)
        if (
            actor.vid != payload.base_vid
            or actor.revision.entity_id != payload.actor_eid
            or actor.revision.manifest_id != payload.actor_mid
        ):
            raise OfflineError("offline event actor does not match its packaged identity head")
        if actor.revision.lifecycle.state not in OPERABLE_STATES:
            raise OfflineError("offline event actor is not in an operable lifecycle state")
        bindings = [binding for binding in actor.revision.keys if binding.kid == attestation.kid]
        if len(bindings) != 1:
            raise OfflineError("offline event key is not bound to the actor")
        binding = bindings[0]
        if not {KeyPurpose.SUBJECT_CONTROL, KeyPurpose.OPERATION}.intersection(binding.purposes):
            raise OfflineError("offline event key lacks operation purpose")
        if payload.signed_at < binding.valid_from or (
            binding.valid_until is not None and payload.signed_at > binding.valid_until
        ):
            raise OfflineError("offline event key is outside its validity interval")
        if bundle.revocations.matches(
            RevocationTargetType.KEY, binding.kid, at_time=payload.signed_at
        ):
            raise OfflineError("offline event key is revoked")
        verify_attestation(attestation, decode_bound_public_key(binding))
        capability = authorize_offline_capability(
            bundle,
            actor.revision,
            capability=payload.capability,
            resource=payload.resource,
            operation=payload.operation,
            evaluation_time=payload.signed_at,
            input_bytes=payload.payload_size,
        )
    except OfflineError:
        raise
    except (ValueError, TypeError, SignatureError) as exc:
        raise OfflineError("offline event is malformed or has an invalid signature") from exc
    return VerifiedOfflineEvent(
        payload=payload,
        evidence_id=attestation.evidence_id,
        signer_kid=attestation.kid,
        capability=capability,
        exact_bytes=data,
    )


class OfflineEventJournal:
    def __init__(self, directory: Path) -> None:
        self.directory = directory.resolve()
        self.directory.mkdir(mode=0o700, parents=True, exist_ok=True)

    def _paths(self) -> list[Path]:
        return sorted(self.directory.glob("*.event.cose"))

    def verify(self, bundle: VerifiedOfflineBundle) -> list[VerifiedOfflineEvent]:
        output: list[VerifiedOfflineEvent] = []
        previous_id: str | None = None
        for expected_sequence, path in enumerate(self._paths(), start=1):
            event = verify_offline_event(
                read_bytes_limited(path, max_bytes=1024 * 1024), bundle=bundle
            )
            if event.payload.sequence != expected_sequence:
                raise OfflineError("offline event journal sequence is broken")
            if event.payload.previous_evidence_id != previous_id:
                raise OfflineError("offline event journal hash link is broken")
            output.append(event)
            previous_id = event.evidence_id
        return output

    def append(
        self,
        *,
        bundle: VerifiedOfflineBundle,
        actor: ParsedArtifact,
        private_key: bytes,
        kid: str,
        session_id: str,
        action: str,
        capability: str,
        resource: str,
        operation: str,
        event_data: bytes,
        signed_at: str,
    ) -> VerifiedOfflineEvent:
        prior = self.verify(bundle)
        sequence = len(prior) + 1
        previous_id = prior[-1].evidence_id if prior else None
        data = create_offline_event(
            bundle=bundle,
            actor=actor,
            private_key=private_key,
            kid=kid,
            sequence=sequence,
            previous_evidence_id=previous_id,
            session_id=session_id,
            action=action,
            capability=capability,
            resource=resource,
            operation=operation,
            event_data=event_data,
            signed_at=signed_at,
        )
        path = self.directory / f"{sequence:020d}.event.cose"
        write_bytes_exclusive(path, data, mode=0o600)
        return verify_offline_event(data, bundle=bundle)

    def synchronization_status(
        self, bundle: VerifiedOfflineBundle, registry: Registry
    ) -> dict[str, list[str]]:
        ready: list[str] = []
        conflicts: list[str] = []
        for event in self.verify(bundle):
            latest = registry.latest_artifact(mid=event.payload.actor_mid)
            if latest is None or derive_vid(latest) != event.payload.base_vid:
                conflicts.append(event.evidence_id)
            else:
                ready.append(event.evidence_id)
        return {"ready": ready, "conflicts": conflicts}
