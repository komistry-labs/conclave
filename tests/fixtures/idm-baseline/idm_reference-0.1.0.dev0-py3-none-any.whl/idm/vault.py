"""Non-production encrypted local key-vault backend."""

from __future__ import annotations

import base64
import json
import os
import secrets
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Literal, Self

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from pydantic import Field, field_validator, model_validator

from .crypto import generate_ed25519_private_key, public_key_from_private
from .errors import FileSafetyError, VaultError
from .identifiers import derive_kid, derive_section_kid, validate_kid, validate_section_kid
from .models import StrictModel

_VAULT_FORMAT = "idm-encrypted-key"
_VAULT_VERSION = 1
_SECTION_VAULT_FORMAT = "idm-encrypted-section-key"
_SCRYPT_N = 2**15
_SCRYPT_R = 8
_SCRYPT_P = 1


def _b64(value: bytes) -> str:
    return base64.b64encode(value).decode("ascii")


def _unb64(value: str) -> bytes:
    try:
        return base64.b64decode(value, validate=True)
    except ValueError as exc:
        raise VaultError("vault contains malformed base64") from exc


class EncryptedKeyRecord(StrictModel):
    format: Literal["idm-encrypted-key"] = "idm-encrypted-key"
    version: Literal[1] = 1
    kid: str
    public_key: str
    kdf: Literal["scrypt"] = "scrypt"
    salt: str
    n: int = Field(default=_SCRYPT_N, ge=2**14, le=2**16)
    r: int = Field(default=_SCRYPT_R, ge=8, le=16)
    p: int = Field(default=_SCRYPT_P, ge=1, le=4)
    aead: Literal["AES-256-GCM"] = "AES-256-GCM"
    nonce: str
    ciphertext: str

    @field_validator("kid")
    @classmethod
    def check_kid(cls, value: str) -> str:
        return validate_kid(value)

    @model_validator(mode="after")
    def check_kdf_cost(self) -> Self:
        if self.n & (self.n - 1) or self.n * self.r > 2**19:
            raise ValueError("vault scrypt cost is outside the supported security envelope")
        return self


class EncryptedSectionKeyRecord(StrictModel):
    format: Literal["idm-encrypted-section-key"] = "idm-encrypted-section-key"
    version: Literal[1] = 1
    key_id: str
    kdf: Literal["scrypt"] = "scrypt"
    salt: str
    n: int = Field(default=_SCRYPT_N, ge=2**14, le=2**16)
    r: int = Field(default=_SCRYPT_R, ge=8, le=16)
    p: int = Field(default=_SCRYPT_P, ge=1, le=4)
    aead: Literal["AES-256-GCM"] = "AES-256-GCM"
    nonce: str
    ciphertext: str

    @field_validator("key_id")
    @classmethod
    def check_key_id(cls, value: str) -> str:
        return validate_section_kid(value)

    @model_validator(mode="after")
    def check_kdf_cost(self) -> Self:
        if self.n & (self.n - 1) or self.n * self.r > 2**19:
            raise ValueError("vault scrypt cost is outside the supported security envelope")
        return self


@dataclass(frozen=True, slots=True)
class GeneratedKey:
    private_key: bytes
    public_key: bytes
    kid: str


@dataclass(frozen=True, slots=True)
class GeneratedSectionKey:
    key: bytes
    key_id: str


def _derive_vault_key(passphrase: bytes, salt: bytes, *, n: int, r: int, p: int) -> bytes:
    try:
        return Scrypt(salt=salt, length=32, n=n, r=r, p=p).derive(passphrase)
    except (TypeError, ValueError) as exc:
        raise VaultError("invalid vault KDF parameters") from exc


def generate_key() -> GeneratedKey:
    private_key = generate_ed25519_private_key()
    public_key = public_key_from_private(private_key)
    return GeneratedKey(private_key=private_key, public_key=public_key, kid=derive_kid(public_key))


def generate_section_key() -> GeneratedSectionKey:
    key = secrets.token_bytes(32)
    return GeneratedSectionKey(key=key, key_id=derive_section_kid(key))


def encrypt_key(generated: GeneratedKey, passphrase: str) -> EncryptedKeyRecord:
    encoded_passphrase = passphrase.encode("utf-8")
    if len(encoded_passphrase) < 12:
        raise VaultError("development-vault passphrase must be at least 12 UTF-8 bytes")
    salt = secrets.token_bytes(16)
    nonce = secrets.token_bytes(12)
    key = _derive_vault_key(encoded_passphrase, salt, n=_SCRYPT_N, r=_SCRYPT_R, p=_SCRYPT_P)
    aad = f"{_VAULT_FORMAT}|{_VAULT_VERSION}|{generated.kid}".encode()
    ciphertext = AESGCM(key).encrypt(nonce, generated.private_key, aad)
    return EncryptedKeyRecord(
        kid=generated.kid,
        public_key=_b64(generated.public_key),
        salt=_b64(salt),
        nonce=_b64(nonce),
        ciphertext=_b64(ciphertext),
    )


def decrypt_key(record: EncryptedKeyRecord, passphrase: str) -> GeneratedKey:
    if record.format != _VAULT_FORMAT or record.version != _VAULT_VERSION:
        raise VaultError("unsupported vault record")
    if record.kdf != "scrypt" or record.aead != "AES-256-GCM":
        raise VaultError("unsupported vault algorithms")
    salt = _unb64(record.salt)
    nonce = _unb64(record.nonce)
    ciphertext = _unb64(record.ciphertext)
    public_key = _unb64(record.public_key)
    if len(salt) != 16 or len(nonce) != 12 or len(ciphertext) != 48 or len(public_key) != 32:
        raise VaultError("key-vault cryptographic field has an invalid length")
    key = _derive_vault_key(passphrase.encode("utf-8"), salt, n=record.n, r=record.r, p=record.p)
    aad = f"{_VAULT_FORMAT}|{_VAULT_VERSION}|{record.kid}".encode()
    try:
        private_key = AESGCM(key).decrypt(nonce, ciphertext, aad)
    except InvalidTag as exc:
        raise VaultError("vault authentication failed") from exc
    derived_public = public_key_from_private(private_key)
    if derived_public != public_key or derive_kid(derived_public) != record.kid:
        raise VaultError("vault key identity mismatch")
    return GeneratedKey(private_key=private_key, public_key=public_key, kid=record.kid)


def encrypt_section_key(
    generated: GeneratedSectionKey, passphrase: str
) -> EncryptedSectionKeyRecord:
    encoded_passphrase = passphrase.encode("utf-8")
    if len(encoded_passphrase) < 12:
        raise VaultError("development-vault passphrase must be at least 12 UTF-8 bytes")
    if len(generated.key) != 32 or derive_section_kid(generated.key) != generated.key_id:
        raise VaultError("invalid generated section key")
    salt = secrets.token_bytes(16)
    nonce = secrets.token_bytes(12)
    key = _derive_vault_key(encoded_passphrase, salt, n=_SCRYPT_N, r=_SCRYPT_R, p=_SCRYPT_P)
    aad = f"{_SECTION_VAULT_FORMAT}|{_VAULT_VERSION}|{generated.key_id}".encode()
    ciphertext = AESGCM(key).encrypt(nonce, generated.key, aad)
    return EncryptedSectionKeyRecord(
        key_id=generated.key_id,
        salt=_b64(salt),
        nonce=_b64(nonce),
        ciphertext=_b64(ciphertext),
    )


def decrypt_section_key(record: EncryptedSectionKeyRecord, passphrase: str) -> GeneratedSectionKey:
    if record.format != _SECTION_VAULT_FORMAT or record.version != _VAULT_VERSION:
        raise VaultError("unsupported section-key vault record")
    if record.kdf != "scrypt" or record.aead != "AES-256-GCM":
        raise VaultError("unsupported section-key vault algorithms")
    salt = _unb64(record.salt)
    nonce = _unb64(record.nonce)
    ciphertext = _unb64(record.ciphertext)
    if len(salt) != 16 or len(nonce) != 12 or len(ciphertext) != 48:
        raise VaultError("section-key vault cryptographic field has an invalid length")
    key = _derive_vault_key(passphrase.encode("utf-8"), salt, n=record.n, r=record.r, p=record.p)
    aad = f"{_SECTION_VAULT_FORMAT}|{_VAULT_VERSION}|{record.key_id}".encode()
    try:
        section_key = AESGCM(key).decrypt(nonce, ciphertext, aad)
    except InvalidTag as exc:
        raise VaultError("section-key vault authentication failed") from exc
    if len(section_key) != 32 or derive_section_kid(section_key) != record.key_id:
        raise VaultError("section-key vault identity mismatch")
    return GeneratedSectionKey(key=section_key, key_id=record.key_id)


def write_key_file(path: Path, record: EncryptedKeyRecord) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError as exc:
        raise FileSafetyError(f"refusing to overwrite {path}") from exc
    payload = record.model_dump_json(indent=2).encode("utf-8") + b"\n"
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())


def _read_private_file(path: Path, *, label: str) -> bytes:
    flags = os.O_RDONLY
    path_info: os.stat_result | None = None
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    else:
        try:
            path_info = os.lstat(path)
        except OSError as exc:
            raise VaultError(f"cannot safely open {label} {path}") from exc
        reparse_flag = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
        file_attributes = getattr(path_info, "st_file_attributes", 0)
        if stat.S_ISLNK(path_info.st_mode) or file_attributes & reparse_flag:
            raise VaultError(f"cannot safely open {label} {path}")
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise VaultError(f"cannot safely open {label} {path}") from exc
    try:
        info = os.fstat(descriptor)
        if path_info is not None:
            try:
                current_path_info = os.lstat(path)
            except OSError as exc:
                raise VaultError(f"cannot safely open {label} {path}") from exc
            reparse_flag = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
            file_attributes = getattr(current_path_info, "st_file_attributes", 0)
            if (
                stat.S_ISLNK(current_path_info.st_mode)
                or file_attributes & reparse_flag
                or not os.path.samestat(path_info, info)
                or not os.path.samestat(current_path_info, info)
            ):
                raise VaultError(f"cannot safely open {label} {path}")
        if not stat.S_ISREG(info.st_mode):
            raise VaultError(f"{label} must be a regular file")
        getuid = getattr(os, "getuid", None)
        if getuid is not None and info.st_uid != getuid():
            raise VaultError(f"{label} must be owned by the current user")
        if os.name != "nt" and info.st_mode & 0o077:
            raise VaultError(f"{label} permissions expose secrets to another user")
        if os.name != "nt" and info.st_nlink != 1:
            raise VaultError(f"{label} must not have multiple hard links")
        raw = bytearray()
        while len(raw) <= 64 * 1024:
            chunk = os.read(descriptor, min(8192, 64 * 1024 + 1 - len(raw)))
            if not chunk:
                break
            raw.extend(chunk)
    finally:
        os.close(descriptor)
    if len(raw) > 64 * 1024:
        raise VaultError(f"{label} exceeds size limit")
    return bytes(raw)


def read_key_file(path: Path) -> EncryptedKeyRecord:
    raw = _read_private_file(path, label="key vault")
    try:
        data = json.loads(raw)
        return EncryptedKeyRecord.model_validate(data)
    except (ValueError, TypeError) as exc:
        raise VaultError("invalid key-vault record") from exc


def write_section_key_file(path: Path, record: EncryptedSectionKeyRecord) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError as exc:
        raise FileSafetyError(f"refusing to overwrite {path}") from exc
    payload = record.model_dump_json(indent=2).encode("utf-8") + b"\n"
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())


def read_section_key_file(path: Path) -> EncryptedSectionKeyRecord:
    raw = _read_private_file(path, label="section-key vault")
    try:
        data = json.loads(raw)
        return EncryptedSectionKeyRecord.model_validate(data)
    except (ValueError, TypeError) as exc:
        raise VaultError("invalid section-key vault record") from exc
