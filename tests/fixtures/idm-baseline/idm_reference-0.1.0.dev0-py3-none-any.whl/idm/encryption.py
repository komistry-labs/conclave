"""Independent authenticated encryption for sensitive manifest sections."""

from __future__ import annotations

import secrets

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from . import canonical
from .container import ParsedArtifact
from .errors import VaultError
from .lineage import build_successor
from .models import ProtectedSection, Revision
from .vault import GeneratedSectionKey


def _section_aad(*, entity_id: str, manifest_id: str, section_name: str) -> bytes:
    return canonical.dumps(
        {
            "context": "idm/v1/protected-section",
            "entity_id": entity_id,
            "manifest_id": manifest_id,
            "section_name": section_name,
        }
    )


def encrypt_section(
    plaintext: bytes,
    *,
    entity_id: str,
    manifest_id: str,
    section_name: str,
    section_key: GeneratedSectionKey,
) -> ProtectedSection:
    if not section_name or len(section_name) > 128:
        raise VaultError("protected-section name is invalid")
    if len(section_key.key) != 32:
        raise VaultError("AES-256-GCM section key must be 32 bytes")
    nonce = secrets.token_bytes(12)
    ciphertext = AESGCM(section_key.key).encrypt(
        nonce,
        plaintext,
        _section_aad(
            entity_id=entity_id,
            manifest_id=manifest_id,
            section_name=section_name,
        ),
    )
    return ProtectedSection(
        key_references=[section_key.key_id],
        nonce=nonce,
        ciphertext=ciphertext,
    )


def decrypt_section(
    section: ProtectedSection,
    *,
    entity_id: str,
    manifest_id: str,
    section_name: str,
    section_key: GeneratedSectionKey,
) -> bytes:
    if section_key.key_id not in section.key_references:
        raise VaultError("provided key is not referenced by the protected section")
    try:
        return AESGCM(section_key.key).decrypt(
            section.nonce,
            section.ciphertext,
            _section_aad(
                entity_id=entity_id,
                manifest_id=manifest_id,
                section_name=section_name,
            ),
        )
    except InvalidTag as exc:
        raise VaultError("protected-section authentication failed") from exc


def protect_section_revision(
    predecessor: ParsedArtifact,
    *,
    section_name: str,
    plaintext: bytes,
    section_key: GeneratedSectionKey,
    issued_by_eid: str,
    issued_by_mid: str,
    timestamp: str,
) -> Revision:
    prior = predecessor.revision
    section = encrypt_section(
        plaintext,
        entity_id=prior.entity_id,
        manifest_id=prior.manifest_id,
        section_name=section_name,
        section_key=section_key,
    )
    protected_sections = {**prior.protected_sections, section_name: section}
    return build_successor(
        predecessor,
        issued_by_eid=issued_by_eid,
        issued_by_mid=issued_by_mid,
        issued_at=timestamp,
        updates={"protected_sections": protected_sections},
    )
