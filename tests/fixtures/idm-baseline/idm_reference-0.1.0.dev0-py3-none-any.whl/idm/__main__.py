"""Run the IDM CLI with ``python -m idm``."""

from .cli import main

main()
