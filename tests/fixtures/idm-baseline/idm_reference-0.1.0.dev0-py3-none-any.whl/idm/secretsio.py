"""Conservative loading of passphrases from local files or a terminal."""

from __future__ import annotations

import getpass
import os
import stat
from pathlib import Path

from .errors import FileSafetyError, VaultError

MAX_SECRET_FILE_BYTES = 4096


def read_secret_file(path: Path) -> str:
    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise FileSafetyError(f"cannot safely open secret file {path}") from exc
    try:
        info = os.fstat(descriptor)
        if not stat.S_ISREG(info.st_mode):
            raise FileSafetyError("secret input must be a regular file")
        getuid = getattr(os, "getuid", None)
        if getuid is not None and info.st_uid != getuid():
            raise FileSafetyError("secret input must be owned by the current user")
        if os.name != "nt" and stat.S_IMODE(info.st_mode) & 0o077:
            raise FileSafetyError("secret input must not be accessible by group or others")
        if info.st_size > MAX_SECRET_FILE_BYTES:
            raise FileSafetyError("secret input exceeds the configured size limit")
        raw = os.read(descriptor, MAX_SECRET_FILE_BYTES + 1)
    finally:
        os.close(descriptor)
    if len(raw) > MAX_SECRET_FILE_BYTES:
        raise FileSafetyError("secret input exceeds the configured size limit")
    try:
        value = raw.decode("utf-8").rstrip("\r\n")
    except UnicodeDecodeError as exc:
        raise VaultError("secret input must be UTF-8") from exc
    if "\x00" in value:
        raise VaultError("secret input cannot contain NUL")
    if not value:
        raise VaultError("secret input is empty")
    return value


def obtain_passphrase(path: Path | None, *, confirm: bool) -> str:
    if path is not None:
        return read_secret_file(path)
    first = getpass.getpass("Vault passphrase: ")
    if confirm:
        second = getpass.getpass("Confirm vault passphrase: ")
        if first != second:
            raise VaultError("passphrase confirmation does not match")
    return first
