"""Evidence-preserving relationship graph queries over a verified registry."""

from __future__ import annotations

from collections import deque

from pydantic import Field

from .errors import GraphError
from .models import StrictModel
from .registry import Registry
from .relationships import inverse_relationship
from .revocation import RevocationSet
from .trust import TrustBundle

COUNTERPARTY_REFERENCE_REQUIRED = frozenset(
    {
        "owns",
        "belongs_to",
        "governs",
        "stewards",
        "supervises",
        "operates",
        "hosts",
        "custodies",
        "authorized_by",
        "member_of",
        "has_affiliate",
    }
)


class GraphEdge(StrictModel):
    relationship_id: str
    relationship_type: str
    source_eid: str
    target_eid: str
    source_vid: str
    explicit: bool
    inverse_derived: bool
    trust_state: str
    reference_vid: str | None = None


class GraphPath(StrictModel):
    source_eid: str
    target_eid: str
    edges: list[GraphEdge]
    path_length: int
    inferred: bool
    trusted: bool
    unresolved: list[str] = Field(default_factory=list)


def _edge_from_row(
    row: object,
    *,
    inverse: bool,
    revoked_lineages: set[str],
) -> GraphEdge:
    item = row  # sqlite Row supports mapping access but has no precise public protocol.
    relationship_type = item["relationship_type"]  # type: ignore[index]
    source_eid = item["source_eid"]  # type: ignore[index]
    target_eid = item["target_eid"]  # type: ignore[index]
    if inverse:
        relationship_type = inverse_relationship(relationship_type)
        source_eid, target_eid = target_eid, source_eid
    reference_vid = item["reference_vid"]  # type: ignore[index]
    requires_reference = item["original_type"] in COUNTERPARTY_REFERENCE_REQUIRED  # type: ignore[index]
    target_present = bool(item["target_present"])  # type: ignore[index]
    reference_matches = bool(item["reference_matches"]) and item[  # type: ignore[index]
        "reference_local_role"
    ] == inverse_relationship(item["original_type"])  # type: ignore[index]
    if (
        item["source_mid"] in revoked_lineages  # type: ignore[index]
        or item["target_mid"] in revoked_lineages  # type: ignore[index]
    ):
        trust_state = "revoked_lineage"
    elif not target_present:
        trust_state = "missing_target"
    elif requires_reference and not reference_matches:
        trust_state = "missing_or_stale_reference"
    else:
        trust_state = "verified"
    return GraphEdge(
        relationship_id=item["rid"],  # type: ignore[index]
        relationship_type=relationship_type,
        source_eid=source_eid,
        target_eid=target_eid,
        source_vid=item["source_vid"],  # type: ignore[index]
        explicit=not inverse,
        inverse_derived=inverse,
        trust_state=trust_state,
        reference_vid=reference_vid,
    )


class GraphResolver:
    def __init__(
        self,
        registry: Registry,
        trust_bundle: TrustBundle,
        *,
        revocations: RevocationSet | None = None,
        evaluation_time: str | None = None,
    ) -> None:
        self.registry = registry
        self.trust_bundle = trust_bundle
        self.revocations = revocations
        self.evaluation_time = evaluation_time

    def edges(self, *, trusted_only: bool = True) -> list[GraphEdge]:
        audit_errors = self.registry.verify(
            self.trust_bundle,
            evaluation_time=self.evaluation_time,
        )
        if audit_errors:
            raise GraphError(f"registry integrity audit failed: {audit_errors}")
        revoked_lineages = self.registry.revoked_lineages(
            self.trust_bundle,
            revocations=self.revocations,
            evaluation_time=self.evaluation_time,
        )
        rows = self.registry.connection.execute(
            """
            SELECT
                r.*,
                r.relationship_type AS original_type,
                h.vid IS NOT NULL AS target_present,
                rr.target_vid AS reference_vid,
                rr.local_role AS reference_local_role,
                (
                    rr.rid IS NOT NULL
                    AND rr.authoritative_mid = r.source_mid
                    AND rr.authoritative_vid = r.source_vid
                    AND rr.local_role IS NOT NULL
                ) AS reference_matches
            FROM relationships r
            LEFT JOIN heads h
                ON h.mid = r.target_mid AND h.eid = r.target_eid
            LEFT JOIN relationship_references rr
                ON rr.rid = r.rid AND rr.target_mid = r.target_mid
            WHERE r.status = 'active'
            ORDER BY r.rid
            """
        ).fetchall()
        output = [
            edge
            for row in rows
            for edge in (
                _edge_from_row(
                    row,
                    inverse=False,
                    revoked_lineages=revoked_lineages,
                ),
                _edge_from_row(
                    row,
                    inverse=True,
                    revoked_lineages=revoked_lineages,
                ),
            )
        ]
        if trusted_only:
            return [edge for edge in output if edge.trust_state == "verified"]
        return output

    def path(
        self,
        source_eid: str,
        target_eid: str,
        *,
        trusted_only: bool = True,
        allowed_types: set[str] | None = None,
    ) -> GraphPath:
        if source_eid == target_eid:
            return GraphPath(
                source_eid=source_eid,
                target_eid=target_eid,
                edges=[],
                path_length=0,
                inferred=False,
                trusted=True,
            )
        adjacency: dict[str, list[GraphEdge]] = {}
        for edge in self.edges(trusted_only=trusted_only):
            if allowed_types is not None and edge.relationship_type not in allowed_types:
                continue
            adjacency.setdefault(edge.source_eid, []).append(edge)
        pending: deque[tuple[str, list[GraphEdge]]] = deque([(source_eid, [])])
        seen = {source_eid}
        while pending:
            current, path = pending.popleft()
            for edge in adjacency.get(current, []):
                candidate = [*path, edge]
                if edge.target_eid == target_eid:
                    unresolved = [
                        item.relationship_id for item in candidate if item.trust_state != "verified"
                    ]
                    return GraphPath(
                        source_eid=source_eid,
                        target_eid=target_eid,
                        edges=candidate,
                        path_length=len(candidate),
                        inferred=len(candidate) > 1
                        or any(item.inverse_derived for item in candidate),
                        trusted=not unresolved,
                        unresolved=unresolved,
                    )
                if edge.target_eid not in seen:
                    seen.add(edge.target_eid)
                    pending.append((edge.target_eid, candidate))
        raise GraphError("no permitted relationship path was found")

    def parents(self, eid: str, *, trusted_only: bool = True) -> list[GraphEdge]:
        parent_types = {
            "belongs_to",
            "governed_by",
            "owned_by",
            "stewarded_by",
            "supervised_by",
            "member_of",
        }
        return [
            edge
            for edge in self.edges(trusted_only=trusted_only)
            if edge.source_eid == eid and edge.relationship_type in parent_types
        ]

    def children(self, eid: str, *, trusted_only: bool = True) -> list[GraphEdge]:
        child_types = {"governs", "owns", "stewards", "supervises", "has_member"}
        return [
            edge
            for edge in self.edges(trusted_only=trusted_only)
            if edge.source_eid == eid and edge.relationship_type in child_types
        ]
