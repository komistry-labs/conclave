"""Typed IDM failures."""


class IDMError(Exception):
    """Base class for expected IDM failures."""


class IdentifierError(IDMError):
    """An identifier is malformed or has the wrong type."""


class CanonicalEncodingError(IDMError):
    """CBOR is malformed, non-deterministic, unsupported, or exceeds limits."""


class ManifestSchemaError(IDMError):
    """A manifest draft or signed payload violates schema semantics."""


class SignatureError(IDMError):
    """A signature or signature envelope is invalid."""


class TrustError(IDMError):
    """Cryptographic evidence does not establish configured trust."""


class VaultError(IDMError):
    """A key-vault operation failed safely."""


class FileSafetyError(IDMError):
    """A file operation would overwrite or expose security-sensitive data."""


class LineageError(IDMError):
    """A revision violates lineage, continuity, or anti-rollback rules."""


class PolicyError(IDMError):
    """A requested or signed action is not authorized by policy."""


class LifecycleError(IDMError):
    """A lifecycle transition or operation is not permitted."""


class RegistryError(IDMError):
    """The derived registry rejected or could not safely index evidence."""


class GraphError(IDMError):
    """A relationship graph operation is invalid or unresolved."""


class RevocationError(IDMError):
    """Revocation evidence is malformed, unauthorized, or stale."""


class RuntimeAuthorizationError(IDMError):
    """An identity cannot be mounted or authorized for the requested operation."""


class OfflineError(IDMError):
    """Offline evidence is invalid, stale, expired, rolled back, or conflicting."""
