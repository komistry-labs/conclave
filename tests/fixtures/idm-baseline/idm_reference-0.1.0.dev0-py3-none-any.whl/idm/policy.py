"""Small deterministic policy model for signed revision authorization."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field, field_validator

from .container import ParsedArtifact
from .errors import PolicyError
from .lineage import validate_successor
from .models import StrictModel
from .relationships import required_relationship_scope
from .verification import VerificationReport


class ChangeClass(StrEnum):
    GENESIS = "genesis"
    ENTITY_CORE = "entity_core"
    ENTITY_METADATA = "entity_metadata"
    KEYS = "keys"
    RELATIONSHIPS = "relationships"
    AUTHORITY = "authority"
    CAPABILITY_DECLARATION = "capability_declaration"
    CAPABILITY_GOVERNANCE = "capability_governance"
    LIFECYCLE = "lifecycle"
    PROTECTED_SECTIONS = "protected_sections"
    EXTENSIONS = "extensions"


class PolicyRule(StrictModel):
    change: ChangeClass
    allowed_roles: list[str] = Field(min_length=1)
    required_scope: str
    minimum_approvals: int = Field(default=1, ge=1, le=8)
    required_roles: list[str] = Field(default_factory=list)

    @field_validator("change", mode="before")
    @classmethod
    def parse_change(cls, value: object) -> ChangeClass:
        if isinstance(value, ChangeClass):
            return value
        if isinstance(value, str):
            return ChangeClass(value)
        raise ValueError("policy change class must be text")


class PolicyProfile(StrictModel):
    policy_id: str
    version: int = 1
    rules: list[PolicyRule] = Field(min_length=1)

    def rule_for(self, change: ChangeClass) -> PolicyRule:
        matches = [rule for rule in self.rules if rule.change is change]
        if len(matches) != 1:
            raise PolicyError(f"policy must define exactly one rule for {change.value}")
        return matches[0]


class PolicyDecision(StrictModel):
    allowed: bool
    policy_id: str
    changes: list[ChangeClass]
    errors: list[str] = Field(default_factory=list)


KOMISTRY_V1_POLICY = PolicyProfile(
    policy_id="komistry-policy-v1",
    rules=[
        PolicyRule(
            change=ChangeClass.GENESIS,
            allowed_roles=["identity_authority"],
            required_scope="identity.issue",
        ),
        PolicyRule(
            change=ChangeClass.ENTITY_CORE,
            allowed_roles=["identity_authority", "steward"],
            required_scope="identity.core.change",
            minimum_approvals=2,
            required_roles=["identity_authority", "steward"],
        ),
        PolicyRule(
            change=ChangeClass.ENTITY_METADATA,
            allowed_roles=["identity_authority", "founder", "steward"],
            required_scope="manifest.revise",
        ),
        PolicyRule(
            change=ChangeClass.KEYS,
            allowed_roles=["identity_authority", "steward"],
            required_scope="key.rotate",
            minimum_approvals=2,
            required_roles=["identity_authority", "steward"],
        ),
        PolicyRule(
            change=ChangeClass.RELATIONSHIPS,
            allowed_roles=["identity_authority", "steward"],
            required_scope="relationship.manage",
        ),
        PolicyRule(
            change=ChangeClass.AUTHORITY,
            allowed_roles=["identity_authority", "steward"],
            required_scope="policy.manage",
            minimum_approvals=2,
            required_roles=["identity_authority", "steward"],
        ),
        PolicyRule(
            change=ChangeClass.CAPABILITY_DECLARATION,
            allowed_roles=["identity_authority", "operator", "steward"],
            required_scope="capability.declare",
        ),
        PolicyRule(
            change=ChangeClass.CAPABILITY_GOVERNANCE,
            allowed_roles=["identity_authority", "steward"],
            required_scope="capability.grant",
        ),
        PolicyRule(
            change=ChangeClass.LIFECYCLE,
            allowed_roles=["identity_authority", "steward"],
            required_scope="lifecycle.change",
        ),
        PolicyRule(
            change=ChangeClass.PROTECTED_SECTIONS,
            allowed_roles=["custodian", "identity_authority", "steward"],
            required_scope="protected.write",
        ),
        PolicyRule(
            change=ChangeClass.EXTENSIONS,
            allowed_roles=["identity_authority", "operator", "steward"],
            required_scope="manifest.revise",
        ),
    ],
)


def classify_changes(
    predecessor: ParsedArtifact | None, candidate: ParsedArtifact
) -> list[ChangeClass]:
    if predecessor is None:
        if candidate.revision.revision != 1:
            raise PolicyError("a non-genesis revision requires a predecessor")
        genesis_changes = [ChangeClass.GENESIS]
        revision = candidate.revision
        if revision.relationships.authoritative or revision.relationships.references:
            genesis_changes.append(ChangeClass.RELATIONSHIPS)
        if revision.authority.policy_refs or revision.authority.delegation_refs:
            genesis_changes.append(ChangeClass.AUTHORITY)
        if revision.capabilities.declared:
            genesis_changes.append(ChangeClass.CAPABILITY_DECLARATION)
        if revision.capabilities.grants or revision.capabilities.denials:
            genesis_changes.append(ChangeClass.CAPABILITY_GOVERNANCE)
        if revision.protected_sections:
            genesis_changes.append(ChangeClass.PROTECTED_SECTIONS)
        if revision.extensions:
            genesis_changes.append(ChangeClass.EXTENSIONS)
        return genesis_changes
    validate_successor(predecessor, candidate.revision)
    before = predecessor.revision
    after = candidate.revision
    changes: list[ChangeClass] = []
    if (
        before.entity.type != after.entity.type
        or before.entity.canonical_name != after.entity.canonical_name
        or before.entity.external_identifiers != after.entity.external_identifiers
    ):
        changes.append(ChangeClass.ENTITY_CORE)
    if (
        before.entity.display_name != after.entity.display_name
        or before.entity.description != after.entity.description
        or before.entity.aliases != after.entity.aliases
    ):
        changes.append(ChangeClass.ENTITY_METADATA)
    if before.keys != after.keys:
        changes.append(ChangeClass.KEYS)
    if before.relationships != after.relationships:
        changes.append(ChangeClass.RELATIONSHIPS)
    if before.authority != after.authority:
        changes.append(ChangeClass.AUTHORITY)
    if before.capabilities.declared != after.capabilities.declared:
        changes.append(ChangeClass.CAPABILITY_DECLARATION)
    if (
        before.capabilities.grants != after.capabilities.grants
        or before.capabilities.denials != after.capabilities.denials
    ):
        changes.append(ChangeClass.CAPABILITY_GOVERNANCE)
    if before.lifecycle != after.lifecycle:
        changes.append(ChangeClass.LIFECYCLE)
    if before.protected_sections != after.protected_sections:
        changes.append(ChangeClass.PROTECTED_SECTIONS)
    if before.extensions != after.extensions:
        changes.append(ChangeClass.EXTENSIONS)
    if not changes:
        raise PolicyError("successor contains no semantic change")
    return changes


def evaluate_revision_policy(
    predecessor: ParsedArtifact | None,
    candidate: ParsedArtifact,
    verification: VerificationReport,
    *,
    policy: PolicyProfile = KOMISTRY_V1_POLICY,
) -> PolicyDecision:
    changes = classify_changes(predecessor, candidate)
    errors: list[str] = []
    if not verification.trusted:
        errors.append("artifact did not pass cryptographic trust verification")
    eligible_signatures = [item for item in verification.signatures if item.issuer_authorized]
    for change in changes:
        rule = policy.rule_for(change)
        approvals = [
            item
            for item in eligible_signatures
            if item.role in rule.allowed_roles and rule.required_scope in item.scope
        ]
        distinct_kids = {item.kid for item in approvals}
        if len(distinct_kids) < rule.minimum_approvals:
            errors.append(
                f"{change.value} requires {rule.minimum_approvals} independent approval(s) "
                f"with scope {rule.required_scope}"
            )
        roles = {item.role for item in approvals}
        missing_roles = set(rule.required_roles).difference(roles)
        if missing_roles:
            errors.append(f"{change.value} is missing required roles: {sorted(missing_roles)}")

    prior_grants = (
        {}
        if predecessor is None
        else {item.grant_id: item for item in predecessor.revision.capabilities.grants}
    )
    prior_denials = (
        {}
        if predecessor is None
        else {item.denial_id: item for item in predecessor.revision.capabilities.denials}
    )
    governed_grants = [
        item
        for item in candidate.revision.capabilities.grants
        if prior_grants.get(item.grant_id) != item
    ]
    governed_denials = [
        item
        for item in candidate.revision.capabilities.denials
        if prior_denials.get(item.denial_id) != item
    ]
    for grant in governed_grants:
        attributed_signature = any(
            item.issuer_authorized
            and "capability.grant" in item.scope
            and item.signer_eid == grant.granted_by_eid
            and item.signer_mid == grant.granted_by_mid
            for item in verification.signatures
        )
        if not attributed_signature:
            errors.append(f"capability grant {grant.grant_id} is not signed by its named grantor")
    for denial in governed_denials:
        attributed_signature = any(
            item.issuer_authorized
            and "capability.grant" in item.scope
            and item.signer_eid == denial.denied_by_eid
            and item.signer_mid == denial.denied_by_mid
            for item in verification.signatures
        )
        if not attributed_signature:
            errors.append(f"capability denial {denial.denial_id} is not signed by its named denier")
    prior_bindings = (
        set()
        if predecessor is None
        else {
            (item.scheme, item.value) for item in predecessor.revision.entity.external_identifiers
        }
    )
    for binding in candidate.revision.entity.external_identifiers:
        if (binding.scheme, binding.value) in prior_bindings:
            continue
        attributed_signature = any(
            item.issuer_authorized
            and "identity.allocate" in item.scope
            and item.signer_eid == binding.allocation_authority_eid
            and item.signer_mid == binding.allocation_authority_mid
            for item in verification.signatures
        )
        if not attributed_signature:
            errors.append(
                f"external identifier {binding.scheme}:{binding.value} "
                "is not signed by its named allocation authority"
            )
    prior_edges = (
        {}
        if predecessor is None
        else {
            item.relationship_id: item for item in predecessor.revision.relationships.authoritative
        }
    )
    for edge in candidate.revision.relationships.authoritative:
        if prior_edges.get(edge.relationship_id) == edge:
            continue
        required_scope = required_relationship_scope(edge.type)
        if not any(
            item.issuer_authorized and required_scope in item.scope
            for item in verification.signatures
        ):
            errors.append(f"relationship {edge.relationship_id} requires scope {required_scope}")
    prior_references = (
        {}
        if predecessor is None
        else {item.relationship_id: item for item in predecessor.revision.relationships.references}
    )
    for reference in candidate.revision.relationships.references:
        if prior_references.get(reference.relationship_id) == reference:
            continue
        required_scope = required_relationship_scope(reference.local_role)
        if not any(
            item.issuer_authorized and required_scope in item.scope
            for item in verification.signatures
        ):
            errors.append(
                f"relationship reference {reference.relationship_id} "
                f"requires scope {required_scope}"
            )
    return PolicyDecision(
        allowed=not errors,
        policy_id=policy.policy_id,
        changes=changes,
        errors=errors,
    )
