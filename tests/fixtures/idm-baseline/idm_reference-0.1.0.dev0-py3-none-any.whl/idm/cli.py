"""Command-line interface for the IDM reference implementation."""

from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from collections.abc import Sequence
from dataclasses import asdict
from itertools import pairwise
from pathlib import Path
from typing import Any, NoReturn

from pydantic import ValidationError

from .authority import (
    ISSUANCE_KEY_RELATIVE_PATH,
    REGISTRY_KEY_RELATIVE_PATH,
    TRUST_BUNDLE_FILENAME,
    AuthorityPassphrases,
    create_revocation_from_authority,
    initialize_authority,
    issue_from_authority,
    sign_successor_from_authority,
)
from .canonical import MAX_ARTIFACT_BYTES
from .capabilities import (
    declare_capability_revision,
    deny_capability_revision,
    grant_capability_revision,
)
from .container import ParsedArtifact, parse_artifact
from .errors import IDMError, LineageError
from .files import (
    read_bytes_limited,
    write_bytes_exclusive,
    write_json_exclusive,
)
from .graph import GraphResolver
from .keybindings import create_public_key_binding
from .lifecycle import transition_revision
from .lineage import validate_successor
from .manifest import create_draft, load_draft, write_draft
from .models import CapabilityRisk, KeyPurpose, LifecycleState, PublicKeyBinding, Revision
from .offline import TrustedTimeStore, create_offline_bundle, verify_offline_bundle
from .policy import evaluate_revision_policy
from .registry import Registry
from .relationships import (
    add_relationship_reference_revision,
    add_relationship_revision,
    end_relationship_revision,
    required_relationship_scope,
)
from .revocation import RevocationSet, RevocationTargetType
from .runtime import (
    Runtime,
    RuntimeChallenge,
    SessionStore,
    create_challenge,
    sign_subject_proof,
)
from .secretsio import obtain_passphrase
from .timeutil import now_utc
from .trust import decode_public_key, load_trust_bundle
from .vault import decrypt_key, encrypt_key, generate_key, read_key_file, write_key_file
from .verification import VerificationReport, verify_artifact


def _path(value: str) -> Path:
    return Path(value).expanduser()


def _emit(value: Any) -> None:
    print(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False))


def _artifact_bytes(path: Path) -> bytes:
    return read_bytes_limited(path, max_bytes=MAX_ARTIFACT_BYTES)


def _authority_signer_ids(directory: Path) -> tuple[str, str]:
    bundle = load_trust_bundle(directory / TRUST_BUNDLE_FILENAME)
    record = read_key_file(directory / ISSUANCE_KEY_RELATIVE_PATH)
    authority = bundle.find_anchor(record.kid)
    if authority is None:
        raise LineageError("authority issuance delegation cannot be resolved")
    return authority.signer_eid, authority.signer_mid


def _write_authorized_successor(
    predecessor: bytes,
    revision: Revision,
    *,
    authority: Path,
    passphrase_file: Path | None,
    scopes: list[str],
    output: Path,
    revocation_paths: list[Path],
) -> VerificationReport:
    bundle = load_trust_bundle(authority / TRUST_BUNDLE_FILENAME)
    revocations = RevocationSet.from_files(revocation_paths, bundle) if revocation_paths else None
    return sign_successor_from_authority(
        predecessor,
        revision,
        authority,
        passphrase=obtain_passphrase(passphrase_file, confirm=False),
        required_scopes=scopes,
        output_path=output,
        revocations=revocations,
    )


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="idm", description="IDM identity-manifest tools")
    subcommands = parser.add_subparsers(dest="command", required=True)

    def add_revocation_option(command_parser: argparse.ArgumentParser) -> None:
        command_parser.add_argument(
            "--revocation",
            action="append",
            type=_path,
            default=[],
            help="verified revocation evidence; repeat for multiple statements",
        )

    authority = subcommands.add_parser("authority", help="manage an IDM trust authority")
    authority_commands = authority.add_subparsers(dest="authority_command", required=True)
    authority_init = authority_commands.add_parser("init", help="initialize a private trust domain")
    authority_init.add_argument("--name", required=True, help="canonical authority name")
    authority_init.add_argument("--output", required=True, type=_path)
    authority_init.add_argument("--passphrase-file", type=_path)
    authority_init.add_argument("--root-passphrase-file", type=_path)
    authority_init.add_argument("--issuance-passphrase-file", type=_path)
    authority_init.add_argument("--allocation-passphrase-file", type=_path)
    authority_init.add_argument("--revocation-passphrase-file", type=_path)
    authority_init.add_argument("--registry-passphrase-file", type=_path)

    key = subcommands.add_parser("key", help="manage development-vault keys")
    key_commands = key.add_subparsers(dest="key_command", required=True)
    key_generate = key_commands.add_parser("generate", help="generate an encrypted Ed25519 key")
    key_generate.add_argument("--output", required=True, type=_path)
    key_generate.add_argument("--passphrase-file", type=_path)
    key_rotate = key_commands.add_parser(
        "rotate", help="replace a development-vault key without mutating a manifest"
    )
    key_rotate.add_argument("--current", required=True, type=_path)
    key_rotate.add_argument("--output", required=True, type=_path)
    key_rotate.add_argument("--passphrase-file", type=_path)

    create = subcommands.add_parser("create", help="create an unsigned manifest draft")
    create.add_argument("--type", required=True, dest="entity_type")
    create.add_argument("--name", required=True, dest="canonical_name")
    create.add_argument("--display-name")
    create.add_argument("--description")
    create.add_argument("--originator-eid")
    create.add_argument("--originator-mid")
    create.add_argument("--subject-key", type=_path)
    create.add_argument(
        "--key-purpose",
        action="append",
        choices=[item.value for item in KeyPurpose],
        default=[],
    )
    create.add_argument("--output", required=True, type=_path)

    issue = subcommands.add_parser("issue", help="issue a signed genesis manifest")
    issue.add_argument("draft", type=_path)
    issue.add_argument("--authority", required=True, type=_path)
    issue.add_argument("--output", required=True, type=_path)
    issue.add_argument("--passphrase-file", type=_path)
    issue.add_argument(
        "--allocate-kos",
        action="store_true",
        help="allocate the authoritative next K1 value and a new UUIDv7/RID pair",
    )
    add_revocation_option(issue)

    inspect = subcommands.add_parser(
        "inspect", help="inspect a canonical artifact without trusting it"
    )
    inspect.add_argument("artifact", type=_path)

    verify = subcommands.add_parser("verify", help="verify an artifact against a trust bundle")
    verify.add_argument("artifact", type=_path)
    verify.add_argument("--trust", required=True, type=_path)
    verify.add_argument("--revocation", action="append", type=_path, default=[])
    verify.add_argument("--at", dest="evaluation_time")

    revoke = subcommands.add_parser("revoke", help="issue signed external revocation evidence")
    revoke.add_argument("--authority", required=True, type=_path)
    revoke.add_argument(
        "--target-type", required=True, choices=[item.value for item in RevocationTargetType]
    )
    revoke.add_argument("--target-id", required=True)
    revoke.add_argument("--reason", required=True, dest="reason_code")
    revoke.add_argument("--effective-at")
    revoke.add_argument("--replacement-ref")
    revoke.add_argument("--output", required=True, type=_path)
    revoke.add_argument("--passphrase-file", type=_path)
    add_revocation_option(revoke)

    relationship = subcommands.add_parser("relationship", help="create relationship successors")
    relationship_commands = relationship.add_subparsers(dest="relationship_command", required=True)
    relationship_add = relationship_commands.add_parser("add")
    relationship_add.add_argument("source", type=_path)
    relationship_add.add_argument("target", type=_path)
    relationship_add.add_argument("--type", required=True, dest="relationship_type")
    relationship_add.add_argument("--authority", required=True, type=_path)
    relationship_add.add_argument("--output", required=True, type=_path)
    relationship_add.add_argument("--passphrase-file", type=_path)
    add_revocation_option(relationship_add)
    relationship_reference = relationship_commands.add_parser("add-reference")
    relationship_reference.add_argument("target", type=_path)
    relationship_reference.add_argument("authoritative", type=_path)
    relationship_reference.add_argument("--rid", required=True)
    relationship_reference.add_argument("--authority", required=True, type=_path)
    relationship_reference.add_argument("--output", required=True, type=_path)
    relationship_reference.add_argument("--passphrase-file", type=_path)
    add_revocation_option(relationship_reference)
    relationship_remove = relationship_commands.add_parser("remove")
    relationship_remove.add_argument("artifact", type=_path)
    relationship_remove.add_argument("--rid", required=True)
    relationship_remove.add_argument("--authority", required=True, type=_path)
    relationship_remove.add_argument("--output", required=True, type=_path)
    relationship_remove.add_argument("--passphrase-file", type=_path)
    add_revocation_option(relationship_remove)
    relationship_list = relationship_commands.add_parser("list")
    relationship_list.add_argument("artifact", type=_path)

    capability = subcommands.add_parser("capability", help="govern capability successors")
    capability_commands = capability.add_subparsers(dest="capability_command", required=True)
    capability_declare = capability_commands.add_parser("declare")
    capability_declare.add_argument("artifact", type=_path)
    capability_declare.add_argument("capability")
    capability_declare.add_argument("--authority", required=True, type=_path)
    capability_declare.add_argument("--output", required=True, type=_path)
    capability_declare.add_argument("--passphrase-file", type=_path)
    add_revocation_option(capability_declare)
    capability_grant = capability_commands.add_parser("grant")
    capability_grant.add_argument("artifact", type=_path)
    capability_grant.add_argument("capability")
    capability_grant.add_argument("--authority", required=True, type=_path)
    capability_grant.add_argument("--resource", action="append", default=[])
    capability_grant.add_argument(
        "--risk", choices=[item.value for item in CapabilityRisk], default="medium"
    )
    capability_grant.add_argument("--valid-until")
    capability_grant.add_argument("--requires-online", action="store_true")
    capability_grant.add_argument("--max-input-bytes", type=int)
    capability_grant.add_argument("--operation", action="append", default=[])
    capability_grant.add_argument("--output", required=True, type=_path)
    capability_grant.add_argument("--passphrase-file", type=_path)
    add_revocation_option(capability_grant)
    capability_revoke = capability_commands.add_parser("revoke")
    capability_revoke.add_argument("artifact", type=_path)
    capability_revoke.add_argument("capability")
    capability_revoke.add_argument("--reason", required=True)
    capability_revoke.add_argument("--authority", required=True, type=_path)
    capability_revoke.add_argument("--output", required=True, type=_path)
    capability_revoke.add_argument("--passphrase-file", type=_path)
    add_revocation_option(capability_revoke)

    for command_name in ("suspend", "resume", "retire", "archive"):
        lifecycle = subcommands.add_parser(command_name, help=f"create a {command_name} successor")
        lifecycle.add_argument("artifact", type=_path)
        lifecycle.add_argument("--authority", required=True, type=_path)
        lifecycle.add_argument("--output", required=True, type=_path)
        lifecycle.add_argument("--passphrase-file", type=_path)
        add_revocation_option(lifecycle)

    registry = subcommands.add_parser("registry", help="manage a verified SQLite registry")
    registry_commands = registry.add_subparsers(dest="registry_command", required=True)
    registry_add = registry_commands.add_parser("add")
    registry_add.add_argument("artifact", type=_path)
    registry_add.add_argument("--database", required=True, type=_path)
    registry_add.add_argument("--trust", required=True, type=_path)
    add_revocation_option(registry_add)
    registry_sync = registry_commands.add_parser("sync")
    registry_sync.add_argument("artifacts", nargs="+", type=_path)
    registry_sync.add_argument("--database", required=True, type=_path)
    registry_sync.add_argument("--trust", required=True, type=_path)
    add_revocation_option(registry_sync)
    registry_verify = registry_commands.add_parser("verify")
    registry_verify.add_argument("--database", required=True, type=_path)
    registry_verify.add_argument("--trust", required=True, type=_path)
    add_revocation_option(registry_verify)
    registry_checkpoint = registry_commands.add_parser(
        "checkpoint", help="derive a deterministic externally recordable registry checkpoint"
    )
    registry_checkpoint.add_argument("--database", required=True, type=_path)
    registry_checkpoint.add_argument("--trust", required=True, type=_path)
    registry_checkpoint.add_argument(
        "--expected-digest",
        help="fail closed unless the current checkpoint matches retained recovery evidence",
    )
    registry_pin = registry_commands.add_parser(
        "pin", help="pin a migrated or empty registry to one trust-domain genesis"
    )
    registry_pin.add_argument("--database", required=True, type=_path)
    registry_pin.add_argument("--trust", required=True, type=_path)

    graph = subcommands.add_parser("graph", help="query verified relationships")
    graph_commands = graph.add_subparsers(dest="graph_command", required=True)
    for graph_name in ("parents", "children", "authority"):
        graph_query = graph_commands.add_parser(graph_name)
        graph_query.add_argument("eid")
        graph_query.add_argument("--database", required=True, type=_path)
        graph_query.add_argument("--trust", required=True, type=_path)
        graph_query.add_argument("--include-unresolved", action="store_true")
        add_revocation_option(graph_query)
    graph_path = graph_commands.add_parser("path")
    graph_path.add_argument("source_eid")
    graph_path.add_argument("target_eid")
    graph_path.add_argument("--database", required=True, type=_path)
    graph_path.add_argument("--trust", required=True, type=_path)
    graph_path.add_argument("--include-unresolved", action="store_true")
    graph_path.add_argument("--relationship-type", action="append", default=[])
    add_revocation_option(graph_path)

    lineage = subcommands.add_parser("lineage", help="inspect or verify a revision chain")
    lineage_commands = lineage.add_subparsers(dest="lineage_command", required=True)
    for lineage_name in ("show", "verify"):
        lineage_query = lineage_commands.add_parser(lineage_name)
        lineage_query.add_argument("artifacts", nargs="+", type=_path)
        if lineage_name == "verify":
            lineage_query.add_argument("--trust", required=True, type=_path)
            add_revocation_option(lineage_query)

    export_json = subcommands.add_parser("export-json", help="export diagnostic revision JSON")
    export_json.add_argument("artifact", type=_path)
    export_json.add_argument("--output", required=True, type=_path)
    import_json = subcommands.add_parser("import-json", help="strictly import an unsigned draft")
    import_json.add_argument("draft", type=_path)
    import_json.add_argument("--output", required=True, type=_path)

    challenge = subcommands.add_parser("challenge", help="issue or sign runtime challenges")
    challenge_commands = challenge.add_subparsers(dest="challenge_command", required=True)
    challenge_issue = challenge_commands.add_parser("issue")
    challenge_issue.add_argument("artifact", type=_path)
    challenge_issue.add_argument("--runtime-eid", required=True)
    challenge_issue.add_argument("--action", required=True)
    challenge_issue.add_argument("--sessions", required=True, type=_path)
    challenge_issue.add_argument("--ttl", type=int, default=120)
    challenge_issue.add_argument("--output", required=True, type=_path)
    challenge_sign = challenge_commands.add_parser("sign")
    challenge_sign.add_argument("challenge", type=_path)
    challenge_sign.add_argument("--key", required=True, type=_path)
    challenge_sign.add_argument("--output", required=True, type=_path)
    challenge_sign.add_argument("--passphrase-file", type=_path)

    mount = subcommands.add_parser("mount", help="authenticate and mount a read-only identity")
    mount.add_argument("artifact", type=_path)
    mount.add_argument("--proof", required=True, type=_path)
    mount.add_argument("--trust", required=True, type=_path)
    mount.add_argument("--registry", required=True, type=_path)
    mount.add_argument("--sessions", required=True, type=_path)
    mount.add_argument("--runtime-eid", required=True)
    mount.add_argument("--action", required=True)
    mount.add_argument("--capability")
    mount.add_argument("--resource", default="*")
    mount.add_argument("--operation", default="execute")
    mount.add_argument("--input-bytes", type=int, default=0)
    add_revocation_option(mount)

    offline = subcommands.add_parser("offline", help="create or verify signed offline packages")
    offline_commands = offline.add_subparsers(dest="offline_command", required=True)
    offline_pack = offline_commands.add_parser("pack")
    offline_pack.add_argument("artifacts", nargs="+", type=_path)
    offline_pack.add_argument("--authority", required=True, type=_path)
    offline_pack.add_argument("--revocation", action="append", type=_path, default=[])
    offline_pack.add_argument("--sequence", required=True, type=int)
    offline_pack.add_argument("--verified-as-of")
    offline_pack.add_argument("--expires-at", required=True)
    offline_pack.add_argument("--output", required=True, type=_path)
    offline_pack.add_argument("--passphrase-file", type=_path)
    offline_verify = offline_commands.add_parser("verify")
    offline_verify.add_argument("package", type=_path)
    offline_verify.add_argument("--trust", required=True, type=_path)
    offline_verify.add_argument("--at", required=True, dest="evaluation_time")
    offline_verify.add_argument("--time-store", required=True, type=_path)
    return parser


def _run(args: argparse.Namespace) -> int:
    if args.command == "authority" and args.authority_command == "init":
        separated_paths = (
            args.root_passphrase_file,
            args.issuance_passphrase_file,
            args.allocation_passphrase_file,
            args.revocation_passphrase_file,
            args.registry_passphrase_file,
        )
        separated: AuthorityPassphrases | None = None
        legacy: str | None = None
        if any(item is not None for item in separated_paths):
            if args.passphrase_file is not None or any(item is None for item in separated_paths):
                raise IDMError(
                    "separated authority custody requires all five role passphrase files "
                    "and forbids --passphrase-file"
                )
            separated = AuthorityPassphrases(
                root=obtain_passphrase(args.root_passphrase_file, confirm=True),
                issuance=obtain_passphrase(args.issuance_passphrase_file, confirm=True),
                allocation=obtain_passphrase(args.allocation_passphrase_file, confirm=True),
                revocation=obtain_passphrase(args.revocation_passphrase_file, confirm=True),
                registry=obtain_passphrase(args.registry_passphrase_file, confirm=True),
            )
        else:
            legacy = obtain_passphrase(args.passphrase_file, confirm=True)
        authority_result = initialize_authority(
            args.output,
            canonical_name=args.name,
            passphrase=legacy,
            passphrases=separated,
        )
        _emit(
            {
                "authority_eid": authority_result.authority_eid,
                "authority_mid": authority_result.authority_mid,
                "authority_vid": authority_result.authority_vid,
                "directory": str(authority_result.directory),
                "root_kid": authority_result.root_kid,
                "trust_domain_id": authority_result.trust_domain_id,
            }
        )
        return 0
    if args.command == "key" and args.key_command == "generate":
        generated = generate_key()
        record = encrypt_key(
            generated,
            obtain_passphrase(args.passphrase_file, confirm=True),
        )
        write_key_file(args.output, record)
        _emit({"kid": generated.kid, "output": str(args.output)})
        return 0
    if args.command == "key" and args.key_command == "rotate":
        passphrase = obtain_passphrase(args.passphrase_file, confirm=False)
        current = decrypt_key(read_key_file(args.current), passphrase)
        replacement = generate_key()
        write_key_file(args.output, encrypt_key(replacement, passphrase))
        _emit(
            {
                "new_kid": replacement.kid,
                "old_kid": current.kid,
                "output": str(args.output),
                "warning": (
                    "the new public key must be authorized by a governed manifest "
                    "revision or delegation"
                ),
            }
        )
        return 0
    if args.command == "create":
        keys: list[PublicKeyBinding] = []
        if args.subject_key is not None:
            record = read_key_file(args.subject_key)
            purposes = (
                [KeyPurpose(item) for item in args.key_purpose]
                if args.key_purpose
                else [KeyPurpose.SUBJECT_CONTROL, KeyPurpose.OPERATION]
            )
            keys.append(
                create_public_key_binding(
                    decode_public_key(record.public_key),
                    purposes=purposes,
                    valid_from=now_utc(),
                )
            )
        draft = create_draft(
            entity_type=args.entity_type,
            canonical_name=args.canonical_name,
            display_name=args.display_name,
            description=args.description,
            originator_eid=args.originator_eid,
            originator_mid=args.originator_mid,
            keys=keys,
        )
        write_draft(args.output, draft)
        _emit(
            {
                "entity_id": draft.entity_id,
                "manifest_id": draft.manifest_id,
                "output": str(args.output),
            }
        )
        return 0
    if args.command == "issue":
        bundle = load_trust_bundle(args.authority / TRUST_BUNDLE_FILENAME)
        revocations = RevocationSet.from_files(args.revocation, bundle) if args.revocation else None
        report = issue_from_authority(
            args.draft,
            args.authority,
            passphrase=obtain_passphrase(args.passphrase_file, confirm=False),
            output_path=args.output,
            revocations=revocations,
            allocate_kos=args.allocate_kos,
        )
        _emit(report.model_dump(mode="json"))
        return 0
    if args.command == "inspect":
        inspected_artifact = parse_artifact(
            read_bytes_limited(args.artifact, max_bytes=MAX_ARTIFACT_BYTES)
        )
        _emit(
            {
                "revision": inspected_artifact.revision.model_dump(mode="json"),
                "signatures": [
                    {"kid": item.kid, **item.metadata.model_dump(mode="json")}
                    for item in inspected_artifact.signatures
                ],
                "warning": "inspection establishes structure, not trust",
                "vid": inspected_artifact.vid,
            }
        )
        return 0
    if args.command == "verify":
        bundle = load_trust_bundle(args.trust)
        revocations = RevocationSet.from_files(args.revocation, bundle) if args.revocation else None
        report = verify_artifact(
            read_bytes_limited(args.artifact, max_bytes=MAX_ARTIFACT_BYTES),
            bundle,
            revocations=revocations,
            evaluation_time=args.evaluation_time,
        )
        _emit(report.model_dump(mode="json"))
        return 0 if report.trusted else 2
    if args.command == "revoke":
        bundle = load_trust_bundle(args.authority / TRUST_BUNDLE_FILENAME)
        revocations = RevocationSet.from_files(args.revocation, bundle) if args.revocation else None
        verified = create_revocation_from_authority(
            args.authority,
            passphrase=obtain_passphrase(args.passphrase_file, confirm=False),
            target_type=RevocationTargetType(args.target_type),
            target_id=args.target_id,
            reason_code=args.reason_code,
            output_path=args.output,
            effective_at=args.effective_at,
            replacement_ref=args.replacement_ref,
            revocations=revocations,
        )
        _emit(
            {
                "evidence_id": verified.evidence_id,
                "output": str(args.output),
                "revocation": verified.statement.model_dump(mode="json"),
                "signer_kid": verified.signer_kid,
            }
        )
        return 0
    if args.command == "relationship":
        timestamp = now_utc()
        if args.relationship_command == "list":
            revision = parse_artifact(_artifact_bytes(args.artifact)).revision
            _emit(revision.relationships.model_dump(mode="json"))
            return 0
        if args.relationship_command == "add":
            predecessor = _artifact_bytes(args.source)
            target = parse_artifact(_artifact_bytes(args.target))
            signer_eid, signer_mid = _authority_signer_ids(args.authority)
            revision, rid = add_relationship_revision(
                parse_artifact(predecessor),
                relationship_type=args.relationship_type,
                target_eid=target.revision.entity_id,
                target_mid=target.revision.manifest_id,
                issued_by_eid=signer_eid,
                issued_by_mid=signer_mid,
                timestamp=timestamp,
            )
            report = _write_authorized_successor(
                predecessor,
                revision,
                authority=args.authority,
                passphrase_file=args.passphrase_file,
                scopes=[
                    "relationship.manage",
                    required_relationship_scope(args.relationship_type),
                ],
                output=args.output,
                revocation_paths=args.revocation,
            )
            _emit({"relationship_id": rid, "verification": report.model_dump(mode="json")})
            return 0
        if args.relationship_command == "add-reference":
            predecessor = _artifact_bytes(args.target)
            signer_eid, signer_mid = _authority_signer_ids(args.authority)
            revision = add_relationship_reference_revision(
                parse_artifact(predecessor),
                authoritative_artifact=parse_artifact(_artifact_bytes(args.authoritative)),
                relationship_id=args.rid,
                issued_by_eid=signer_eid,
                issued_by_mid=signer_mid,
                timestamp=timestamp,
            )
            report = _write_authorized_successor(
                predecessor,
                revision,
                authority=args.authority,
                passphrase_file=args.passphrase_file,
                scopes=[
                    "relationship.manage",
                    required_relationship_scope(revision.relationships.references[-1].local_role),
                ],
                output=args.output,
                revocation_paths=args.revocation,
            )
            _emit(report.model_dump(mode="json"))
            return 0
        if args.relationship_command == "remove":
            predecessor = _artifact_bytes(args.artifact)
            predecessor_artifact = parse_artifact(predecessor)
            signer_eid, signer_mid = _authority_signer_ids(args.authority)
            revision = end_relationship_revision(
                predecessor_artifact,
                relationship_id=args.rid,
                issued_by_eid=signer_eid,
                issued_by_mid=signer_mid,
                timestamp=timestamp,
            )
            report = _write_authorized_successor(
                predecessor,
                revision,
                authority=args.authority,
                passphrase_file=args.passphrase_file,
                scopes=[
                    "relationship.manage",
                    required_relationship_scope(
                        next(
                            item.type
                            for item in predecessor_artifact.revision.relationships.authoritative
                            if item.relationship_id == args.rid
                        )
                    ),
                ],
                output=args.output,
                revocation_paths=args.revocation,
            )
            _emit(report.model_dump(mode="json"))
            return 0
    if args.command == "capability":
        timestamp = now_utc()
        predecessor = _artifact_bytes(args.artifact)
        signer_eid, signer_mid = _authority_signer_ids(args.authority)
        if args.capability_command == "declare":
            revision = declare_capability_revision(
                parse_artifact(predecessor),
                capability=args.capability,
                issued_by_eid=signer_eid,
                issued_by_mid=signer_mid,
                timestamp=timestamp,
            )
            scopes = ["capability.declare"]
            evidence_id = None
        elif args.capability_command == "grant":
            constraints: dict[str, Any] = {}
            if args.requires_online:
                constraints["requires_online"] = True
            if args.max_input_bytes is not None:
                constraints["max_input_bytes"] = args.max_input_bytes
            if args.operation:
                constraints["allowed_operations"] = args.operation
            revision, evidence_id = grant_capability_revision(
                parse_artifact(predecessor),
                capability=args.capability,
                granted_by_eid=signer_eid,
                granted_by_mid=signer_mid,
                issued_by_eid=signer_eid,
                issued_by_mid=signer_mid,
                timestamp=timestamp,
                resource_scope=args.resource or ["*"],
                valid_until=args.valid_until,
                risk=CapabilityRisk(args.risk),
                constraints=constraints,
            )
            scopes = ["capability.grant"]
        else:
            revision, evidence_id = deny_capability_revision(
                parse_artifact(predecessor),
                capability=args.capability,
                denied_by_eid=signer_eid,
                denied_by_mid=signer_mid,
                issued_by_eid=signer_eid,
                issued_by_mid=signer_mid,
                timestamp=timestamp,
                reason_code=args.reason,
            )
            scopes = ["capability.grant"]
        report = _write_authorized_successor(
            predecessor,
            revision,
            authority=args.authority,
            passphrase_file=args.passphrase_file,
            scopes=scopes,
            output=args.output,
            revocation_paths=args.revocation,
        )
        _emit(
            {
                "evidence_id": evidence_id,
                "verification": report.model_dump(mode="json"),
            }
        )
        return 0
    if args.command in {"suspend", "resume", "retire", "archive"}:
        targets = {
            "suspend": LifecycleState.SUSPENDED,
            "resume": LifecycleState.ACTIVE,
            "retire": LifecycleState.RETIRED,
            "archive": LifecycleState.ARCHIVED,
        }
        predecessor = _artifact_bytes(args.artifact)
        signer_eid, signer_mid = _authority_signer_ids(args.authority)
        revision = transition_revision(
            parse_artifact(predecessor),
            target=targets[args.command],
            issued_by_eid=signer_eid,
            issued_by_mid=signer_mid,
            timestamp=now_utc(),
        )
        report = _write_authorized_successor(
            predecessor,
            revision,
            authority=args.authority,
            passphrase_file=args.passphrase_file,
            scopes=["lifecycle.change"],
            output=args.output,
            revocation_paths=args.revocation,
        )
        _emit(report.model_dump(mode="json"))
        return 0
    if args.command == "registry":
        bundle = load_trust_bundle(args.trust)
        revocation_paths = getattr(args, "revocation", [])
        revocations = (
            RevocationSet.from_files(revocation_paths, bundle) if revocation_paths else None
        )
        with Registry(args.database) as registry:
            if args.registry_command == "add":
                registry_result = registry.add_file(
                    args.artifact,
                    bundle,
                    revocations=revocations,
                )
                _emit(asdict(registry_result))
                return 0
            if args.registry_command == "sync":
                _emit(
                    [
                        asdict(item)
                        for item in registry.sync(
                            args.artifacts,
                            bundle,
                            revocations=revocations,
                        )
                    ]
                )
                return 0
            if args.registry_command == "checkpoint":
                checkpoint = (
                    registry.assert_checkpoint(bundle, args.expected_digest)
                    if args.expected_digest
                    else registry.checkpoint(bundle)
                )
                _emit(asdict(checkpoint))
                return 0
            if args.registry_command == "pin":
                registry.pin_trust_domain(bundle)
                _emit(asdict(registry.checkpoint(bundle)))
                return 0
            errors = registry.verify(bundle)
            revoked_lineages = sorted(
                registry.revoked_lineages(
                    bundle,
                    revocations=revocations,
                )
            )
            _emit(
                {
                    "errors": errors,
                    "revoked_lineages": revoked_lineages,
                    "verified": not errors,
                }
            )
            return 0 if not errors else 2
    if args.command == "graph":
        bundle = load_trust_bundle(args.trust)
        revocations = RevocationSet.from_files(args.revocation, bundle) if args.revocation else None
        with Registry(args.database) as registry:
            resolver = GraphResolver(registry, bundle, revocations=revocations)
            trusted_only = not args.include_unresolved
            if args.graph_command == "path":
                graph_result = resolver.path(
                    args.source_eid,
                    args.target_eid,
                    trusted_only=trusted_only,
                    allowed_types=set(args.relationship_type) if args.relationship_type else None,
                )
                _emit(graph_result.model_dump(mode="json"))
                return 0
            if args.graph_command == "children":
                edges = resolver.children(args.eid, trusted_only=trusted_only)
            else:
                edges = resolver.parents(args.eid, trusted_only=trusted_only)
                if args.graph_command == "authority":
                    authority_types = {
                        "belongs_to",
                        "governed_by",
                        "owned_by",
                        "stewarded_by",
                    }
                    edges = [edge for edge in edges if edge.relationship_type in authority_types]
            _emit([edge.model_dump(mode="json") for edge in edges])
            return 0
    if args.command == "lineage":
        parsed = [parse_artifact(_artifact_bytes(path)) for path in args.artifacts]
        parsed.sort(key=lambda item: item.revision.revision)
        mids = {item.revision.manifest_id for item in parsed}
        if len(mids) != 1:
            raise LineageError("lineage command requires exactly one MID")
        if args.lineage_command == "verify":
            bundle = load_trust_bundle(args.trust)
            revocations = (
                RevocationSet.from_files(args.revocation, bundle) if args.revocation else None
            )
            lineage_predecessor: ParsedArtifact | None = None
            for item in parsed:
                report = verify_artifact(
                    item.exact_bytes,
                    bundle,
                    revocations=revocations,
                )
                if not report.trusted:
                    raise LineageError(f"untrusted lineage artifact {item.vid}: {report.errors}")
                decision = evaluate_revision_policy(lineage_predecessor, item, report)
                if not decision.allowed:
                    raise LineageError(
                        f"lineage artifact {item.vid} failed policy: {decision.errors}"
                    )
                lineage_predecessor = item
        else:
            for previous_item, next_item in pairwise(parsed):
                validate_successor(previous_item, next_item.revision)
        _emit(
            [
                {
                    "issued_at": item.revision.issued_at,
                    "predecessor_vid": item.revision.predecessor_vid,
                    "revision": item.revision.revision,
                    "vid": item.vid,
                }
                for item in parsed
            ]
        )
        return 0
    if args.command == "export-json":
        exported_artifact = parse_artifact(_artifact_bytes(args.artifact))
        write_json_exclusive(args.output, exported_artifact.revision.model_dump(mode="json"))
        _emit(
            {
                "output": str(args.output),
                "vid": exported_artifact.vid,
                "warning": "diagnostic only",
            }
        )
        return 0
    if args.command == "import-json":
        draft = load_draft(args.draft)
        write_draft(args.output, draft)
        _emit({"entity_id": draft.entity_id, "manifest_id": draft.manifest_id})
        return 0
    if args.command == "challenge":
        if args.challenge_command == "issue":
            challenge_artifact_bytes = _artifact_bytes(args.artifact)
            challenge = create_challenge(
                challenge_artifact_bytes,
                runtime_eid=args.runtime_eid,
                action=args.action,
                ttl_seconds=args.ttl,
            )
            with SessionStore(args.sessions) as sessions:
                sessions.record(challenge)
            write_json_exclusive(args.output, challenge.model_dump(mode="json"))
            _emit({"output": str(args.output), "session_id": challenge.session_id})
            return 0
        challenge = RuntimeChallenge.model_validate_json(
            read_bytes_limited(args.challenge, max_bytes=64 * 1024)
        )
        key = decrypt_key(
            read_key_file(args.key), obtain_passphrase(args.passphrase_file, confirm=False)
        )
        proof = sign_subject_proof(challenge, private_key=key.private_key, kid=key.kid)
        write_bytes_exclusive(args.output, proof)
        _emit({"kid": key.kid, "output": str(args.output)})
        return 0
    if args.command == "mount":
        mount_artifact_bytes = _artifact_bytes(args.artifact)
        bundle = load_trust_bundle(args.trust)
        revocations = RevocationSet.from_files(args.revocation, bundle) if args.revocation else None
        with (
            Registry(args.registry) as registry,
            SessionStore(args.sessions) as sessions,
        ):
            runtime = Runtime(
                runtime_eid=args.runtime_eid,
                registry=registry,
                sessions=sessions,
            )
            context = runtime.mount(
                mount_artifact_bytes,
                trust_bundle=bundle,
                subject_proof=_artifact_bytes(args.proof),
                expected_action=args.action,
                revocations=revocations,
                capability=args.capability,
                resource=args.resource,
                operation=args.operation,
                input_bytes=args.input_bytes,
            )
        context_output = asdict(context)
        context_output["capabilities"] = [
            item.model_dump(mode="json") for item in context.capabilities
        ]
        _emit(context_output)
        return 0
    if args.command == "offline":
        if args.offline_command == "pack":
            trust = load_trust_bundle(args.authority / TRUST_BUNDLE_FILENAME)
            key = decrypt_key(
                read_key_file(args.authority / REGISTRY_KEY_RELATIVE_PATH),
                obtain_passphrase(args.passphrase_file, confirm=False),
            )
            timestamp = args.verified_as_of or now_utc()
            package = create_offline_bundle(
                trust_bundle=trust,
                artifact_bytes=[_artifact_bytes(path) for path in args.artifacts],
                revocation_bytes=[_artifact_bytes(path) for path in args.revocation],
                sequence=args.sequence,
                generated_at=timestamp,
                verified_as_of=timestamp,
                expires_at=args.expires_at,
                private_key=key.private_key,
                kid=key.kid,
            )
            verified_package = verify_offline_bundle(
                package, pinned_trust=trust, evaluation_time=timestamp
            )
            write_bytes_exclusive(args.output, package)
            _emit(
                {
                    "bundle_id": verified_package.payload.bundle_id,
                    "evidence_id": verified_package.evidence_id,
                    "heads": verified_package.payload.heads,
                    "output": str(args.output),
                }
            )
            return 0
        trust = load_trust_bundle(args.trust)
        with TrustedTimeStore(args.time_store) as time_store:
            verified_package = verify_offline_bundle(
                _artifact_bytes(args.package),
                pinned_trust=trust,
                evaluation_time=args.evaluation_time,
                time_store=time_store,
            )
        _emit(
            {
                "bundle_id": verified_package.payload.bundle_id,
                "evidence_id": verified_package.evidence_id,
                "expires_at": verified_package.payload.expires_at,
                "heads": verified_package.payload.heads,
                "verified_as_of": verified_package.payload.verified_as_of,
            }
        )
        return 0
    raise AssertionError("unreachable command")


def run(argv: Sequence[str] | None = None) -> int:
    parser = _build_parser()
    try:
        return _run(parser.parse_args(argv))
    except (IDMError, ValidationError, sqlite3.Error) as exc:
        print(f"idm: {exc}", file=sys.stderr)
        return 1


def main() -> NoReturn:
    raise SystemExit(run())
