"""Strict COSE_Sign1 envelope for signed non-manifest IDM evidence."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import cbor2

from . import canonical
from .crypto import sign as ed25519_sign
from .crypto import verify as ed25519_verify
from .errors import SignatureError
from .identifiers import derive_vid, validate_kid

COSE_SIGN1_TAG = 18
COSE_ALG = 1
COSE_CONTENT_TYPE = 3
COSE_KID = 4
COSE_EDDSA = -8
CONTENT_TYPE = "application/idm-evidence+cbor"
EVIDENCE_FORMAT = 1
_BODY_KEYS: set[int | str] = {COSE_CONTENT_TYPE, "idm_format", "idm_context"}
_SIGNATURE_KEYS: set[int | str] = {COSE_ALG, COSE_KID}


@dataclass(frozen=True, slots=True)
class ParsedAttestation:
    exact_bytes: bytes
    evidence_id: str
    context: str
    kid: str
    protected: bytes
    payload_bytes: bytes
    payload: dict[str, Any]
    signature: bytes


def _signature_structure(protected: bytes, payload: bytes) -> bytes:
    return canonical.dumps(["Signature1", protected, b"", payload])


def encode_attestation(
    payload: dict[str, Any],
    *,
    context: str,
    private_key: bytes,
    kid: str,
) -> bytes:
    validate_kid(kid)
    canonical.validate_profile(payload)
    payload_bytes = canonical.dumps(payload)
    protected = canonical.dumps(
        {
            COSE_CONTENT_TYPE: CONTENT_TYPE,
            "idm_format": EVIDENCE_FORMAT,
            "idm_context": context,
            COSE_ALG: COSE_EDDSA,
            COSE_KID: kid.encode("ascii"),
        }
    )
    signature = ed25519_sign(private_key, _signature_structure(protected, payload_bytes))
    envelope = cbor2.CBORTag(COSE_SIGN1_TAG, [protected, {}, payload_bytes, signature])
    canonical.validate_profile(envelope, allow_tags={COSE_SIGN1_TAG}, allow_integer_keys=True)
    return canonical.dumps(envelope)


def parse_attestation(data: bytes, *, expected_context: str) -> ParsedAttestation:
    top = canonical.load_canonical(
        data,
        allow_tags={COSE_SIGN1_TAG},
        allow_integer_keys=True,
        max_bytes=canonical.MAX_ARTIFACT_BYTES,
    )
    if not isinstance(top, cbor2.CBORTag) or top.tag != COSE_SIGN1_TAG:
        raise SignatureError("evidence is not a tagged COSE_Sign1 structure")
    if not isinstance(top.value, (list, tuple)) or len(top.value) != 4:
        raise SignatureError("malformed COSE_Sign1 structure")
    protected, unprotected, payload_bytes, signature = top.value
    if not isinstance(protected, bytes) or unprotected != {}:
        raise SignatureError("IDM evidence requires protected headers only")
    headers = canonical.load_canonical(protected, allow_integer_keys=True, max_bytes=64 * 1024)
    if not isinstance(headers, dict) or set(headers) != _BODY_KEYS | _SIGNATURE_KEYS:
        raise SignatureError("evidence protected header set is unsupported")
    if (
        headers[COSE_CONTENT_TYPE] != CONTENT_TYPE
        or headers["idm_format"] != EVIDENCE_FORMAT
        or headers["idm_context"] != expected_context
        or headers[COSE_ALG] != COSE_EDDSA
        or not isinstance(headers[COSE_KID], bytes)
    ):
        raise SignatureError("evidence profile or context is unsupported")
    try:
        kid = headers[COSE_KID].decode("ascii")
    except UnicodeDecodeError as exc:
        raise SignatureError("evidence KID must be ASCII") from exc
    validate_kid(kid)
    if not isinstance(payload_bytes, bytes):
        raise SignatureError("detached evidence payloads are not allowed")
    payload = canonical.load_canonical(payload_bytes)
    if not isinstance(payload, dict):
        raise SignatureError("evidence payload must be a map")
    if not isinstance(signature, bytes) or len(signature) != 64:
        raise SignatureError("evidence Ed25519 signature must be 64 bytes")
    return ParsedAttestation(
        exact_bytes=data,
        evidence_id=derive_vid(data).replace("vid:", "evidence:", 1),
        context=expected_context,
        kid=kid,
        protected=protected,
        payload_bytes=payload_bytes,
        payload=payload,
        signature=signature,
    )


def verify_attestation(attestation: ParsedAttestation, public_key: bytes) -> None:
    ed25519_verify(
        public_key,
        attestation.signature,
        _signature_structure(attestation.protected, attestation.payload_bytes),
    )
