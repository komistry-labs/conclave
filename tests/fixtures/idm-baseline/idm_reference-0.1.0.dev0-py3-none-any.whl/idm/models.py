"""Strict IDM v1 domain models."""

from __future__ import annotations

import base64
from enum import StrEnum
from typing import Any, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .identifiers import (
    derive_kid,
    validate_eid,
    validate_k1_allocation_number,
    validate_kid,
    validate_mid,
    validate_rid,
    validate_uuid7_urn,
    validate_vid,
)
from .timeutil import validate_timestamp


class StrictModel(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        strict=True,
        frozen=True,
        validate_by_alias=True,
        validate_by_name=True,
        serialize_by_alias=True,
        ser_json_bytes="base64",
        val_json_bytes="base64",
    )


class LifecycleState(StrEnum):
    DRAFT = "draft"
    ISSUED = "issued"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    RETIRED = "retired"
    ARCHIVED = "archived"
    REVOKED = "revoked"


class RelationshipStatus(StrEnum):
    ACTIVE = "active"
    ENDED = "ended"


class KeyPurpose(StrEnum):
    SUBJECT_CONTROL = "subject_control"
    OPERATION = "operation"
    RUNTIME_SESSION = "runtime_session"
    SECTION_ENCRYPTION = "section_encryption"
    RECOVERY = "recovery"


class CapabilityRisk(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class PublicKeyBinding(StrictModel):
    kid: str
    algorithm: Literal["Ed25519"] = "Ed25519"
    public_key: str
    purposes: list[KeyPurpose] = Field(min_length=1)
    valid_from: str
    valid_until: str | None = None

    @field_validator("kid")
    @classmethod
    def check_kid(cls, value: str) -> str:
        return validate_kid(value)

    @field_validator("valid_from", "valid_until")
    @classmethod
    def check_time(cls, value: str | None) -> str | None:
        return None if value is None else validate_timestamp(value)

    @field_validator("purposes", mode="before")
    @classmethod
    def parse_purposes(cls, value: object) -> object:
        if not isinstance(value, (list, tuple)):
            raise ValueError("key purposes must be an array")
        return [item if isinstance(item, KeyPurpose) else KeyPurpose(item) for item in value]

    @model_validator(mode="after")
    def validate_binding(self) -> Self:
        try:
            public_key = base64.b64decode(self.public_key, validate=True)
        except ValueError as exc:
            raise ValueError("public key must be canonical base64") from exc
        if len(public_key) != 32 or derive_kid(public_key) != self.kid:
            raise ValueError("public key does not match its Ed25519 KID")
        if len(self.purposes) != len(set(self.purposes)):
            raise ValueError("key purposes must be unique")
        if self.valid_until is not None and self.valid_until < self.valid_from:
            raise ValueError("key-binding validity interval is inverted")
        return self


class ExternalIdentifierBinding(StrictModel):
    scheme: str = Field(min_length=1, max_length=64, pattern=r"^[a-z][a-z0-9_.-]*$")
    value: str = Field(min_length=1, max_length=512)
    allocation_event_id: str
    allocation_authority_eid: str
    allocation_authority_mid: str

    @field_validator("allocation_event_id")
    @classmethod
    def check_event_id(cls, value: str) -> str:
        return validate_rid(value)

    @field_validator("allocation_authority_eid")
    @classmethod
    def check_authority_eid(cls, value: str) -> str:
        return validate_eid(value)

    @field_validator("allocation_authority_mid")
    @classmethod
    def check_authority_mid(cls, value: str) -> str:
        return validate_mid(value)

    @model_validator(mode="after")
    def validate_binding(self) -> Self:
        if self.scheme == "kos-canonical-id":
            validate_uuid7_urn(self.value)
        elif self.scheme == "kos-allocation-number":
            validate_k1_allocation_number(self.value)
        return self


class Entity(StrictModel):
    type: str = Field(min_length=1, max_length=64, pattern=r"^[a-z][a-z0-9_-]*$")
    canonical_name: str = Field(min_length=1, max_length=256)
    display_name: str = Field(min_length=1, max_length=256)
    description: str | None = Field(default=None, max_length=4096)
    aliases: list[str] = Field(default_factory=list, max_length=64)
    external_identifiers: list[ExternalIdentifierBinding] = Field(
        default_factory=list, max_length=64
    )

    @field_validator("aliases")
    @classmethod
    def validate_aliases(cls, value: list[str]) -> list[str]:
        if len(set(value)) != len(value):
            raise ValueError("aliases must be unique")
        if any(not alias or len(alias) > 256 for alias in value):
            raise ValueError("aliases must contain 1 to 256 characters")
        return value

    @model_validator(mode="after")
    def unique_external_identifiers(self) -> Self:
        identifiers = [(item.scheme, item.value) for item in self.external_identifiers]
        if len(identifiers) != len(set(identifiers)):
            raise ValueError("external identifier bindings must be unique")
        canonical = [
            item for item in self.external_identifiers if item.scheme == "kos-canonical-id"
        ]
        allocation = [
            item for item in self.external_identifiers if item.scheme == "kos-allocation-number"
        ]
        if canonical or allocation:
            if len(canonical) != 1 or len(allocation) != 1:
                raise ValueError(
                    "KOS identity requires exactly one canonical ID and one allocation number"
                )
            canonical_authority = (
                canonical[0].allocation_event_id,
                canonical[0].allocation_authority_eid,
                canonical[0].allocation_authority_mid,
            )
            allocation_authority = (
                allocation[0].allocation_event_id,
                allocation[0].allocation_authority_eid,
                allocation[0].allocation_authority_mid,
            )
            if canonical_authority != allocation_authority:
                raise ValueError(
                    "KOS canonical ID and allocation number must share one allocation record"
                )
        return self


class DraftOrigin(StrictModel):
    originator_eid: str | None = None
    originator_mid: str | None = None
    enrollment_profile: str = Field(
        default="komistry-institutional-v1", min_length=1, max_length=128
    )

    @field_validator("originator_eid")
    @classmethod
    def check_eid(cls, value: str | None) -> str | None:
        return None if value is None else validate_eid(value)

    @field_validator("originator_mid")
    @classmethod
    def check_mid(cls, value: str | None) -> str | None:
        return None if value is None else validate_mid(value)

    @model_validator(mode="after")
    def pair_originator(self) -> Self:
        if (self.originator_eid is None) != (self.originator_mid is None):
            raise ValueError("originator EID and MID must both be present or absent")
        return self


class Origin(StrictModel):
    originator_eid: str | None = None
    originator_mid: str | None = None
    issued_by_eid: str
    issued_by_mid: str
    enrollment_profile: str = Field(min_length=1, max_length=128)

    @field_validator("originator_eid", "issued_by_eid")
    @classmethod
    def check_eid(cls, value: str | None) -> str | None:
        return None if value is None else validate_eid(value)

    @field_validator("originator_mid", "issued_by_mid")
    @classmethod
    def check_mid(cls, value: str | None) -> str | None:
        return None if value is None else validate_mid(value)

    @model_validator(mode="after")
    def pair_originator(self) -> Self:
        if (self.originator_eid is None) != (self.originator_mid is None):
            raise ValueError("originator EID and MID must both be present or absent")
        return self


class Relationship(StrictModel):
    relationship_id: str
    type: str = Field(min_length=1, max_length=64, pattern=r"^[a-z][a-z0-9_]*$")
    source_eid: str
    source_mid: str
    target_eid: str
    target_mid: str
    effective_from: str
    effective_until: str | None = None
    status: RelationshipStatus = RelationshipStatus.ACTIVE
    constraints: dict[str, Any] = Field(default_factory=dict)

    @field_validator("relationship_id")
    @classmethod
    def check_rid(cls, value: str) -> str:
        return validate_rid(value)

    @field_validator("source_eid", "target_eid")
    @classmethod
    def check_eid(cls, value: str) -> str:
        return validate_eid(value)

    @field_validator("source_mid", "target_mid")
    @classmethod
    def check_mid(cls, value: str) -> str:
        return validate_mid(value)

    @field_validator("effective_from", "effective_until")
    @classmethod
    def check_time(cls, value: str | None) -> str | None:
        return None if value is None else validate_timestamp(value)

    @field_validator("status", mode="before")
    @classmethod
    def parse_status(cls, value: object) -> RelationshipStatus:
        if isinstance(value, RelationshipStatus):
            return value
        if isinstance(value, str):
            return RelationshipStatus(value)
        raise ValueError("relationship status must be a supported text value")

    @model_validator(mode="after")
    def validate_interval(self) -> Self:
        if self.effective_until is not None and self.effective_until < self.effective_from:
            raise ValueError("relationship end cannot precede start")
        return self


class RelationshipReference(StrictModel):
    relationship_id: str
    authoritative_mid: str
    authoritative_vid: str | None = None
    local_role: str = Field(min_length=1, max_length=64)

    @field_validator("relationship_id")
    @classmethod
    def check_rid(cls, value: str) -> str:
        return validate_rid(value)

    @field_validator("authoritative_mid")
    @classmethod
    def check_mid(cls, value: str) -> str:
        return validate_mid(value)

    @field_validator("authoritative_vid")
    @classmethod
    def check_vid(cls, value: str | None) -> str | None:
        return None if value is None else validate_vid(value)


class Relationships(StrictModel):
    authoritative: list[Relationship] = Field(default_factory=list)
    references: list[RelationshipReference] = Field(default_factory=list)

    @model_validator(mode="after")
    def unique_relationships(self) -> Self:
        ids = [item.relationship_id for item in self.authoritative]
        ids.extend(item.relationship_id for item in self.references)
        if len(ids) != len(set(ids)):
            raise ValueError("relationship IDs must be unique within a manifest")
        return self


class AuthorityRefs(StrictModel):
    policy_refs: list[str] = Field(default_factory=list)
    delegation_refs: list[str] = Field(default_factory=list)


class CapabilityGrant(StrictModel):
    grant_id: str
    capability: str = Field(min_length=1, max_length=256, pattern=r"^[a-z][a-z0-9_.:-]*$")
    granted_by_eid: str
    granted_by_mid: str
    grantee_eid: str
    grantee_mid: str
    resource_scope: list[str] = Field(default_factory=lambda: ["*"])
    valid_from: str
    valid_until: str | None = None
    risk: CapabilityRisk = CapabilityRisk.MEDIUM
    constraints: dict[str, Any] = Field(default_factory=dict)

    @field_validator("grant_id")
    @classmethod
    def check_rid(cls, value: str) -> str:
        return validate_rid(value)

    @field_validator("granted_by_eid", "grantee_eid")
    @classmethod
    def check_eid(cls, value: str) -> str:
        return validate_eid(value)

    @field_validator("granted_by_mid", "grantee_mid")
    @classmethod
    def check_mid(cls, value: str) -> str:
        return validate_mid(value)

    @field_validator("valid_from", "valid_until")
    @classmethod
    def check_time(cls, value: str | None) -> str | None:
        return None if value is None else validate_timestamp(value)

    @field_validator("risk", mode="before")
    @classmethod
    def parse_risk(cls, value: object) -> CapabilityRisk:
        if isinstance(value, CapabilityRisk):
            return value
        if isinstance(value, str):
            return CapabilityRisk(value)
        raise ValueError("capability risk must be text")

    @model_validator(mode="after")
    def validate_grant(self) -> Self:
        if not self.resource_scope or len(self.resource_scope) != len(set(self.resource_scope)):
            raise ValueError("resource scope must be nonempty and unique")
        if self.valid_until is not None and self.valid_until < self.valid_from:
            raise ValueError("capability-grant validity interval is inverted")
        return self


class CapabilityDenial(StrictModel):
    denial_id: str
    capability: str = Field(min_length=1, max_length=256, pattern=r"^[a-z][a-z0-9_.:-]*$")
    denied_by_eid: str
    denied_by_mid: str
    grantee_eid: str
    grantee_mid: str
    effective_from: str
    effective_until: str | None = None
    reason_code: str = Field(min_length=1, max_length=64)

    @field_validator("denial_id")
    @classmethod
    def check_rid(cls, value: str) -> str:
        return validate_rid(value)

    @field_validator("denied_by_eid", "grantee_eid")
    @classmethod
    def check_eid(cls, value: str) -> str:
        return validate_eid(value)

    @field_validator("denied_by_mid", "grantee_mid")
    @classmethod
    def check_mid(cls, value: str) -> str:
        return validate_mid(value)

    @field_validator("effective_from", "effective_until")
    @classmethod
    def check_time(cls, value: str | None) -> str | None:
        return None if value is None else validate_timestamp(value)

    @model_validator(mode="after")
    def validate_denial(self) -> Self:
        if self.effective_until is not None and self.effective_until < self.effective_from:
            raise ValueError("capability-denial validity interval is inverted")
        return self


class Capabilities(StrictModel):
    declared: list[str] = Field(default_factory=list)
    grants: list[CapabilityGrant] = Field(default_factory=list)
    denials: list[CapabilityDenial] = Field(default_factory=list)

    @field_validator("declared")
    @classmethod
    def unique_declared(cls, value: list[str]) -> list[str]:
        if len(value) != len(set(value)):
            raise ValueError("declared capabilities must be unique")
        return value

    @model_validator(mode="after")
    def unique_evidence(self) -> Self:
        identifiers = [grant.grant_id for grant in self.grants]
        identifiers.extend(denial.denial_id for denial in self.denials)
        if len(identifiers) != len(set(identifiers)):
            raise ValueError("capability evidence identifiers must be unique")
        return self


class Lifecycle(StrictModel):
    state: LifecycleState
    state_changed_at: str

    @field_validator("state_changed_at")
    @classmethod
    def check_time(cls, value: str) -> str:
        return validate_timestamp(value)

    @field_validator("state", mode="before")
    @classmethod
    def parse_state(cls, value: object) -> LifecycleState:
        if isinstance(value, LifecycleState):
            return value
        if isinstance(value, str):
            return LifecycleState(value)
        raise ValueError("lifecycle state must be a supported text value")


class ProtectedSection(StrictModel):
    algorithm: Literal["AES-256-GCM"] = "AES-256-GCM"
    key_references: list[str] = Field(min_length=1)
    nonce: bytes = Field(min_length=12, max_length=12)
    ciphertext: bytes = Field(min_length=16)


class ManifestDraft(StrictModel):
    schema_name: Literal["idm"] = Field(default="idm", alias="schema")
    schema_version: Literal["1.0.0"] = "1.0.0"
    manifest_id: str
    entity_id: str
    entity: Entity
    keys: list[PublicKeyBinding] = Field(default_factory=list)
    origin: DraftOrigin = Field(default_factory=DraftOrigin)
    relationships: Relationships = Field(default_factory=Relationships)
    authority: AuthorityRefs = Field(default_factory=AuthorityRefs)
    capabilities: Capabilities = Field(default_factory=Capabilities)
    extensions: dict[str, Any] = Field(default_factory=dict)

    @field_validator("manifest_id")
    @classmethod
    def check_mid(cls, value: str) -> str:
        return validate_mid(value)

    @field_validator("entity_id")
    @classmethod
    def check_eid(cls, value: str) -> str:
        return validate_eid(value)

    @model_validator(mode="after")
    def unique_keys(self) -> Self:
        if len({key.kid for key in self.keys}) != len(self.keys):
            raise ValueError("manifest key KIDs must be unique")
        return self


class Revision(StrictModel):
    schema_name: Literal["idm"] = Field(default="idm", alias="schema")
    schema_version: Literal["1.0.0"] = "1.0.0"
    manifest_id: str
    entity_id: str
    revision: int = Field(ge=1)
    predecessor_vid: str | None
    issued_at: str
    entity: Entity
    keys: list[PublicKeyBinding] = Field(default_factory=list)
    origin: Origin
    relationships: Relationships = Field(default_factory=Relationships)
    authority: AuthorityRefs = Field(default_factory=AuthorityRefs)
    capabilities: Capabilities = Field(default_factory=Capabilities)
    lifecycle: Lifecycle
    protected_sections: dict[str, ProtectedSection] = Field(default_factory=dict)
    extensions: dict[str, Any] = Field(default_factory=dict)

    @field_validator("manifest_id")
    @classmethod
    def check_mid(cls, value: str) -> str:
        return validate_mid(value)

    @field_validator("entity_id")
    @classmethod
    def check_eid(cls, value: str) -> str:
        return validate_eid(value)

    @field_validator("predecessor_vid")
    @classmethod
    def check_vid(cls, value: str | None) -> str | None:
        return None if value is None else validate_vid(value)

    @field_validator("issued_at")
    @classmethod
    def check_time(cls, value: str) -> str:
        return validate_timestamp(value)

    @model_validator(mode="after")
    def validate_lineage_shape(self) -> Self:
        if self.revision == 1 and self.predecessor_vid is not None:
            raise ValueError("genesis revision cannot have a predecessor")
        if self.revision > 1 and self.predecessor_vid is None:
            raise ValueError("successor revision requires a predecessor")
        if self.lifecycle.state == LifecycleState.DRAFT:
            raise ValueError("a signed revision cannot have draft lifecycle state")
        if len({key.kid for key in self.keys}) != len(self.keys):
            raise ValueError("manifest key KIDs must be unique")
        return self


class SignatureMetadata(StrictModel):
    signer_eid: str
    signer_mid: str
    role: str = Field(min_length=1, max_length=64)
    scope: list[str] = Field(min_length=1, max_length=64)
    signed_at: str
    policy_ref: str | None = None

    @field_validator("signer_eid")
    @classmethod
    def check_eid(cls, value: str) -> str:
        return validate_eid(value)

    @field_validator("signer_mid")
    @classmethod
    def check_mid(cls, value: str) -> str:
        return validate_mid(value)

    @field_validator("signed_at")
    @classmethod
    def check_time(cls, value: str) -> str:
        return validate_timestamp(value)

    @field_validator("scope")
    @classmethod
    def unique_scope(cls, value: list[str]) -> list[str]:
        if len(value) != len(set(value)):
            raise ValueError("signature scope entries must be unique")
        return value
