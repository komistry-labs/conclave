"""Declared, granted, denied, and effective capability semantics."""

from __future__ import annotations

from typing import Any

from pydantic import Field

from .container import ParsedArtifact
from .errors import PolicyError, RuntimeAuthorizationError
from .identifiers import new_rid
from .lineage import build_successor
from .models import (
    Capabilities,
    CapabilityDenial,
    CapabilityGrant,
    CapabilityRisk,
    Revision,
    StrictModel,
)
from .timeutil import validate_timestamp

SUPPORTED_CONSTRAINTS = frozenset({"requires_online", "max_input_bytes", "allowed_operations"})


class EffectiveCapability(StrictModel):
    capability: str
    grant_id: str
    resource_scope: list[str]
    risk: CapabilityRisk
    constraints: dict[str, Any] = Field(default_factory=dict)


def _validate_subject_capabilities(revision: Revision) -> None:
    for grant in revision.capabilities.grants:
        if grant.grantee_eid != revision.entity_id or grant.grantee_mid != revision.manifest_id:
            raise PolicyError("capability grant grantee must match its containing manifest")
    for denial in revision.capabilities.denials:
        if denial.grantee_eid != revision.entity_id or denial.grantee_mid != revision.manifest_id:
            raise PolicyError("capability denial grantee must match its containing manifest")


def declare_capability_revision(
    predecessor: ParsedArtifact,
    *,
    capability: str,
    issued_by_eid: str,
    issued_by_mid: str,
    timestamp: str,
) -> Revision:
    prior = predecessor.revision.capabilities
    if capability in prior.declared:
        raise PolicyError("capability is already declared")
    updated = Capabilities(
        declared=[*prior.declared, capability],
        grants=prior.grants,
        denials=prior.denials,
    )
    return build_successor(
        predecessor,
        issued_by_eid=issued_by_eid,
        issued_by_mid=issued_by_mid,
        issued_at=timestamp,
        updates={"capabilities": updated},
    )


def grant_capability_revision(
    predecessor: ParsedArtifact,
    *,
    capability: str,
    granted_by_eid: str,
    granted_by_mid: str,
    issued_by_eid: str,
    issued_by_mid: str,
    timestamp: str,
    resource_scope: list[str] | None = None,
    valid_until: str | None = None,
    risk: CapabilityRisk = CapabilityRisk.MEDIUM,
    constraints: dict[str, Any] | None = None,
) -> tuple[Revision, str]:
    prior_revision = predecessor.revision
    prior = prior_revision.capabilities
    if capability not in prior.declared:
        raise PolicyError("a capability must be declared before it can be granted")
    grant_id = new_rid()
    grant = CapabilityGrant(
        grant_id=grant_id,
        capability=capability,
        granted_by_eid=granted_by_eid,
        granted_by_mid=granted_by_mid,
        grantee_eid=prior_revision.entity_id,
        grantee_mid=prior_revision.manifest_id,
        resource_scope=resource_scope or ["*"],
        valid_from=timestamp,
        valid_until=valid_until,
        risk=risk,
        constraints=constraints or {},
    )
    unknown_constraints = set(grant.constraints).difference(SUPPORTED_CONSTRAINTS)
    if unknown_constraints:
        raise PolicyError(f"unsupported capability constraints: {sorted(unknown_constraints)}")
    updated = Capabilities(
        declared=prior.declared,
        grants=[*prior.grants, grant],
        denials=prior.denials,
    )
    successor = build_successor(
        predecessor,
        issued_by_eid=issued_by_eid,
        issued_by_mid=issued_by_mid,
        issued_at=timestamp,
        updates={"capabilities": updated},
    )
    _validate_subject_capabilities(successor)
    return successor, grant_id


def deny_capability_revision(
    predecessor: ParsedArtifact,
    *,
    capability: str,
    denied_by_eid: str,
    denied_by_mid: str,
    issued_by_eid: str,
    issued_by_mid: str,
    timestamp: str,
    reason_code: str,
    effective_until: str | None = None,
) -> tuple[Revision, str]:
    prior_revision = predecessor.revision
    prior = prior_revision.capabilities
    denial_id = new_rid()
    denial = CapabilityDenial(
        denial_id=denial_id,
        capability=capability,
        denied_by_eid=denied_by_eid,
        denied_by_mid=denied_by_mid,
        grantee_eid=prior_revision.entity_id,
        grantee_mid=prior_revision.manifest_id,
        effective_from=timestamp,
        effective_until=effective_until,
        reason_code=reason_code,
    )
    updated = Capabilities(
        declared=prior.declared,
        grants=prior.grants,
        denials=[*prior.denials, denial],
    )
    successor = build_successor(
        predecessor,
        issued_by_eid=issued_by_eid,
        issued_by_mid=issued_by_mid,
        issued_at=timestamp,
        updates={"capabilities": updated},
    )
    _validate_subject_capabilities(successor)
    return successor, denial_id


def effective_capabilities(revision: Revision, *, at_time: str) -> list[EffectiveCapability]:
    timestamp = validate_timestamp(at_time)
    _validate_subject_capabilities(revision)
    denied = {
        denial.capability
        for denial in revision.capabilities.denials
        if denial.effective_from <= timestamp
        and (denial.effective_until is None or timestamp <= denial.effective_until)
    }
    output: list[EffectiveCapability] = []
    declared = set(revision.capabilities.declared)
    for grant in revision.capabilities.grants:
        if grant.capability not in declared or grant.capability in denied:
            continue
        if timestamp < grant.valid_from or (
            grant.valid_until is not None and timestamp > grant.valid_until
        ):
            continue
        output.append(
            EffectiveCapability(
                capability=grant.capability,
                grant_id=grant.grant_id,
                resource_scope=grant.resource_scope,
                risk=grant.risk,
                constraints=grant.constraints,
            )
        )
    return output


def _resource_allowed(resource: str, scopes: list[str]) -> bool:
    return any(
        scope == "*"
        or scope == resource
        or (scope.endswith("/*") and resource.startswith(scope[:-1]))
        for scope in scopes
    )


def authorize_capability(
    revision: Revision,
    *,
    capability: str,
    resource: str,
    operation: str,
    at_time: str,
    online: bool,
    input_bytes: int = 0,
) -> EffectiveCapability:
    candidates = [
        item
        for item in effective_capabilities(revision, at_time=at_time)
        if item.capability == capability and _resource_allowed(resource, item.resource_scope)
    ]
    for item in candidates:
        constraints = item.constraints
        if set(constraints).difference(SUPPORTED_CONSTRAINTS):
            continue
        if constraints.get("requires_online") is True and not online:
            continue
        limit = constraints.get("max_input_bytes")
        if not isinstance(limit, int) and limit is not None:
            continue
        if isinstance(limit, int) and (limit < 0 or input_bytes > limit):
            continue
        allowed_operations = constraints.get("allowed_operations")
        if allowed_operations is not None and (
            not isinstance(allowed_operations, list)
            or not all(isinstance(value, str) for value in allowed_operations)
            or operation not in allowed_operations
        ):
            continue
        return item
    raise RuntimeAuthorizationError("requested capability is not effectively authorized")
