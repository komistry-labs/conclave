"""Draft creation and genesis issuance."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pydantic import ValidationError

from .canonical import MAX_ARTIFACT_BYTES
from .container import Signer, encode_signed_revision
from .errors import ManifestSchemaError
from .files import read_json_limited, write_bytes_exclusive, write_json_exclusive
from .identifiers import new_eid, new_mid
from .models import (
    DraftOrigin,
    Entity,
    ExternalIdentifierBinding,
    Lifecycle,
    LifecycleState,
    ManifestDraft,
    Origin,
    PublicKeyBinding,
    Revision,
    SignatureMetadata,
)
from .timeutil import now_utc


def create_draft(
    *,
    entity_type: str,
    canonical_name: str,
    display_name: str | None = None,
    description: str | None = None,
    external_identifiers: list[ExternalIdentifierBinding] | None = None,
    originator_eid: str | None = None,
    originator_mid: str | None = None,
    enrollment_profile: str = "komistry-institutional-v1",
    keys: list[PublicKeyBinding] | None = None,
) -> ManifestDraft:
    return ManifestDraft(
        manifest_id=new_mid(),
        entity_id=new_eid(),
        entity=Entity(
            type=entity_type,
            canonical_name=canonical_name,
            display_name=display_name or canonical_name,
            description=description,
            external_identifiers=external_identifiers or [],
        ),
        origin=DraftOrigin(
            originator_eid=originator_eid,
            originator_mid=originator_mid,
            enrollment_profile=enrollment_profile,
        ),
        keys=keys or [],
    )


def issue_genesis(
    draft: ManifestDraft,
    *,
    private_key: bytes,
    kid: str,
    signer_eid: str,
    signer_mid: str,
    issued_at: str | None = None,
    role: str = "identity_authority",
    scope: list[str] | None = None,
    policy_ref: str | None = None,
) -> bytes:
    timestamp = issued_at or now_utc()
    revision = Revision(
        manifest_id=draft.manifest_id,
        entity_id=draft.entity_id,
        revision=1,
        predecessor_vid=None,
        issued_at=timestamp,
        entity=draft.entity,
        origin=Origin(
            originator_eid=draft.origin.originator_eid,
            originator_mid=draft.origin.originator_mid,
            issued_by_eid=signer_eid,
            issued_by_mid=signer_mid,
            enrollment_profile=draft.origin.enrollment_profile,
        ),
        keys=draft.keys,
        relationships=draft.relationships,
        authority=draft.authority,
        capabilities=draft.capabilities,
        lifecycle=Lifecycle(state=LifecycleState.ISSUED, state_changed_at=timestamp),
        extensions=draft.extensions,
    )
    metadata = SignatureMetadata(
        signer_eid=signer_eid,
        signer_mid=signer_mid,
        role=role,
        scope=scope or ["identity.issue"],
        signed_at=timestamp,
        policy_ref=policy_ref,
    )
    return encode_signed_revision(
        revision,
        [Signer(private_key=private_key, kid=kid, metadata=metadata)],
    )


def load_draft(path: Path) -> ManifestDraft:
    try:
        value = read_json_limited(path, max_bytes=MAX_ARTIFACT_BYTES)
        return ManifestDraft.model_validate(value)
    except (ValidationError, ValueError, TypeError) as exc:
        raise ManifestSchemaError(f"invalid manifest draft {path}") from exc


def write_draft(path: Path, draft: ManifestDraft) -> None:
    write_json_exclusive(path, draft.model_dump(mode="json"))


def write_artifact(path: Path, artifact: bytes) -> None:
    write_bytes_exclusive(path, artifact)


def diagnostic_revision(revision: Revision) -> dict[str, Any]:
    return revision.model_dump(mode="json")
