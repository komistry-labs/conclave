"""Out-of-band trust bundles for the gate-1 root profile."""

from __future__ import annotations

import base64
from pathlib import Path
from typing import Literal, Self

from pydantic import Field, field_validator, model_validator

from .attestation import encode_attestation, parse_attestation, verify_attestation
from .errors import SignatureError, TrustError
from .files import read_json_limited, write_json_exclusive
from .identifiers import (
    derive_kid,
    validate_eid,
    validate_kid,
    validate_mid,
    validate_rid,
    validate_trust_domain_id,
)
from .models import SignatureMetadata, StrictModel
from .timeutil import validate_timestamp

DELEGATION_CONTEXT = "idm/v1/key-delegation"


def encode_public_key(value: bytes) -> str:
    return base64.b64encode(value).decode("ascii")


def decode_public_key(value: str) -> bytes:
    try:
        decoded = base64.b64decode(value, validate=True)
    except ValueError as exc:
        raise TrustError("trust anchor contains malformed public-key base64") from exc
    if len(decoded) != 32:
        raise TrustError("Ed25519 public key must be 32 bytes")
    return decoded


class TrustAnchor(StrictModel):
    kid: str
    public_key: str
    signer_eid: str
    signer_mid: str
    roles: list[str] = Field(min_length=1)
    scopes: list[str] = Field(min_length=1)
    valid_from: str
    valid_until: str | None = None
    delegation_id: str | None = None

    @field_validator("kid")
    @classmethod
    def check_kid(cls, value: str) -> str:
        return validate_kid(value)

    @field_validator("signer_eid")
    @classmethod
    def check_eid(cls, value: str) -> str:
        return validate_eid(value)

    @field_validator("signer_mid")
    @classmethod
    def check_mid(cls, value: str) -> str:
        return validate_mid(value)

    @field_validator("valid_from", "valid_until")
    @classmethod
    def check_time(cls, value: str | None) -> str | None:
        return None if value is None else validate_timestamp(value)

    @field_validator("delegation_id")
    @classmethod
    def check_delegation_id(cls, value: str | None) -> str | None:
        return None if value is None else validate_rid(value)

    @model_validator(mode="after")
    def validate_anchor(self) -> TrustAnchor:
        public_key = decode_public_key(self.public_key)
        if derive_kid(public_key) != self.kid:
            raise ValueError("trust-anchor KID does not match public key")
        if len(set(self.roles)) != len(self.roles):
            raise ValueError("trust-anchor roles must be unique")
        if len(set(self.scopes)) != len(self.scopes):
            raise ValueError("trust-anchor scopes must be unique")
        if self.valid_until is not None and self.valid_until < self.valid_from:
            raise ValueError("trust-anchor validity interval is inverted")
        return self

    def authorizes(self, metadata: SignatureMetadata) -> bool:
        if metadata.signer_eid != self.signer_eid or metadata.signer_mid != self.signer_mid:
            return False
        if metadata.role not in self.roles:
            return False
        if not set(metadata.scope).issubset(self.scopes):
            return False
        if metadata.signed_at < self.valid_from:
            return False
        if self.valid_until is not None and metadata.signed_at > self.valid_until:
            return False
        return True


class KeyDelegation(StrictModel):
    schema_name: Literal["idm-key-delegation"] = Field(default="idm-key-delegation", alias="schema")
    version: Literal[1] = 1
    delegation_id: str
    issuer_eid: str
    issuer_mid: str
    issuer_kid: str
    delegated_kid: str
    delegated_public_key: str
    signer_eid: str
    signer_mid: str
    roles: list[str] = Field(min_length=1)
    scopes: list[str] = Field(min_length=1)
    valid_from: str
    valid_until: str | None = None
    issued_at: str

    @field_validator("delegation_id")
    @classmethod
    def check_rid(cls, value: str) -> str:
        return validate_rid(value)

    @field_validator("issuer_eid", "signer_eid")
    @classmethod
    def check_eid(cls, value: str) -> str:
        return validate_eid(value)

    @field_validator("issuer_mid", "signer_mid")
    @classmethod
    def check_mid(cls, value: str) -> str:
        return validate_mid(value)

    @field_validator("issuer_kid", "delegated_kid")
    @classmethod
    def check_kid(cls, value: str) -> str:
        return validate_kid(value)

    @field_validator("valid_from", "valid_until", "issued_at")
    @classmethod
    def check_time(cls, value: str | None) -> str | None:
        return None if value is None else validate_timestamp(value)

    @model_validator(mode="after")
    def validate_delegation(self) -> Self:
        public_key = decode_public_key(self.delegated_public_key)
        if derive_kid(public_key) != self.delegated_kid:
            raise ValueError("delegated KID does not match public key")
        if self.schema_name != "idm-key-delegation" or self.version != 1:
            raise ValueError("unsupported key-delegation schema")
        if self.valid_until is not None and self.valid_until < self.valid_from:
            raise ValueError("delegation validity interval is inverted")
        if self.issued_at > self.valid_from:
            raise ValueError("delegation cannot become valid before it was issued")
        if len(set(self.roles)) != len(self.roles) or len(set(self.scopes)) != len(self.scopes):
            raise ValueError("delegation roles and scopes must be unique")
        return self


def encode_delegation(delegation: KeyDelegation, *, root_private_key: bytes, root_kid: str) -> str:
    if delegation.issuer_kid != root_kid:
        raise TrustError("delegation issuer KID does not match signing key reference")
    evidence = encode_attestation(
        delegation.model_dump(mode="python"),
        context=DELEGATION_CONTEXT,
        private_key=root_private_key,
        kid=root_kid,
    )
    return base64.b64encode(evidence).decode("ascii")


class TrustBundle(StrictModel):
    format: Literal["idm-trust-bundle"] = "idm-trust-bundle"
    version: Literal[1] = 1
    trust_domain_id: str
    generated_at: str
    anchors: list[TrustAnchor] = Field(min_length=1, max_length=16)
    delegations: list[str] = Field(default_factory=list, max_length=128)

    @field_validator("trust_domain_id")
    @classmethod
    def check_domain(cls, value: str) -> str:
        return validate_trust_domain_id(value)

    @field_validator("generated_at")
    @classmethod
    def check_time(cls, value: str) -> str:
        return validate_timestamp(value)

    @model_validator(mode="after")
    def unique_anchors(self) -> TrustBundle:
        kids = [anchor.kid for anchor in self.anchors]
        if len(kids) != len(set(kids)):
            raise ValueError("trust-anchor KIDs must be unique")
        return self

    def find_anchor(self, kid: str) -> TrustAnchor | None:
        direct = next((anchor for anchor in self.anchors if anchor.kid == kid), None)
        if direct is not None:
            return direct
        return self._resolve_delegation(kid)

    def _resolve_delegation(self, kid: str) -> TrustAnchor | None:
        matches: list[TrustAnchor] = []
        for encoded in self.delegations:
            try:
                evidence = base64.b64decode(encoded, validate=True)
                attestation = parse_attestation(evidence, expected_context=DELEGATION_CONTEXT)
                delegation = KeyDelegation.model_validate(attestation.payload)
                if delegation.delegated_kid != kid:
                    continue
                root = next(
                    (anchor for anchor in self.anchors if anchor.kid == delegation.issuer_kid),
                    None,
                )
                if root is None:
                    raise TrustError("delegation does not chain directly to a pinned root")
                if (
                    root.signer_eid != delegation.issuer_eid
                    or root.signer_mid != delegation.issuer_mid
                    or "trust.delegate" not in root.scopes
                    or delegation.issued_at < root.valid_from
                    or (root.valid_until is not None and delegation.issued_at > root.valid_until)
                    or attestation.kid != root.kid
                ):
                    raise TrustError("root was not authorized to issue the delegation")
                verify_attestation(attestation, decode_public_key(root.public_key))
                matches.append(
                    TrustAnchor(
                        kid=delegation.delegated_kid,
                        public_key=delegation.delegated_public_key,
                        signer_eid=delegation.signer_eid,
                        signer_mid=delegation.signer_mid,
                        roles=delegation.roles,
                        scopes=delegation.scopes,
                        valid_from=delegation.valid_from,
                        valid_until=delegation.valid_until,
                        delegation_id=delegation.delegation_id,
                    )
                )
            except (ValueError, SignatureError) as exc:
                raise TrustError("trust bundle contains an invalid signed delegation") from exc
        if len(matches) > 1:
            raise TrustError("trust bundle contains ambiguous delegations for one KID")
        return matches[0] if matches else None

    def validate_delegations(self) -> None:
        anchor_kids = {anchor.kid for anchor in self.anchors}
        delegated_kids: set[str] = set()
        for encoded in self.delegations:
            try:
                evidence = base64.b64decode(encoded, validate=True)
                attestation = parse_attestation(evidence, expected_context=DELEGATION_CONTEXT)
                delegation = KeyDelegation.model_validate(attestation.payload)
            except (ValueError, SignatureError) as exc:
                raise TrustError("trust bundle contains malformed delegation evidence") from exc
            if delegation.delegated_kid in delegated_kids:
                raise TrustError("trust bundle contains duplicate delegated KIDs")
            if delegation.delegated_kid in anchor_kids:
                raise TrustError("delegated KID collides with a pinned trust-anchor KID")
            delegated_kids.add(delegation.delegated_kid)
            if self._resolve_delegation(delegation.delegated_kid) is None:
                raise TrustError("trust bundle delegation could not be resolved")


def load_trust_bundle(path: Path) -> TrustBundle:
    try:
        value = read_json_limited(path, max_bytes=256 * 1024)
        bundle = TrustBundle.model_validate(value)
    except (ValueError, TypeError) as exc:
        raise TrustError(f"invalid trust bundle {path}") from exc
    if bundle.format != "idm-trust-bundle" or bundle.version != 1:
        raise TrustError("unsupported trust-bundle format")
    bundle.validate_delegations()
    return bundle


def write_trust_bundle(path: Path, bundle: TrustBundle) -> None:
    write_json_exclusive(path, bundle.model_dump(mode="json"))
