"""Bounded and non-overwriting file operations."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .errors import FileSafetyError


def read_bytes_limited(path: Path, *, max_bytes: int) -> bytes:
    try:
        size = path.stat().st_size
    except OSError as exc:
        raise FileSafetyError(f"cannot stat {path}") from exc
    if size > max_bytes:
        raise FileSafetyError(f"{path} exceeds the {max_bytes}-byte limit")
    try:
        return path.read_bytes()
    except OSError as exc:
        raise FileSafetyError(f"cannot read {path}") from exc


def write_bytes_exclusive(path: Path, payload: bytes, *, mode: int = 0o644) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
    except FileExistsError as exc:
        raise FileSafetyError(f"refusing to overwrite {path}") from exc
    except OSError as exc:
        raise FileSafetyError(f"cannot create {path}") from exc
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
    except OSError as exc:
        raise FileSafetyError(f"cannot write {path}") from exc


def write_json_exclusive(path: Path, value: Any, *, mode: int = 0o644) -> None:
    serialized = json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False)
    payload = serialized.encode("utf-8") + b"\n"
    write_bytes_exclusive(path, payload, mode=mode)


def read_json_limited(path: Path, *, max_bytes: int) -> Any:
    raw = read_bytes_limited(path, max_bytes=max_bytes)
    try:
        return json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise FileSafetyError(f"invalid JSON in {path}") from exc
