"""Opaque IDM identifiers and content-derived fingerprints."""

from __future__ import annotations

import base64
import hashlib
import re
import secrets
import time
import uuid

from .errors import IdentifierError

_OPAQUE_RE = re.compile(r"^(?P<prefix>eid|mid|rid|tdid):(?P<body>[a-z2-7]{26})$")
_KID_RE = re.compile(r"^kid:sha256:[A-Za-z0-9_-]{43}$")
_VID_RE = re.compile(r"^vid:sha256:[A-Za-z0-9_-]{43}$")
_SECTION_KID_RE = re.compile(r"^skid:sha256:[A-Za-z0-9_-]{43}$")
_EVIDENCE_ID_RE = re.compile(r"^evidence:sha256:[A-Za-z0-9_-]{43}$")
_CHECKPOINT_ID_RE = re.compile(r"^checkpoint:sha256:[A-Za-z0-9_-]{43}$")
_ROOT_FINGERPRINT_RE = re.compile(r"^rootfp:sha256:[A-Za-z0-9_-]{43}$")
_UUIDV7_URN_RE = re.compile(
    r"^urn:uuid:[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$"
)
_K1_DATA_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
_K1_CHECK_ALPHABET = f"{_K1_DATA_ALPHABET}*~$=U"
_K1_RE = re.compile(rf"^K1-([{_K1_DATA_ALPHABET}]{{26}})-([{re.escape(_K1_CHECK_ALPHABET)}])$")
_MAX_UINT128 = (1 << 128) - 1


def _b32_no_padding(value: bytes) -> str:
    return base64.b32encode(value).decode("ascii").rstrip("=").lower()


def _b64url_no_padding(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).decode("ascii").rstrip("=")


def _new_opaque(prefix: str) -> str:
    return f"{prefix}:{_b32_no_padding(secrets.token_bytes(16))}"


def new_eid() -> str:
    return _new_opaque("eid")


def new_mid() -> str:
    return _new_opaque("mid")


def new_rid() -> str:
    return _new_opaque("rid")


def new_trust_domain_id() -> str:
    return _new_opaque("tdid")


def validate_uuid7_urn(value: str) -> str:
    if _UUIDV7_URN_RE.fullmatch(value) is None:
        raise IdentifierError("expected canonical RFC 9562 UUIDv7 URN")
    return value


def new_uuid7_urn(*, timestamp_ms: int | None = None) -> str:
    """Generate a canonical RFC 9562 UUIDv7 URN.

    The embedded timestamp is informational. Authority and allocation order
    remain properties of signed registry evidence and the K1 ledger.
    """

    milliseconds = time.time_ns() // 1_000_000 if timestamp_ms is None else timestamp_ms
    if isinstance(milliseconds, bool) or not isinstance(milliseconds, int):
        raise IdentifierError("UUIDv7 timestamp must be an integer number of milliseconds")
    if milliseconds < 0 or milliseconds >= 1 << 48:
        raise IdentifierError("UUIDv7 timestamp must fit the unsigned 48-bit field")
    value = (
        (milliseconds << 80)
        | (0x7 << 76)
        | (secrets.randbits(12) << 64)
        | (0b10 << 62)
        | secrets.randbits(62)
    )
    return f"urn:uuid:{uuid.UUID(int=value)}"


def format_k1_allocation_number(ordinal: int) -> str:
    if isinstance(ordinal, bool) or not isinstance(ordinal, int):
        raise IdentifierError("K1 allocation ordinal must be an integer")
    if ordinal < 1 or ordinal > _MAX_UINT128:
        raise IdentifierError("K1 allocation ordinal must be an unsigned non-zero 128-bit value")
    remaining = ordinal
    encoded = ""
    while remaining:
        remaining, digit = divmod(remaining, 32)
        encoded = _K1_DATA_ALPHABET[digit] + encoded
    encoded = encoded.rjust(26, "0")
    check = _K1_CHECK_ALPHABET[ordinal % 37]
    return f"K1-{encoded}-{check}"


def parse_k1_allocation_number(value: str) -> int:
    match = _K1_RE.fullmatch(value)
    if match is None:
        raise IdentifierError("expected canonical K1 allocation number")
    ordinal = 0
    for symbol in match.group(1):
        ordinal = ordinal * 32 + _K1_DATA_ALPHABET.index(symbol)
    if ordinal < 1 or ordinal > _MAX_UINT128:
        raise IdentifierError("K1 allocation ordinal must be an unsigned non-zero 128-bit value")
    if match.group(2) != _K1_CHECK_ALPHABET[ordinal % 37]:
        raise IdentifierError("K1 allocation number has an invalid modulo-37 check symbol")
    return ordinal


def validate_k1_allocation_number(value: str) -> str:
    parse_k1_allocation_number(value)
    return value


def derive_kid(public_key_bytes: bytes) -> str:
    return f"kid:sha256:{_b64url_no_padding(hashlib.sha256(public_key_bytes).digest())}"


def derive_vid(artifact_bytes: bytes) -> str:
    return f"vid:sha256:{_b64url_no_padding(hashlib.sha256(artifact_bytes).digest())}"


def derive_evidence_id(evidence_bytes: bytes) -> str:
    return f"evidence:sha256:{_b64url_no_padding(hashlib.sha256(evidence_bytes).digest())}"


def derive_checkpoint_id(checkpoint_bytes: bytes) -> str:
    digest = hashlib.sha256(b"idm-registry-checkpoint-v1\0" + checkpoint_bytes).digest()
    return f"checkpoint:sha256:{_b64url_no_padding(digest)}"


def derive_root_fingerprint(anchor_bytes: bytes) -> str:
    digest = hashlib.sha256(b"idm-root-anchor-set-v1\0" + anchor_bytes).digest()
    return f"rootfp:sha256:{_b64url_no_padding(digest)}"


def derive_section_kid(key_bytes: bytes) -> str:
    return f"skid:sha256:{_b64url_no_padding(hashlib.sha256(key_bytes).digest())}"


def validate_opaque(value: str, expected_prefix: str) -> str:
    match = _OPAQUE_RE.fullmatch(value)
    if match is None or match.group("prefix") != expected_prefix:
        raise IdentifierError(f"expected {expected_prefix}: identifier")
    return value


def validate_eid(value: str) -> str:
    return validate_opaque(value, "eid")


def validate_mid(value: str) -> str:
    return validate_opaque(value, "mid")


def validate_rid(value: str) -> str:
    return validate_opaque(value, "rid")


def validate_trust_domain_id(value: str) -> str:
    return validate_opaque(value, "tdid")


def validate_kid(value: str) -> str:
    if _KID_RE.fullmatch(value) is None:
        raise IdentifierError("expected kid:sha256 identifier")
    return value


def validate_vid(value: str) -> str:
    if _VID_RE.fullmatch(value) is None:
        raise IdentifierError("expected vid:sha256 identifier")
    return value


def validate_section_kid(value: str) -> str:
    if _SECTION_KID_RE.fullmatch(value) is None:
        raise IdentifierError("expected skid:sha256 identifier")
    return value


def validate_evidence_id(value: str) -> str:
    if _EVIDENCE_ID_RE.fullmatch(value) is None:
        raise IdentifierError("expected evidence:sha256 identifier")
    return value


def validate_checkpoint_id(value: str) -> str:
    if _CHECKPOINT_ID_RE.fullmatch(value) is None:
        raise IdentifierError("expected checkpoint:sha256 identifier")
    return value


def validate_root_fingerprint(value: str) -> str:
    if _ROOT_FINGERPRINT_RE.fullmatch(value) is None:
        raise IdentifierError("expected rootfp:sha256 identifier")
    return value
