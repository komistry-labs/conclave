"""Deterministic CBOR encoding and bounded decoding."""

from __future__ import annotations

import io
import unicodedata
from collections.abc import Mapping, Sequence
from typing import Any

import cbor2

from .errors import CanonicalEncodingError

MAX_ARTIFACT_BYTES = 1024 * 1024
MAX_DEPTH = 32
MAX_ITEMS = 10_000
MAX_TEXT_BYTES = 64 * 1024


def dumps(value: Any) -> bytes:
    try:
        return cbor2.dumps(value, canonical=True)
    except (TypeError, ValueError, cbor2.CBOREncodeError) as exc:
        raise CanonicalEncodingError("value cannot be encoded by the IDM CBOR profile") from exc


def loads_one(data: bytes, *, max_bytes: int = MAX_ARTIFACT_BYTES) -> Any:
    if len(data) > max_bytes:
        raise CanonicalEncodingError("CBOR input exceeds the configured size limit")
    stream = io.BytesIO(data)
    decoder = cbor2.CBORDecoder(stream)
    try:
        value = decoder.decode()
    except (EOFError, ValueError, TypeError, cbor2.CBORDecodeError) as exc:
        raise CanonicalEncodingError("malformed CBOR") from exc
    if stream.read(1) != b"":
        raise CanonicalEncodingError("trailing bytes after the top-level CBOR item")
    return value


def validate_profile(
    value: Any,
    *,
    allow_tags: set[int] | None = None,
    allow_integer_keys: bool = False,
) -> None:
    counter = [0]

    def walk(item: Any, depth: int) -> None:
        if depth > MAX_DEPTH:
            raise CanonicalEncodingError("CBOR nesting exceeds the configured depth limit")
        counter[0] += 1
        if counter[0] > MAX_ITEMS:
            raise CanonicalEncodingError("CBOR item count exceeds the configured limit")

        if item is None or isinstance(item, bool) or isinstance(item, int):
            return
        if isinstance(item, float):
            raise CanonicalEncodingError("floating-point values are not allowed")
        if isinstance(item, bytes):
            if len(item) > MAX_ARTIFACT_BYTES:
                raise CanonicalEncodingError("byte string exceeds the configured limit")
            return
        if isinstance(item, str):
            if unicodedata.normalize("NFC", item) != item:
                raise CanonicalEncodingError("text must be Unicode NFC normalized")
            if len(item.encode("utf-8")) > MAX_TEXT_BYTES:
                raise CanonicalEncodingError("text string exceeds the configured limit")
            return
        if isinstance(item, cbor2.CBORTag):
            if allow_tags is None or item.tag not in allow_tags:
                raise CanonicalEncodingError(f"CBOR tag {item.tag} is not allowed")
            walk(item.value, depth + 1)
            return
        if isinstance(item, Mapping):
            for key, child in item.items():
                if not isinstance(key, str) and not (allow_integer_keys and isinstance(key, int)):
                    raise CanonicalEncodingError("map keys must be text in this IDM profile")
                walk(key, depth + 1)
                walk(child, depth + 1)
            return
        if isinstance(item, Sequence):
            for child in item:
                walk(child, depth + 1)
            return
        raise CanonicalEncodingError(f"unsupported CBOR value type: {type(item).__name__}")

    walk(value, 0)


def load_canonical(
    data: bytes,
    *,
    allow_tags: set[int] | None = None,
    allow_integer_keys: bool = False,
    max_bytes: int = MAX_ARTIFACT_BYTES,
) -> Any:
    value = loads_one(data, max_bytes=max_bytes)
    validate_profile(value, allow_tags=allow_tags, allow_integer_keys=allow_integer_keys)
    if dumps(value) != data:
        raise CanonicalEncodingError("CBOR is valid but not deterministically encoded")
    return value
