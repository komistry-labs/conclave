"""Lifecycle transition rules and typed successor construction."""

from __future__ import annotations

from .container import ParsedArtifact
from .errors import LifecycleError
from .lineage import build_successor
from .models import Lifecycle, LifecycleState, Revision

ALLOWED_TRANSITIONS: dict[LifecycleState, frozenset[LifecycleState]] = {
    LifecycleState.DRAFT: frozenset({LifecycleState.ISSUED}),
    LifecycleState.ISSUED: frozenset(
        {LifecycleState.ACTIVE, LifecycleState.SUSPENDED, LifecycleState.RETIRED}
    ),
    LifecycleState.ACTIVE: frozenset(
        {LifecycleState.SUSPENDED, LifecycleState.RETIRED, LifecycleState.ARCHIVED}
    ),
    LifecycleState.SUSPENDED: frozenset({LifecycleState.ACTIVE, LifecycleState.RETIRED}),
    LifecycleState.RETIRED: frozenset({LifecycleState.ARCHIVED}),
    LifecycleState.ARCHIVED: frozenset(),
    LifecycleState.REVOKED: frozenset(),
}

OPERABLE_STATES = frozenset({LifecycleState.ACTIVE})
MOUNTABLE_STATES = frozenset({LifecycleState.ISSUED, LifecycleState.ACTIVE})


def validate_transition(current: LifecycleState, target: LifecycleState) -> None:
    if target not in ALLOWED_TRANSITIONS[current]:
        raise LifecycleError(
            f"lifecycle transition {current.value} -> {target.value} is not allowed"
        )


def transition_revision(
    predecessor: ParsedArtifact,
    *,
    target: LifecycleState,
    issued_by_eid: str,
    issued_by_mid: str,
    timestamp: str,
) -> Revision:
    validate_transition(predecessor.revision.lifecycle.state, target)
    return build_successor(
        predecessor,
        issued_by_eid=issued_by_eid,
        issued_by_mid=issued_by_mid,
        issued_at=timestamp,
        updates={"lifecycle": Lifecycle(state=target, state_changed_at=timestamp)},
    )
