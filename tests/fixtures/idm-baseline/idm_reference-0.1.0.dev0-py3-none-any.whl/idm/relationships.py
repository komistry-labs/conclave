"""Typed direct relationships and relationship-specific successor operations."""

from __future__ import annotations

from .container import ParsedArtifact
from .errors import GraphError
from .identifiers import new_rid
from .lineage import build_successor
from .models import (
    Relationship,
    RelationshipReference,
    Relationships,
    RelationshipStatus,
    Revision,
)

INVERSE_RELATIONSHIPS: dict[str, str] = {
    "owns": "owned_by",
    "owned_by": "owns",
    "founded": "founded_by",
    "founded_by": "founded",
    "originated": "originated_by",
    "originated_by": "originated",
    "belongs_to": "has_member",
    "has_member": "belongs_to",
    "governs": "governed_by",
    "governed_by": "governs",
    "stewards": "stewarded_by",
    "stewarded_by": "stewards",
    "operates": "operated_by",
    "operated_by": "operates",
    "custodies": "held_by",
    "held_by": "custodies",
    "issued_by": "issued",
    "issued": "issued_by",
    "member_of": "has_affiliate",
    "has_affiliate": "member_of",
    "depends_on": "dependency_of",
    "dependency_of": "depends_on",
    "hosts": "hosted_by",
    "hosted_by": "hosts",
    "authorized_by": "authorizes",
    "authorizes": "authorized_by",
    "supervises": "supervised_by",
    "supervised_by": "supervises",
}

CYCLE_CONTROLLED_RELATIONSHIPS = frozenset(
    {
        "owns",
        "owned_by",
        "belongs_to",
        "has_member",
        "governs",
        "governed_by",
        "stewards",
        "stewarded_by",
        "supervises",
        "supervised_by",
    }
)

RELATIONSHIP_AUTHORIZATION_SCOPES: dict[str, str] = {
    "owns": "relationship.ownership",
    "owned_by": "relationship.ownership",
    "founded": "relationship.provenance",
    "founded_by": "relationship.provenance",
    "originated": "relationship.provenance",
    "originated_by": "relationship.provenance",
    "issued": "relationship.provenance",
    "issued_by": "relationship.provenance",
    "belongs_to": "relationship.governance",
    "has_member": "relationship.governance",
    "governs": "relationship.governance",
    "governed_by": "relationship.governance",
    "stewards": "relationship.stewardship",
    "stewarded_by": "relationship.stewardship",
    "supervises": "relationship.supervision",
    "supervised_by": "relationship.supervision",
    "member_of": "relationship.affiliation",
    "has_affiliate": "relationship.affiliation",
    "operates": "relationship.operations",
    "operated_by": "relationship.operations",
    "custodies": "relationship.custody",
    "held_by": "relationship.custody",
    "hosts": "relationship.hosting",
    "hosted_by": "relationship.hosting",
    "authorized_by": "relationship.authorization",
    "authorizes": "relationship.authorization",
    "depends_on": "relationship.dependency",
    "dependency_of": "relationship.dependency",
}


def inverse_relationship(relationship_type: str) -> str:
    try:
        return INVERSE_RELATIONSHIPS[relationship_type]
    except KeyError as exc:
        raise GraphError(f"unsupported relationship type {relationship_type}") from exc


def required_relationship_scope(relationship_type: str) -> str:
    inverse_relationship(relationship_type)
    return RELATIONSHIP_AUTHORIZATION_SCOPES[relationship_type]


def validate_revision_relationships(revision: Revision) -> None:
    active_primary_homes = 0
    for relationship in revision.relationships.authoritative:
        inverse_relationship(relationship.type)
        if (
            relationship.source_eid != revision.entity_id
            or relationship.source_mid != revision.manifest_id
        ):
            raise GraphError("authoritative relationship source must be its containing manifest")
        if relationship.source_eid == relationship.target_eid:
            raise GraphError("self-relationships are not allowed")
        if relationship.status is RelationshipStatus.ENDED and relationship.effective_until is None:
            raise GraphError("ended relationships require effective_until")
        if relationship.type == "belongs_to" and relationship.status is RelationshipStatus.ACTIVE:
            active_primary_homes += 1
    if active_primary_homes > 1:
        raise GraphError("an entity cannot have multiple active belongs_to relationships")
    for reference in revision.relationships.references:
        inverse_relationship(reference.local_role)


def add_relationship_revision(
    predecessor: ParsedArtifact,
    *,
    relationship_type: str,
    target_eid: str,
    target_mid: str,
    issued_by_eid: str,
    issued_by_mid: str,
    timestamp: str,
    constraints: dict[str, object] | None = None,
) -> tuple[Revision, str]:
    inverse_relationship(relationship_type)
    previous = predecessor.revision
    if target_eid == previous.entity_id:
        raise GraphError("self-relationships are not allowed")
    if any(
        item.type == relationship_type
        and item.target_eid == target_eid
        and item.status is RelationshipStatus.ACTIVE
        for item in previous.relationships.authoritative
    ):
        raise GraphError("equivalent active direct relationship already exists")
    relationship_id = new_rid()
    edge = Relationship(
        relationship_id=relationship_id,
        type=relationship_type,
        source_eid=previous.entity_id,
        source_mid=previous.manifest_id,
        target_eid=target_eid,
        target_mid=target_mid,
        effective_from=timestamp,
        constraints=constraints or {},
    )
    relationships = Relationships(
        authoritative=[*previous.relationships.authoritative, edge],
        references=previous.relationships.references,
    )
    successor = build_successor(
        predecessor,
        issued_by_eid=issued_by_eid,
        issued_by_mid=issued_by_mid,
        issued_at=timestamp,
        updates={"relationships": relationships},
    )
    validate_revision_relationships(successor)
    return successor, relationship_id


def add_relationship_reference_revision(
    predecessor: ParsedArtifact,
    *,
    authoritative_artifact: ParsedArtifact,
    relationship_id: str,
    issued_by_eid: str,
    issued_by_mid: str,
    timestamp: str,
) -> Revision:
    matches = [
        edge
        for edge in authoritative_artifact.revision.relationships.authoritative
        if edge.relationship_id == relationship_id
    ]
    if len(matches) != 1:
        raise GraphError("authoritative relationship is missing or ambiguous")
    edge = matches[0]
    target = predecessor.revision
    if edge.target_eid != target.entity_id or edge.target_mid != target.manifest_id:
        raise GraphError("relationship target does not match the referencing manifest")
    reference = RelationshipReference(
        relationship_id=relationship_id,
        authoritative_mid=authoritative_artifact.revision.manifest_id,
        authoritative_vid=authoritative_artifact.vid,
        local_role=inverse_relationship(edge.type),
    )
    relationships = Relationships(
        authoritative=target.relationships.authoritative,
        references=[*target.relationships.references, reference],
    )
    successor = build_successor(
        predecessor,
        issued_by_eid=issued_by_eid,
        issued_by_mid=issued_by_mid,
        issued_at=timestamp,
        updates={"relationships": relationships},
    )
    validate_revision_relationships(successor)
    return successor


def end_relationship_revision(
    predecessor: ParsedArtifact,
    *,
    relationship_id: str,
    issued_by_eid: str,
    issued_by_mid: str,
    timestamp: str,
) -> Revision:
    found = False
    authoritative: list[Relationship] = []
    for edge in predecessor.revision.relationships.authoritative:
        if edge.relationship_id != relationship_id:
            authoritative.append(edge)
            continue
        if edge.status is not RelationshipStatus.ACTIVE:
            raise GraphError("relationship is not active")
        found = True
        values = edge.model_dump(mode="python")
        values.update({"status": RelationshipStatus.ENDED, "effective_until": timestamp})
        authoritative.append(Relationship.model_validate(values))
    if not found:
        raise GraphError("relationship does not exist in the authoritative manifest")
    relationships = Relationships(
        authoritative=authoritative,
        references=predecessor.revision.relationships.references,
    )
    successor = build_successor(
        predecessor,
        issued_by_eid=issued_by_eid,
        issued_by_mid=issued_by_mid,
        issued_at=timestamp,
        updates={"relationships": relationships},
    )
    validate_revision_relationships(successor)
    return successor
