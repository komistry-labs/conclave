"""Signed external revocation evidence for immutable IDM artifacts and keys."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Literal, Self

from pydantic import Field, field_validator, model_validator

from .attestation import encode_attestation, parse_attestation, verify_attestation
from .canonical import MAX_ARTIFACT_BYTES
from .errors import RevocationError, SignatureError, TrustError
from .files import read_bytes_limited, write_bytes_exclusive
from .identifiers import (
    new_rid,
    validate_eid,
    validate_kid,
    validate_mid,
    validate_rid,
    validate_vid,
)
from .models import StrictModel
from .timeutil import validate_timestamp
from .trust import TrustBundle, decode_public_key

REVOCATION_CONTEXT = "idm/v1/revocation"


class RevocationTargetType(StrEnum):
    KEY = "key"
    ENTITY = "entity"
    MANIFEST = "manifest"
    REVISION = "revision"
    DELEGATION = "delegation"


class RevocationStatement(StrictModel):
    schema_name: Literal["idm-revocation"] = Field(default="idm-revocation", alias="schema")
    version: Literal[1] = 1
    revocation_id: str
    target_type: RevocationTargetType
    target_id: str
    reason_code: str = Field(min_length=1, max_length=64, pattern=r"^[a-z][a-z0-9_.-]*$")
    effective_at: str
    issued_at: str
    issuer_eid: str
    issuer_mid: str
    replacement_ref: str | None = None

    @field_validator("revocation_id")
    @classmethod
    def check_rid(cls, value: str) -> str:
        return validate_rid(value)

    @field_validator("issuer_eid")
    @classmethod
    def check_eid(cls, value: str) -> str:
        return validate_eid(value)

    @field_validator("issuer_mid")
    @classmethod
    def check_mid(cls, value: str) -> str:
        return validate_mid(value)

    @field_validator("effective_at", "issued_at")
    @classmethod
    def check_time(cls, value: str) -> str:
        return validate_timestamp(value)

    @field_validator("target_type", mode="before")
    @classmethod
    def parse_target_type(cls, value: object) -> RevocationTargetType:
        if isinstance(value, RevocationTargetType):
            return value
        if isinstance(value, str):
            return RevocationTargetType(value)
        raise ValueError("revocation target type must be text")

    @model_validator(mode="after")
    def validate_target(self) -> Self:
        validators = {
            RevocationTargetType.KEY: validate_kid,
            RevocationTargetType.ENTITY: validate_eid,
            RevocationTargetType.MANIFEST: validate_mid,
            RevocationTargetType.REVISION: validate_vid,
            RevocationTargetType.DELEGATION: validate_rid,
        }
        validators[self.target_type](self.target_id)
        return self


@dataclass(frozen=True, slots=True)
class VerifiedRevocation:
    statement: RevocationStatement
    evidence_id: str
    signer_kid: str
    exact_bytes: bytes


def create_revocation_statement(
    *,
    target_type: RevocationTargetType,
    target_id: str,
    reason_code: str,
    effective_at: str,
    issued_at: str,
    issuer_eid: str,
    issuer_mid: str,
    replacement_ref: str | None = None,
) -> RevocationStatement:
    return RevocationStatement(
        revocation_id=new_rid(),
        target_type=target_type,
        target_id=target_id,
        reason_code=reason_code,
        effective_at=effective_at,
        issued_at=issued_at,
        issuer_eid=issuer_eid,
        issuer_mid=issuer_mid,
        replacement_ref=replacement_ref,
    )


def sign_revocation(statement: RevocationStatement, *, private_key: bytes, kid: str) -> bytes:
    return encode_attestation(
        statement.model_dump(mode="python"),
        context=REVOCATION_CONTEXT,
        private_key=private_key,
        kid=kid,
    )


def verify_revocation(data: bytes, bundle: TrustBundle) -> VerifiedRevocation:
    try:
        attestation = parse_attestation(data, expected_context=REVOCATION_CONTEXT)
        statement = RevocationStatement.model_validate(attestation.payload)
        authority = bundle.find_anchor(attestation.kid)
        if authority is None:
            raise RevocationError("revocation signer is not anchored to the trust domain")
        if (
            statement.issuer_eid != authority.signer_eid
            or statement.issuer_mid != authority.signer_mid
            or "revocation.issue" not in authority.scopes
            or not {"identity_authority", "revocation_authority"}.intersection(authority.roles)
            or statement.issued_at < authority.valid_from
            or (authority.valid_until is not None and statement.issued_at > authority.valid_until)
        ):
            raise RevocationError("revocation signer lacks authority, scope, or time validity")
        verify_attestation(attestation, decode_public_key(authority.public_key))
    except RevocationError:
        raise
    except (ValueError, TypeError, SignatureError, TrustError) as exc:
        raise RevocationError(
            "revocation evidence is malformed or has an invalid signature"
        ) from exc
    return VerifiedRevocation(
        statement=statement,
        evidence_id=attestation.evidence_id,
        signer_kid=attestation.kid,
        exact_bytes=data,
    )


class RevocationSet:
    def __init__(self, evidence: list[VerifiedRevocation]) -> None:
        identifiers = [item.statement.revocation_id for item in evidence]
        if len(identifiers) != len(set(identifiers)):
            raise RevocationError("duplicate revocation statement ID")
        self.evidence = tuple(evidence)

    @classmethod
    def from_bytes(cls, values: list[bytes], bundle: TrustBundle) -> RevocationSet:
        return cls([verify_revocation(value, bundle) for value in values])

    @classmethod
    def from_files(cls, paths: list[Path], bundle: TrustBundle) -> RevocationSet:
        return cls.from_bytes(
            [read_bytes_limited(path, max_bytes=MAX_ARTIFACT_BYTES) for path in paths],
            bundle,
        )

    def matches(
        self, target_type: RevocationTargetType, target_id: str, *, at_time: str
    ) -> list[VerifiedRevocation]:
        timestamp = validate_timestamp(at_time)
        return [
            item
            for item in self.evidence
            if item.statement.target_type is target_type
            and item.statement.target_id == target_id
            and item.statement.effective_at <= timestamp
        ]


def write_revocation(path: Path, data: bytes) -> None:
    write_bytes_exclusive(path, data)
