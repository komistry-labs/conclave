"""Signed offline trust packages with freshness and local rollback controls."""

from __future__ import annotations

import os
import sqlite3
from dataclasses import dataclass
from datetime import UTC, datetime
from itertools import pairwise
from pathlib import Path
from typing import Any, Literal, Self

from pydantic import Field, field_validator, model_validator

from .attestation import encode_attestation, parse_attestation, verify_attestation
from .capabilities import EffectiveCapability, authorize_capability
from .container import ParsedArtifact, parse_artifact
from .errors import (
    LineageError,
    OfflineError,
    PolicyError,
    RegistryError,
    SignatureError,
    TrustError,
)
from .identifiers import (
    new_rid,
    validate_mid,
    validate_rid,
    validate_trust_domain_id,
    validate_vid,
)
from .kos_profile import validate_kos_entity_profile
from .lineage import validate_successor
from .models import CapabilityRisk, Revision, StrictModel
from .policy import KOMISTRY_V1_POLICY, PolicyProfile, evaluate_revision_policy
from .revocation import RevocationSet, RevocationTargetType
from .timeutil import validate_timestamp
from .trust import TrustBundle, decode_public_key
from .verification import verify_artifact

OFFLINE_BUNDLE_CONTEXT = "idm/v1/offline-bundle"


def _parse_time(value: str) -> datetime:
    return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)


class OfflineBundlePayload(StrictModel):
    schema_name: Literal["idm-offline-bundle"] = Field(default="idm-offline-bundle", alias="schema")
    version: Literal[1] = 1
    bundle_id: str
    trust_domain_id: str
    sequence: int = Field(ge=1)
    generated_at: str
    verified_as_of: str
    expires_at: str
    trust_bundle: dict[str, Any]
    policy: dict[str, Any]
    artifacts: list[bytes] = Field(min_length=1, max_length=1024)
    revocations: list[bytes] = Field(default_factory=list, max_length=4096)
    heads: dict[str, str] = Field(min_length=1)
    max_age_seconds: dict[str, int]

    @field_validator("bundle_id")
    @classmethod
    def check_rid(cls, value: str) -> str:
        return validate_rid(value)

    @field_validator("trust_domain_id")
    @classmethod
    def check_domain(cls, value: str) -> str:
        return validate_trust_domain_id(value)

    @field_validator("generated_at", "verified_as_of", "expires_at")
    @classmethod
    def check_time(cls, value: str) -> str:
        return validate_timestamp(value)

    @model_validator(mode="after")
    def validate_payload(self) -> Self:
        if not self.generated_at <= self.verified_as_of <= self.expires_at:
            raise ValueError("offline bundle time interval is inconsistent")
        if set(self.max_age_seconds) != {"low", "medium", "high"}:
            raise ValueError("offline freshness policy must define low, medium, and high")
        if any(not isinstance(value, int) or value < 0 for value in self.max_age_seconds.values()):
            raise ValueError("offline freshness ages must be nonnegative integers")
        for mid, vid in self.heads.items():
            validate_mid(mid)
            validate_vid(vid)
        return self


@dataclass(frozen=True, slots=True)
class VerifiedOfflineBundle:
    payload: OfflineBundlePayload
    evidence_id: str
    signer_kid: str
    trust_bundle: TrustBundle
    policy: PolicyProfile
    revocations: RevocationSet
    artifacts: tuple[ParsedArtifact, ...]


class TrustedTimeStore:
    def __init__(self, path: Path) -> None:
        self.path = path.resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        new_file = not self.path.exists()
        self.connection = sqlite3.connect(self.path)
        self.connection.execute(
            """
            CREATE TABLE IF NOT EXISTS checkpoints (
                trust_domain_id TEXT PRIMARY KEY,
                sequence INTEGER NOT NULL,
                newest_signed_time TEXT NOT NULL,
                bundle_id TEXT NOT NULL
            )
            """
        )
        if new_file:
            os.chmod(self.path, 0o600)

    def __enter__(self) -> TrustedTimeStore:
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def close(self) -> None:
        self.connection.close()

    def check_and_advance(
        self,
        *,
        trust_domain_id: str,
        sequence: int,
        signed_time: str,
        evaluation_time: str,
        bundle_id: str,
    ) -> None:
        validate_timestamp(signed_time)
        validate_timestamp(evaluation_time)
        try:
            self.connection.execute("BEGIN IMMEDIATE")
            row = self.connection.execute(
                """
                SELECT sequence, newest_signed_time, bundle_id FROM checkpoints
                WHERE trust_domain_id = ?
                """,
                (trust_domain_id,),
            ).fetchone()
            if row is not None:
                if sequence < int(row[0]) or signed_time < str(row[1]):
                    raise OfflineError("offline trust package rollback detected")
                if sequence == int(row[0]) and bundle_id != str(row[2]):
                    raise OfflineError("offline trust package sequence equivocation detected")
                if evaluation_time < str(row[1]):
                    raise OfflineError(
                        "local clock is earlier than the trusted signed-time checkpoint"
                    )
            self.connection.execute(
                """
                INSERT INTO checkpoints(trust_domain_id, sequence, newest_signed_time, bundle_id)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(trust_domain_id) DO UPDATE SET
                    sequence = MAX(sequence, excluded.sequence),
                    newest_signed_time = MAX(newest_signed_time, excluded.newest_signed_time),
                    bundle_id = CASE
                        WHEN excluded.sequence > checkpoints.sequence THEN excluded.bundle_id
                        ELSE checkpoints.bundle_id
                    END
                """,
                (trust_domain_id, sequence, signed_time, bundle_id),
            )
            self.connection.commit()
        except (sqlite3.Error, OfflineError):
            self.connection.rollback()
            raise


def _heads_for(artifacts: list[ParsedArtifact]) -> dict[str, str]:
    grouped: dict[str, list[ParsedArtifact]] = {}
    for artifact in artifacts:
        grouped.setdefault(artifact.revision.manifest_id, []).append(artifact)
    heads: dict[str, str] = {}
    for mid, lineage in grouped.items():
        lineage.sort(key=lambda item: item.revision.revision)
        if lineage[0].revision.revision != 1:
            raise LineageError("offline lineage does not include its genesis revision")
        for predecessor, successor in pairwise(lineage):
            validate_successor(predecessor, successor.revision)
        heads[mid] = lineage[-1].vid
    return heads


def _validate_cross_lineage_allocations(artifacts: list[ParsedArtifact]) -> None:
    values: dict[tuple[str, str], tuple[str, str]] = {}
    events: dict[str, tuple[object, ...]] = {}
    for artifact in artifacts:
        binding = validate_kos_entity_profile(artifact.revision.entity)
        if binding is None:
            continue
        owner = (artifact.revision.entity_id, artifact.revision.manifest_id)
        for item in (binding.canonical, binding.allocation):
            prior_owner = values.setdefault((item.scheme, item.value), owner)
            if prior_owner != owner:
                raise OfflineError("offline bundle reuses a KOS identifier across lineages")
        event = (
            binding.canonical.value,
            binding.allocation.value,
            binding.ordinal,
            *owner,
            binding.canonical.allocation_authority_eid,
            binding.canonical.allocation_authority_mid,
        )
        prior_event = events.setdefault(binding.canonical.allocation_event_id, event)
        if prior_event != event:
            raise OfflineError("offline bundle reuses a KOS allocation RID")


def create_offline_bundle(
    *,
    trust_bundle: TrustBundle,
    artifact_bytes: list[bytes],
    revocation_bytes: list[bytes],
    sequence: int,
    generated_at: str,
    verified_as_of: str,
    expires_at: str,
    private_key: bytes,
    kid: str,
    max_age_seconds: dict[str, int] | None = None,
    policy: PolicyProfile = KOMISTRY_V1_POLICY,
) -> bytes:
    artifacts = [parse_artifact(data) for data in artifact_bytes]
    payload = OfflineBundlePayload(
        bundle_id=new_rid(),
        trust_domain_id=trust_bundle.trust_domain_id,
        sequence=sequence,
        generated_at=generated_at,
        verified_as_of=verified_as_of,
        expires_at=expires_at,
        trust_bundle=trust_bundle.model_dump(mode="json"),
        policy=policy.model_dump(mode="json"),
        artifacts=artifact_bytes,
        revocations=revocation_bytes,
        heads=_heads_for(artifacts),
        max_age_seconds=max_age_seconds or {"low": 86400, "medium": 3600, "high": 0},
    )
    return encode_attestation(
        payload.model_dump(mode="python"),
        context=OFFLINE_BUNDLE_CONTEXT,
        private_key=private_key,
        kid=kid,
    )


def verify_offline_bundle(
    data: bytes,
    *,
    pinned_trust: TrustBundle,
    evaluation_time: str,
    time_store: TrustedTimeStore | None = None,
    expected_policy: PolicyProfile = KOMISTRY_V1_POLICY,
) -> VerifiedOfflineBundle:
    timestamp = validate_timestamp(evaluation_time)
    try:
        attestation = parse_attestation(data, expected_context=OFFLINE_BUNDLE_CONTEXT)
        payload = OfflineBundlePayload.model_validate(attestation.payload)
        if payload.trust_domain_id != pinned_trust.trust_domain_id:
            raise OfflineError("offline bundle belongs to another trust domain")
        embedded_trust = TrustBundle.model_validate(payload.trust_bundle)
        embedded_trust.validate_delegations()
        if embedded_trust.anchors != pinned_trust.anchors:
            raise OfflineError("offline bundle changes the out-of-band pinned roots")
        signer = embedded_trust.find_anchor(attestation.kid)
        if signer is None or "registry.snapshot" not in signer.scopes:
            raise OfflineError("offline bundle signer lacks registry.snapshot authority")
        if "registry_authority" not in signer.roles:
            raise OfflineError("offline bundle signer has the wrong authority role")
        if payload.generated_at < signer.valid_from or (
            signer.valid_until is not None and payload.generated_at > signer.valid_until
        ):
            raise OfflineError("offline bundle signer was not valid when the package was generated")
        verify_attestation(attestation, decode_public_key(signer.public_key))
        if timestamp < payload.verified_as_of:
            raise OfflineError("offline bundle is not yet valid")
        if timestamp > payload.expires_at:
            raise OfflineError("offline bundle has expired")
        policy = PolicyProfile.model_validate(payload.policy)
        if policy != expected_policy:
            raise OfflineError("offline bundle policy does not match the locally pinned policy")
        revocations = RevocationSet.from_bytes(payload.revocations, embedded_trust)
        if revocations.matches(RevocationTargetType.KEY, signer.kid, at_time=timestamp):
            raise OfflineError("offline bundle signer key is revoked")
        artifacts = [parse_artifact(item) for item in payload.artifacts]
        _validate_cross_lineage_allocations(artifacts)
        computed_heads = _heads_for(artifacts)
        if computed_heads != payload.heads:
            raise OfflineError("offline bundle head map does not match its signed artifacts")
        grouped: dict[str, list[ParsedArtifact]] = {}
        for artifact in artifacts:
            grouped.setdefault(artifact.revision.manifest_id, []).append(artifact)
        for lineage in grouped.values():
            lineage.sort(key=lambda item: item.revision.revision)
            predecessor: ParsedArtifact | None = None
            for artifact in lineage:
                report = verify_artifact(
                    artifact.exact_bytes,
                    embedded_trust,
                    revocations=revocations,
                    evaluation_time=timestamp,
                )
                if not report.trusted:
                    raise OfflineError(f"offline artifact failed verification: {report.errors}")
                decision = evaluate_revision_policy(
                    predecessor,
                    artifact,
                    report,
                    policy=policy,
                )
                if not decision.allowed:
                    raise OfflineError(
                        f"offline artifact failed revision policy: {decision.errors}"
                    )
                predecessor = artifact
        if time_store is not None:
            time_store.check_and_advance(
                trust_domain_id=payload.trust_domain_id,
                sequence=payload.sequence,
                signed_time=payload.verified_as_of,
                evaluation_time=timestamp,
                bundle_id=payload.bundle_id,
            )
    except OfflineError:
        raise
    except (
        ValueError,
        TypeError,
        LineageError,
        PolicyError,
        RegistryError,
        SignatureError,
        TrustError,
    ) as exc:
        raise OfflineError("offline bundle is malformed or cryptographically invalid") from exc
    return VerifiedOfflineBundle(
        payload=payload,
        evidence_id=attestation.evidence_id,
        signer_kid=attestation.kid,
        trust_bundle=embedded_trust,
        policy=policy,
        revocations=revocations,
        artifacts=tuple(artifacts),
    )


def authorize_offline_capability(
    bundle: VerifiedOfflineBundle,
    revision: Revision,
    *,
    capability: str,
    resource: str,
    operation: str,
    evaluation_time: str,
    input_bytes: int = 0,
) -> EffectiveCapability:
    selected = authorize_capability(
        revision,
        capability=capability,
        resource=resource,
        operation=operation,
        at_time=evaluation_time,
        online=False,
        input_bytes=input_bytes,
    )
    age_seconds = int(
        (_parse_time(evaluation_time) - _parse_time(bundle.payload.verified_as_of)).total_seconds()
    )
    limit = bundle.payload.max_age_seconds[selected.risk.value]
    if selected.risk is CapabilityRisk.HIGH or limit == 0 or age_seconds > limit:
        raise OfflineError(
            f"offline trust state is too stale for {selected.risk.value}-risk capability"
        )
    return selected
