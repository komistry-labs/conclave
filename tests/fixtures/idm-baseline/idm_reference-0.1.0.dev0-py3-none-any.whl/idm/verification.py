"""Fail-closed structural, cryptographic, trust, and issuance verification."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field

from .container import ParsedArtifact, parse_artifact, verify_parsed_signature
from .errors import IDMError, SignatureError
from .models import StrictModel
from .revocation import RevocationSet, RevocationTargetType
from .timeutil import now_utc, validate_timestamp
from .trust import TrustBundle, decode_public_key


class VerificationStatus(StrEnum):
    INVALID = "invalid"
    UNTRUSTED = "untrusted"
    TRUSTED = "trusted"
    REVOKED = "revoked"


class SignatureVerification(StrictModel):
    kid: str
    signer_eid: str
    signer_mid: str
    role: str
    scope: list[str]
    cryptographically_valid: bool
    anchor_recognized: bool
    issuer_authorized: bool
    delegation_id: str | None = None
    errors: list[str] = Field(default_factory=list)


class VerificationReport(StrictModel):
    status: VerificationStatus
    vid: str | None
    entity_id: str | None
    manifest_id: str | None
    revision: int | None
    structurally_valid: bool
    schema_valid: bool
    signatures: list[SignatureVerification] = Field(default_factory=list)
    trusted: bool
    revoked: bool = False
    revocation_ids: list[str] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)


def _invalid_report(message: str) -> VerificationReport:
    return VerificationReport(
        status=VerificationStatus.INVALID,
        vid=None,
        entity_id=None,
        manifest_id=None,
        revision=None,
        structurally_valid=False,
        schema_valid=False,
        trusted=False,
        errors=[message],
    )


def _verify_signature(
    artifact: ParsedArtifact, index: int, bundle: TrustBundle
) -> SignatureVerification:
    signature = artifact.signatures[index]
    errors: list[str] = []
    anchor = bundle.find_anchor(signature.kid)
    if anchor is None:
        errors.append("signer key is not a configured trust anchor")
        return SignatureVerification(
            kid=signature.kid,
            signer_eid=signature.metadata.signer_eid,
            signer_mid=signature.metadata.signer_mid,
            role=signature.metadata.role,
            scope=signature.metadata.scope,
            cryptographically_valid=False,
            anchor_recognized=False,
            issuer_authorized=False,
            delegation_id=None,
            errors=errors,
        )

    crypto_valid = True
    try:
        verify_parsed_signature(artifact, signature, decode_public_key(anchor.public_key))
    except SignatureError as exc:
        crypto_valid = False
        errors.append(str(exc))

    authorized = crypto_valid and anchor.authorizes(signature.metadata)
    if crypto_valid and not authorized:
        errors.append("trusted key is not authorized for the declared signer, role, scope, or time")
    return SignatureVerification(
        kid=signature.kid,
        signer_eid=signature.metadata.signer_eid,
        signer_mid=signature.metadata.signer_mid,
        role=signature.metadata.role,
        scope=signature.metadata.scope,
        cryptographically_valid=crypto_valid,
        anchor_recognized=True,
        issuer_authorized=authorized,
        delegation_id=anchor.delegation_id,
        errors=errors,
    )


def verify_artifact(
    data: bytes,
    bundle: TrustBundle,
    *,
    revocations: RevocationSet | None = None,
    evaluation_time: str | None = None,
) -> VerificationReport:
    try:
        artifact = parse_artifact(data)
    except IDMError as exc:
        return _invalid_report(str(exc))

    at_time = evaluation_time or now_utc()
    try:
        validate_timestamp(at_time)
    except ValueError as exc:
        return _invalid_report(str(exc))
    signatures = [
        _verify_signature(artifact, index, bundle) for index in range(len(artifact.signatures))
    ]
    signatures_valid = bool(signatures) and all(
        item.cryptographically_valid and item.anchor_recognized and item.issuer_authorized
        for item in signatures
    )
    required_scope = "identity.issue" if artifact.revision.revision == 1 else "manifest.revise"
    primary_signers = [
        item
        for item in signatures
        if item.issuer_authorized
        and required_scope in item.scope
        and artifact.revision.origin.issued_by_eid == item.signer_eid
        and artifact.revision.origin.issued_by_mid == item.signer_mid
    ]
    errors = [error for item in signatures for error in item.errors]
    if not primary_signers:
        errors.append(
            f"no authorized payload issuer signature carries required scope {required_scope}"
        )
    temporal_valid = True
    if artifact.revision.issued_at > at_time:
        temporal_valid = False
        errors.append("artifact issuance time is later than the trusted evaluation time")
    future_signers = [
        item.kid
        for item, signature in zip(signatures, artifact.signatures, strict=True)
        if signature.metadata.signed_at > at_time
    ]
    if future_signers:
        temporal_valid = False
        errors.append(f"signature time is later than the trusted evaluation time: {future_signers}")
    trusted = signatures_valid and bool(primary_signers) and temporal_valid
    matched_revocations = []
    if revocations is not None:
        targets = [
            (RevocationTargetType.REVISION, artifact.vid),
            (RevocationTargetType.MANIFEST, artifact.revision.manifest_id),
            (RevocationTargetType.ENTITY, artifact.revision.entity_id),
            *[(RevocationTargetType.KEY, signature.kid) for signature in artifact.signatures],
            *[
                (RevocationTargetType.DELEGATION, signature.delegation_id)
                for signature in signatures
                if signature.delegation_id is not None
            ],
        ]
        matched_revocations = [
            evidence
            for target_type, target_id in targets
            for evidence in revocations.matches(target_type, target_id, at_time=at_time)
        ]
    revocation_ids = sorted({evidence.statement.revocation_id for evidence in matched_revocations})
    if revocation_ids:
        trusted = False
        errors.append(f"artifact is revoked by statements: {revocation_ids}")
    status = (
        VerificationStatus.REVOKED
        if revocation_ids
        else VerificationStatus.TRUSTED
        if trusted
        else VerificationStatus.UNTRUSTED
    )
    return VerificationReport(
        status=status,
        vid=artifact.vid,
        entity_id=artifact.revision.entity_id,
        manifest_id=artifact.revision.manifest_id,
        revision=artifact.revision.revision,
        structurally_valid=True,
        schema_valid=True,
        signatures=signatures,
        trusted=trusted,
        revoked=bool(revocation_ids),
        revocation_ids=revocation_ids,
        errors=errors,
    )
