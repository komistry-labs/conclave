"""IDM identity-manifest reference implementation."""

from .identifiers import derive_kid, derive_vid, new_eid, new_mid, new_rid
from .manifest import create_draft, issue_genesis
from .verification import VerificationReport, verify_artifact

__all__ = [
    "VerificationReport",
    "create_draft",
    "derive_kid",
    "derive_vid",
    "issue_genesis",
    "new_eid",
    "new_mid",
    "new_rid",
    "verify_artifact",
]

__version__ = "0.1.0.dev0"
