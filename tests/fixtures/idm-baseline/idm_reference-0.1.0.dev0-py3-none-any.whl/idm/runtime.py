"""Fail-closed runtime challenge, subject proof, and read-only identity mounting."""

from __future__ import annotations

import os
import secrets
import sqlite3
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Literal, Self

from pydantic import Field, field_validator, model_validator

from . import canonical
from .attestation import encode_attestation, parse_attestation, verify_attestation
from .capabilities import EffectiveCapability, authorize_capability, effective_capabilities
from .container import parse_artifact
from .errors import RuntimeAuthorizationError
from .identifiers import new_rid, validate_eid, validate_rid, validate_vid
from .keybindings import decode_bound_public_key
from .lifecycle import MOUNTABLE_STATES, OPERABLE_STATES
from .models import KeyPurpose, StrictModel
from .registry import Registry
from .revocation import RevocationSet, RevocationTargetType
from .timeutil import now_utc, validate_timestamp
from .trust import TrustBundle
from .verification import verify_artifact

SUBJECT_PROOF_CONTEXT = "idm/v1/subject-proof"
MAX_CHALLENGE_TTL_SECONDS = 300


def _parse_time(value: str) -> datetime:
    return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)


class RuntimeChallenge(StrictModel):
    schema_name: Literal["idm-runtime-challenge"] = Field(
        default="idm-runtime-challenge", alias="schema"
    )
    version: Literal[1] = 1
    nonce: bytes = Field(min_length=32, max_length=32)
    entity_id: str
    version_id: str
    action: str = Field(min_length=1, max_length=256)
    runtime_eid: str
    session_id: str
    issued_at: str
    expires_at: str

    @field_validator("entity_id", "runtime_eid")
    @classmethod
    def check_eid(cls, value: str) -> str:
        return validate_eid(value)

    @field_validator("version_id")
    @classmethod
    def check_vid(cls, value: str) -> str:
        return validate_vid(value)

    @field_validator("session_id")
    @classmethod
    def check_rid(cls, value: str) -> str:
        return validate_rid(value)

    @field_validator("issued_at", "expires_at")
    @classmethod
    def check_time(cls, value: str) -> str:
        return validate_timestamp(value)

    @model_validator(mode="after")
    def validate_window(self) -> Self:
        issued = _parse_time(self.issued_at)
        expires = _parse_time(self.expires_at)
        if expires <= issued:
            raise ValueError("runtime challenge must expire after issuance")
        if (expires - issued).total_seconds() > MAX_CHALLENGE_TTL_SECONDS:
            raise ValueError("runtime challenge lifetime exceeds the protocol maximum")
        return self


@dataclass(frozen=True, slots=True)
class IdentityContext:
    entity_id: str
    manifest_id: str
    version_id: str
    revision: int
    entity_type: str
    canonical_name: str
    display_name: str
    lifecycle_state: str
    authenticated_kid: str
    session_id: str
    verified_at: str
    capabilities: tuple[EffectiveCapability, ...]


class SessionStore:
    def __init__(self, path: Path) -> None:
        self.path = path.resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        new_file = not self.path.exists()
        self.connection = sqlite3.connect(self.path)
        self.connection.execute(
            """
            CREATE TABLE IF NOT EXISTS challenges (
                session_id TEXT PRIMARY KEY,
                challenge BLOB NOT NULL,
                expires_at TEXT NOT NULL,
                consumed INTEGER NOT NULL DEFAULT 0,
                proof_id TEXT UNIQUE
            )
            """
        )
        if new_file:
            os.chmod(self.path, 0o600)

    def __enter__(self) -> SessionStore:
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def close(self) -> None:
        self.connection.close()

    def record(self, challenge: RuntimeChallenge) -> None:
        encoded = canonical.dumps(challenge.model_dump(mode="python"))
        try:
            with self.connection:
                self.connection.execute(
                    "INSERT INTO challenges(session_id, challenge, expires_at) VALUES (?, ?, ?)",
                    (challenge.session_id, encoded, challenge.expires_at),
                )
        except sqlite3.IntegrityError as exc:
            raise RuntimeAuthorizationError("runtime session identifier already exists") from exc

    def consume(self, challenge: RuntimeChallenge, proof_id: str) -> None:
        encoded = canonical.dumps(challenge.model_dump(mode="python"))
        try:
            self.connection.execute("BEGIN IMMEDIATE")
            row = self.connection.execute(
                "SELECT challenge, consumed FROM challenges WHERE session_id = ?",
                (challenge.session_id,),
            ).fetchone()
            if row is None or bytes(row[0]) != encoded:
                raise RuntimeAuthorizationError("proof does not match a runtime-issued challenge")
            if bool(row[1]):
                raise RuntimeAuthorizationError("runtime challenge has already been consumed")
            self.connection.execute(
                "UPDATE challenges SET consumed = 1, proof_id = ? WHERE session_id = ?",
                (proof_id, challenge.session_id),
            )
            self.connection.commit()
        except (sqlite3.Error, RuntimeAuthorizationError):
            self.connection.rollback()
            raise


def create_challenge(
    artifact_bytes: bytes,
    *,
    runtime_eid: str,
    action: str,
    issued_at: str | None = None,
    ttl_seconds: int = 120,
) -> RuntimeChallenge:
    if not 1 <= ttl_seconds <= MAX_CHALLENGE_TTL_SECONDS:
        raise RuntimeAuthorizationError("challenge TTL is outside the permitted range")
    artifact = parse_artifact(artifact_bytes)
    timestamp = issued_at or now_utc()
    expires = _parse_time(timestamp) + timedelta(seconds=ttl_seconds)
    return RuntimeChallenge(
        nonce=secrets.token_bytes(32),
        entity_id=artifact.revision.entity_id,
        version_id=artifact.vid,
        action=action,
        runtime_eid=runtime_eid,
        session_id=new_rid(),
        issued_at=timestamp,
        expires_at=expires.strftime("%Y-%m-%dT%H:%M:%SZ"),
    )


def sign_subject_proof(challenge: RuntimeChallenge, *, private_key: bytes, kid: str) -> bytes:
    return encode_attestation(
        challenge.model_dump(mode="python"),
        context=SUBJECT_PROOF_CONTEXT,
        private_key=private_key,
        kid=kid,
    )


class Runtime:
    def __init__(
        self,
        *,
        runtime_eid: str,
        registry: Registry,
        sessions: SessionStore,
        clock: Callable[[], str] = now_utc,
    ) -> None:
        self.runtime_eid = validate_eid(runtime_eid)
        self.registry = registry
        self.sessions = sessions
        self.clock = clock

    def issue_challenge(
        self,
        artifact_bytes: bytes,
        *,
        action: str,
        ttl_seconds: int = 120,
    ) -> RuntimeChallenge:
        challenge = create_challenge(
            artifact_bytes,
            runtime_eid=self.runtime_eid,
            action=action,
            issued_at=self.clock(),
            ttl_seconds=ttl_seconds,
        )
        self.sessions.record(challenge)
        return challenge

    def mount(
        self,
        artifact_bytes: bytes,
        *,
        trust_bundle: TrustBundle,
        subject_proof: bytes,
        expected_action: str,
        revocations: RevocationSet | None = None,
        capability: str | None = None,
        resource: str = "*",
        operation: str = "execute",
        online: bool = True,
        input_bytes: int = 0,
    ) -> IdentityContext:
        timestamp = self.clock()
        validate_timestamp(timestamp)
        report = verify_artifact(
            artifact_bytes,
            trust_bundle,
            revocations=revocations,
            evaluation_time=timestamp,
        )
        if not report.trusted:
            raise RuntimeAuthorizationError(f"artifact trust verification failed: {report.errors}")
        artifact = parse_artifact(artifact_bytes)
        registry_errors = self.registry.verify(
            trust_bundle,
            evaluation_time=timestamp,
        )
        if registry_errors:
            raise RuntimeAuthorizationError(f"registry integrity audit failed: {registry_errors}")
        if artifact.revision.manifest_id in self.registry.revoked_lineages(
            trust_bundle,
            revocations=revocations,
            evaluation_time=timestamp,
        ):
            raise RuntimeAuthorizationError("artifact lineage contains revoked evidence")
        latest = self.registry.latest_artifact(mid=artifact.revision.manifest_id)
        if latest is None or parse_artifact(latest).vid != artifact.vid:
            raise RuntimeAuthorizationError("artifact is not the trusted current lineage head")
        state = artifact.revision.lifecycle.state
        allowed_states = OPERABLE_STATES if expected_action != "mount" else MOUNTABLE_STATES
        if state not in allowed_states:
            raise RuntimeAuthorizationError(
                f"lifecycle state {state.value} does not permit {expected_action}"
            )

        proof = parse_attestation(subject_proof, expected_context=SUBJECT_PROOF_CONTEXT)
        try:
            challenge = RuntimeChallenge.model_validate(proof.payload)
        except ValueError as exc:
            raise RuntimeAuthorizationError("subject proof contains an invalid challenge") from exc
        if (
            challenge.entity_id != artifact.revision.entity_id
            or challenge.version_id != artifact.vid
            or challenge.runtime_eid != self.runtime_eid
            or challenge.action != expected_action
        ):
            raise RuntimeAuthorizationError("subject proof is not bound to this activation request")
        if not challenge.issued_at <= timestamp <= challenge.expires_at:
            raise RuntimeAuthorizationError("runtime challenge is not currently valid")
        bindings = [binding for binding in artifact.revision.keys if binding.kid == proof.kid]
        if len(bindings) != 1:
            raise RuntimeAuthorizationError("proof key is not uniquely bound to the subject")
        binding = bindings[0]
        permitted_purposes = {KeyPurpose.SUBJECT_CONTROL, KeyPurpose.OPERATION}
        if not permitted_purposes.intersection(binding.purposes):
            raise RuntimeAuthorizationError("proof key lacks subject-control purpose")
        if timestamp < binding.valid_from or (
            binding.valid_until is not None and timestamp > binding.valid_until
        ):
            raise RuntimeAuthorizationError("subject-control key is outside its validity window")
        if revocations is not None and revocations.matches(
            RevocationTargetType.KEY, binding.kid, at_time=timestamp
        ):
            raise RuntimeAuthorizationError("subject-control key is revoked")
        verify_attestation(proof, decode_bound_public_key(binding))

        capabilities = effective_capabilities(artifact.revision, at_time=timestamp)
        if capability is not None:
            selected = authorize_capability(
                artifact.revision,
                capability=capability,
                resource=resource,
                operation=operation,
                at_time=timestamp,
                online=online,
                input_bytes=input_bytes,
            )
            capabilities = [selected]
        self.sessions.consume(challenge, proof.evidence_id)
        return IdentityContext(
            entity_id=artifact.revision.entity_id,
            manifest_id=artifact.revision.manifest_id,
            version_id=artifact.vid,
            revision=artifact.revision.revision,
            entity_type=artifact.revision.entity.type,
            canonical_name=artifact.revision.entity.canonical_name,
            display_name=artifact.revision.entity.display_name,
            lifecycle_state=state.value,
            authenticated_kid=binding.kid,
            session_id=challenge.session_id,
            verified_at=timestamp,
            capabilities=tuple(capabilities),
        )
