"""Normalized protocol timestamps."""

from __future__ import annotations

import re
from datetime import UTC, datetime

_TIMESTAMP_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")


def now_utc() -> str:
    return datetime.now(UTC).replace(microsecond=0).strftime("%Y-%m-%dT%H:%M:%SZ")


def validate_timestamp(value: str) -> str:
    if _TIMESTAMP_RE.fullmatch(value) is None:
        raise ValueError("timestamp must use normalized UTC form YYYY-MM-DDTHH:MM:SSZ")
    parsed = datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
    if parsed.strftime("%Y-%m-%dT%H:%M:%SZ") != value:
        raise ValueError("timestamp is not normalized")
    return value
