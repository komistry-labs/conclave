"""Immutable revision-chain construction and continuity validation."""

from __future__ import annotations

from typing import Any

from .container import ParsedArtifact, Signer, encode_signed_revision, parse_artifact
from .errors import LineageError
from .models import Origin, Revision
from .timeutil import validate_timestamp

IMMUTABLE_ORIGIN_FIELDS = ("originator_eid", "originator_mid", "enrollment_profile")
KOS_IDENTIFIER_SCHEMES = frozenset({"kos-canonical-id", "kos-allocation-number"})


def validate_successor(predecessor: ParsedArtifact, successor: Revision) -> None:
    previous = predecessor.revision
    if successor.entity_id != previous.entity_id:
        raise LineageError("successor cannot change the enduring entity ID")
    if successor.manifest_id != previous.manifest_id:
        raise LineageError("successor cannot change the manifest lineage ID")
    if successor.revision != previous.revision + 1:
        raise LineageError("successor revision must increment exactly once")
    if successor.predecessor_vid != predecessor.vid:
        raise LineageError("successor does not name the exact predecessor VID")
    if successor.issued_at < previous.issued_at:
        raise LineageError("successor issuance time cannot move backwards")
    for field_name in IMMUTABLE_ORIGIN_FIELDS:
        if getattr(successor.origin, field_name) != getattr(previous.origin, field_name):
            raise LineageError(f"successor cannot change immutable origin field {field_name}")
    previous_kos_bindings = {
        item.scheme: item
        for item in previous.entity.external_identifiers
        if item.scheme in KOS_IDENTIFIER_SCHEMES
    }
    successor_kos_bindings = {
        item.scheme: item
        for item in successor.entity.external_identifiers
        if item.scheme in KOS_IDENTIFIER_SCHEMES
    }
    if previous_kos_bindings and successor_kos_bindings != previous_kos_bindings:
        raise LineageError("successor cannot change or remove the atomic KOS identifier binding")


def build_successor(
    predecessor: ParsedArtifact,
    *,
    issued_by_eid: str,
    issued_by_mid: str,
    issued_at: str,
    updates: dict[str, Any] | None = None,
) -> Revision:
    timestamp = validate_timestamp(issued_at)
    previous = predecessor.revision
    values = previous.model_dump(mode="python")
    forbidden = {
        "schema",
        "schema_name",
        "schema_version",
        "manifest_id",
        "entity_id",
        "revision",
        "predecessor_vid",
        "issued_at",
        "origin",
    }
    requested = updates or {}
    overlap = forbidden.intersection(requested)
    if overlap:
        raise LineageError(f"successor update attempts protected fields: {sorted(overlap)}")
    values.update(requested)
    values.update(
        {
            "revision": previous.revision + 1,
            "predecessor_vid": predecessor.vid,
            "issued_at": timestamp,
            "origin": Origin(
                originator_eid=previous.origin.originator_eid,
                originator_mid=previous.origin.originator_mid,
                issued_by_eid=issued_by_eid,
                issued_by_mid=issued_by_mid,
                enrollment_profile=previous.origin.enrollment_profile,
            ),
        }
    )
    successor = Revision.model_validate(values)
    validate_successor(predecessor, successor)
    return successor


def issue_successor(
    predecessor_bytes: bytes,
    successor: Revision,
    signers: list[Signer],
) -> bytes:
    predecessor = parse_artifact(predecessor_bytes)
    validate_successor(predecessor, successor)
    return encode_signed_revision(successor, signers)
