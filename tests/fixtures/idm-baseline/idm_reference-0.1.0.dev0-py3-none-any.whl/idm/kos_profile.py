"""Pinned KOS admission profile derived from Accepted ADR-0002 and ADR-0009."""

from __future__ import annotations

from dataclasses import dataclass

from .errors import RegistryError
from .identifiers import parse_k1_allocation_number
from .models import Entity, ExternalIdentifierBinding

KOS_OBJECT_TYPE_PROFILE = "kos-adr-0002+0009-v1.0"
KOS_OBJECT_TYPES = frozenset(
    {
        "institution",
        "lab",
        "team",
        "programme",
        "initiative",
        "project",
        "workstream",
        "task",
        "experiment",
        "product",
        "service",
        "agent",
        "publication",
        "framework",
        "method",
        "standard",
        "asset",
        "knowledge_record",
        "research_record",
        "requirement",
        "definition",
        "record",
        "decision",
        "policy",
        "principle",
        "rule",
        "approval",
        "exception",
        "role",
        "identity",
        "actor",
        "repository",
        "workspace",
        "workflow",
        "event",
        "relationship",
        "constitutional_charter",
    }
)


@dataclass(frozen=True, slots=True)
class KosAllocationBinding:
    canonical: ExternalIdentifierBinding
    allocation: ExternalIdentifierBinding
    ordinal: int


def kos_allocation_binding(entity: Entity) -> KosAllocationBinding | None:
    canonical = next(
        (item for item in entity.external_identifiers if item.scheme == "kos-canonical-id"),
        None,
    )
    allocation = next(
        (item for item in entity.external_identifiers if item.scheme == "kos-allocation-number"),
        None,
    )
    if canonical is None and allocation is None:
        return None
    if canonical is None or allocation is None:
        raise RegistryError("KOS allocation evidence is not a complete UUIDv7/K1 pair")
    return KosAllocationBinding(
        canonical=canonical,
        allocation=allocation,
        ordinal=parse_k1_allocation_number(allocation.value),
    )


def validate_kos_entity_profile(entity: Entity) -> KosAllocationBinding | None:
    binding = kos_allocation_binding(entity)
    if binding is not None and entity.type not in KOS_OBJECT_TYPES:
        raise RegistryError(
            f"KOS-bound entity type {entity.type!r} is outside {KOS_OBJECT_TYPE_PROFILE}"
        )
    return binding
