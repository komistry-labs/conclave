# Contributing

IDM is security-sensitive protocol code. Changes should be small, reviewable, and accompanied by tests that demonstrate both the intended behavior and a relevant failure case.

Before submitting a change, run:

```bash
.venv/bin/ruff format --check src tests
.venv/bin/ruff check src tests
.venv/bin/mypy src
.venv/bin/pytest
```

Protocol changes require an ADR under `docs/adr/`, corresponding CDDL and diagnostic JSON Schema updates, migration notes, and interoperability vectors when wire bytes change. Never add real keys, passphrases, identity-proofing records, private personal data, or production artifacts to fixtures.

Security reports should follow `SECURITY.md`, not a public issue containing exploit details.
