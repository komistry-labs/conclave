# IDM Identity Manifest

IDM is a reference implementation of a cryptographically governed identity-manifest protocol for enduring humans, agents, laboratories, companies, projects, devices, services, and infrastructure nodes.

An `.idm` is identity evidence, not a casual document and not a bearer credential. One artifact revision represents one entity in one immutable lineage. A runtime recognizes it only after canonical parsing, schema validation, signature and authority verification, lineage and revocation checks, policy evaluation, and—when acting as the entity—a fresh proof from a bound subject key.

This repository is a security prototype. It has not received an independent audit and must not protect production identities, keys, personal data, or safety-critical operations.

## Implemented reference profile

- opaque EID, MID, RID and key identifiers; exact-byte VID;
- deterministic CBOR and strict RFC 9052 COSE_Sign / COSE_Sign1 profiles;
- offline root plus separately delegated issuance, KOS allocation, revocation,
  and registry keys;
- encrypted development vault, key separation, and AES-256-GCM protected sections;
- genesis issuance and policy-authorized immutable successors;
- rollback, duplicate revision, unknown predecessor, and fork rejection;
- external revocation of keys, entities, lineages, and exact revisions;
- revocable delegation evidence and trusted-time rejection of future artifacts and signatures;
- typed direct relationships, family-specific authorization, unambiguous inverses, target references, cycle control, and evidence paths;
- transactional, rebuildable and exact-evidence-audited SQLite registry;
- authority-attributed, non-reusable external identifier allocation, including
  atomic KOS UUIDv7 Canonical-ID and K1 allocation-number bindings;
- trust-domain-pinned allocation events, contiguous K1 high-water enforcement,
  pinned KOS object types, and deterministic registry checkpoints;
- declared, granted, denied, effective, scoped, constrained, and time-bounded capabilities;
- action-bound subject proof, current-head enforcement, lifecycle gating, and replay prevention;
- signed offline bundles, freshness policy, trusted-time rollback checks, and hash-linked local events;
- strict typing, linting, randomized parser checks, unit, integration, and security tests.

The CI contract runs the same Python 3.12 formatting, lint, type, test, and wheel-build gates on Ubuntu, macOS, and Windows. Local Windows validation is supported; POSIX private-file mode checks apply on Linux and macOS, while the Windows development vault relies on inherited directory ACLs as documented in the threat model.

## Install for development

Python 3.12 is required.

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
.venv/bin/python -m pip install --no-deps --no-build-isolation -e .
.venv/bin/pytest
```

The lock records the exact tested versions but does not yet include package hashes. A production build needs a reviewed, hash-locked artifact supply chain.
See [BUILDING.md](BUILDING.md) for the pinned-epoch wheel procedure and remaining supply-chain work.

## Minimal offline workflow

Create a permission-restricted passphrase file for scripted development, or omit `--passphrase-file` to use the terminal prompt:

```bash
chmod 600 vault-input
idm authority init --name komistry-root --output demo-authority --passphrase-file vault-input
idm key generate --output nova-control.idmk --passphrase-file vault-input
idm create --type agent --name nova --subject-key nova-control.idmk --output nova.draft.json
idm issue nova.draft.json --authority demo-authority --output nova.idm --passphrase-file vault-input
idm verify nova.idm --trust demo-authority/trust-bundle.json
idm registry add nova.idm --database registry.db --trust demo-authority/trust-bundle.json
```

The single passphrase option is retained for development compatibility. A
Stage B rehearsal must instead provide all five distinct authority-init role
passphrase files (`root`, `issuance`, `allocation`, `revocation`, and
`registry`). Use `idm issue ... --allocate-kos` with the allocation-key
passphrase to generate a UUIDv7/RID pair and admit only the authoritative next
K1 value. `idm registry checkpoint` derives a domain-separated
`checkpoint:sha256:` digest that must be recorded outside the rehearsal
registry; recovery must supply it through `--expected-digest` and fail closed
on a stale restoration. `registry sync` admits its complete sorted batch or
rolls the complete batch back.

`idm inspect` and `idm export-json` establish no trust. The diagnostic JSON view is never signed authority. `idm import-json` accepts unsigned drafts only.

For authenticated mounting, use `idm challenge issue`, sign it with `idm challenge sign`, and pass the proof to `idm mount`. A copied public artifact without its current authorized private key cannot mount.

Run `idm --help` and each subcommand's `--help` for exact usage. The [CLI map](docs/cli.md) explains the command families and their trust implications.

## Normative order

1. `docs/spec/`
2. accepted architecture decisions in `docs/adr/`
3. `schemas/idm-v1.cddl` and [signed byte vectors](docs/golden-vectors.md)
4. `SECURITY.md` and `THREAT_MODEL.md`
5. library and CLI behavior

Start with [architecture](docs/architecture.md), [authority](docs/authority-model.md), [relationships](docs/relationship-model.md), [offline behavior](docs/offline-operation.md), and the [security guide](docs/security-guide.md).

## Explicit boundaries

V1 is one private Komistry trust domain. The KOS profile supplies a
single-writer rehearsal allocation ledger; it is not a federated or globally
deployed registry. V1 does not implement blockchain, public identity discovery,
transfer, sale, licensing, cloning, or biometric proofing. Cryptography proves
what an authorized issuer attested; it cannot make false enrollment evidence
true.
