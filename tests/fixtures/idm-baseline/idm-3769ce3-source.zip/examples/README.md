# Bootstrap Example

The `*.idm.json` files are human-readable, unsigned authoring drafts. They illustrate direct identity relationships and can be normalized with `idm import-json`; they are not signed identity authority.

`bootstrap_demo.py` creates a fresh private demo trust domain and real signed artifacts for Arthur, Komistry Labs, Alisya, and Nova. It retains their revision history, builds the verified registry, and writes the resolved Nova-to-Arthur evidence path.

The output contains randomly generated fake development keys. Do not commit or reuse it as a real identity environment.

```bash
python examples/bootstrap_demo.py --output /tmp/idm-bootstrap
```

The script prompts for an encrypted-vault passphrase. For automation, `--passphrase-file` requires a regular current-user-owned file with mode `0600` or stricter.
