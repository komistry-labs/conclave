"""Create the Arthur -> Komistry Labs -> agents IDM bootstrap scenario."""

from __future__ import annotations

import argparse
import os
from pathlib import Path

from idm.authority import (
    ISSUANCE_KEY_RELATIVE_PATH,
    TRUST_BUNDLE_FILENAME,
    initialize_authority,
    issue_from_authority,
    sign_successor_from_authority,
)
from idm.container import parse_artifact
from idm.files import read_bytes_limited, write_json_exclusive
from idm.graph import GraphResolver
from idm.manifest import create_draft, write_draft
from idm.registry import Registry
from idm.relationships import (
    add_relationship_reference_revision,
    add_relationship_revision,
    required_relationship_scope,
)
from idm.secretsio import obtain_passphrase
from idm.timeutil import now_utc
from idm.trust import load_trust_bundle
from idm.vault import read_key_file


def _read(path: Path) -> bytes:
    return read_bytes_limited(path, max_bytes=1024 * 1024)


def run_demo(output: Path, *, passphrase: str) -> dict[str, object]:
    output = output.resolve()
    try:
        os.mkdir(output, 0o700)
    except FileExistsError as exc:
        raise RuntimeError(f"refusing to use existing output directory {output}") from exc

    authority_dir = output / "authority"
    initialize_authority(
        authority_dir,
        canonical_name="komistry-root-authority",
        passphrase=passphrase,
    )
    trust = load_trust_bundle(authority_dir / TRUST_BUNDLE_FILENAME)
    issuance_record = read_key_file(authority_dir / ISSUANCE_KEY_RELATIVE_PATH)
    issuer = trust.find_anchor(issuance_record.kid)
    if issuer is None:
        raise RuntimeError("demo issuance delegation did not resolve")

    artifacts: list[bytes] = []

    def issue(name: str, entity_type: str) -> tuple[bytes, Path]:
        draft_path = output / f"{name}.draft.json"
        artifact_path = output / f"{name}.r1.idm"
        write_draft(draft_path, create_draft(entity_type=entity_type, canonical_name=name))
        issue_from_authority(
            draft_path,
            authority_dir,
            passphrase=passphrase,
            output_path=artifact_path,
        )
        artifact = _read(artifact_path)
        artifacts.append(artifact)
        return artifact, artifact_path

    arthur, _ = issue("arthur", "human")
    lab, _ = issue("komistry-labs", "laboratory")
    alisya, _ = issue("alisya", "agent")
    nova, _ = issue("nova", "agent")

    def add_edge(
        source: bytes,
        target: bytes,
        relationship_type: str,
        filename: str,
    ) -> tuple[bytes, str]:
        target_artifact = parse_artifact(target)
        timestamp = now_utc()
        revision, rid = add_relationship_revision(
            parse_artifact(source),
            relationship_type=relationship_type,
            target_eid=target_artifact.revision.entity_id,
            target_mid=target_artifact.revision.manifest_id,
            issued_by_eid=issuer.signer_eid,
            issued_by_mid=issuer.signer_mid,
            timestamp=timestamp,
        )
        path = output / filename
        sign_successor_from_authority(
            source,
            revision,
            authority_dir,
            passphrase=passphrase,
            required_scopes=[
                "relationship.manage",
                required_relationship_scope(relationship_type),
            ],
            output_path=path,
        )
        artifact = _read(path)
        artifacts.append(artifact)
        return artifact, rid

    def add_reference(
        target: bytes,
        authoritative: bytes,
        rid: str,
        filename: str,
    ) -> bytes:
        timestamp = now_utc()
        revision = add_relationship_reference_revision(
            parse_artifact(target),
            authoritative_artifact=parse_artifact(authoritative),
            relationship_id=rid,
            issued_by_eid=issuer.signer_eid,
            issued_by_mid=issuer.signer_mid,
            timestamp=timestamp,
        )
        path = output / filename
        sign_successor_from_authority(
            target,
            revision,
            authority_dir,
            passphrase=passphrase,
            required_scopes=[
                "relationship.manage",
                required_relationship_scope(revision.relationships.references[-1].local_role),
            ],
            output_path=path,
        )
        artifact = _read(path)
        artifacts.append(artifact)
        return artifact

    arthur2, owns_lab = add_edge(arthur, lab, "owns", "arthur.r2.idm")
    lab2 = add_reference(lab, arthur2, owns_lab, "komistry-labs.r2.idm")

    lab3, governs_alisya = add_edge(lab2, alisya, "governs", "komistry-labs.r3.idm")
    alisya2 = add_reference(alisya, lab3, governs_alisya, "alisya.r2.idm")

    lab4, governs_nova = add_edge(lab3, nova, "governs", "komistry-labs.r4.idm")
    nova2 = add_reference(nova, lab4, governs_nova, "nova.r2.idm")
    nova3, belongs_to_lab = add_edge(nova2, lab4, "belongs_to", "nova.r3.idm")
    lab5 = add_reference(lab4, nova3, belongs_to_lab, "komistry-labs.r5.idm")

    registry_path = output / "registry.db"
    with Registry(registry_path) as registry:
        for artifact in artifacts:
            registry.add(artifact, trust)
        resolver = GraphResolver(registry, trust)
        path = resolver.path(
            parse_artifact(nova3).revision.entity_id,
            parse_artifact(arthur2).revision.entity_id,
            allowed_types={"belongs_to", "owned_by"},
        )
        children = resolver.children(parse_artifact(lab5).revision.entity_id)
        registry_errors = registry.verify(trust)

    result: dict[str, object] = {
        "authority": str(authority_dir),
        "entities": {
            "arthur": parse_artifact(arthur2).revision.entity_id,
            "komistry_labs": parse_artifact(lab5).revision.entity_id,
            "alisya": parse_artifact(alisya2).revision.entity_id,
            "nova": parse_artifact(nova3).revision.entity_id,
        },
        "heads": {
            "arthur": parse_artifact(arthur2).vid,
            "komistry_labs": parse_artifact(lab5).vid,
            "alisya": parse_artifact(alisya2).vid,
            "nova": parse_artifact(nova3).vid,
        },
        "lab_children": [edge.model_dump(mode="json") for edge in children],
        "nova_to_arthur": path.model_dump(mode="json"),
        "registry": str(registry_path),
        "registry_errors": registry_errors,
        "revision_artifacts": len(artifacts),
    }
    write_json_exclusive(output / "bootstrap-result.json", result)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--passphrase-file", type=Path)
    args = parser.parse_args()
    result = run_demo(
        args.output,
        passphrase=obtain_passphrase(args.passphrase_file, confirm=True),
    )
    print(
        f"created {result['revision_artifacts']} signed revisions; "
        f"result: {args.output / 'bootstrap-result.json'}"
    )


if __name__ == "__main__":
    main()
