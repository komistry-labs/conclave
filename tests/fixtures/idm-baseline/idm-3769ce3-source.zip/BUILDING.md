# Reproducible package build

Install the exact versions in `requirements.lock`, including the build backend, then build without isolation so the lock controls the toolchain:

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
export SOURCE_DATE_EPOCH=1784678400
.venv/bin/python -m pip wheel --no-deps --no-build-isolation --wheel-dir dist .
shasum -a 256 dist/idm_reference-0.1.0.dev0-py3-none-any.whl
```

Use one reviewed `SOURCE_DATE_EPOCH` for every builder, normally the release commit time. The audit build produced byte-identical wheels in consecutive isolated output directories with the pinned epoch. Do not run concurrent setuptools builds against the same source checkout because they share the local `build/` staging directory.

The current lock fixes versions but does not contain artifact hashes. Before a production release, resolve the lock from an approved package mirror, add hashes for every supported platform, record build-environment provenance, and compare outputs from independent builders.
