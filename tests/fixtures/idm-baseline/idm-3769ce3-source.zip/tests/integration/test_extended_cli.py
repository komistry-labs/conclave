"""CLI coverage for subject authentication, registry, lineage, and successors."""

from __future__ import annotations

import json

from idm.authority import TRUST_BUNDLE_FILENAME
from idm.cli import run
from idm.container import parse_artifact
from idm.identifiers import new_eid
from idm.trust import load_trust_bundle


def _secret_file(tmp_path) -> str:
    path = tmp_path / "vault-input"
    path.write_text("correct horse battery staple\n", encoding="utf-8")
    path.chmod(0o600)
    return str(path)


def test_cli_subject_proof_mount_and_governed_successor(tmp_path, capsys) -> None:
    vault_input = _secret_file(tmp_path)
    authority = tmp_path / "authority"
    subject_key = tmp_path / "subject.idmk"
    draft = tmp_path / "agent.json"
    genesis = tmp_path / "agent-r1.idm"
    suspended = tmp_path / "agent-r2.idm"
    database = tmp_path / "registry.db"
    sessions = tmp_path / "sessions.db"
    challenge = tmp_path / "challenge.json"
    proof = tmp_path / "subject.proof.cose"

    assert (
        run(
            [
                "authority",
                "init",
                "--name",
                "root",
                "--output",
                str(authority),
                "--passphrase-file",
                vault_input,
            ]
        )
        == 0
    )
    capsys.readouterr()
    assert (
        run(
            [
                "key",
                "generate",
                "--output",
                str(subject_key),
                "--passphrase-file",
                vault_input,
            ]
        )
        == 0
    )
    capsys.readouterr()
    assert (
        run(
            [
                "create",
                "--type",
                "agent",
                "--name",
                "subject-agent",
                "--subject-key",
                str(subject_key),
                "--output",
                str(draft),
            ]
        )
        == 0
    )
    capsys.readouterr()
    assert (
        run(
            [
                "issue",
                str(draft),
                "--authority",
                str(authority),
                "--output",
                str(genesis),
                "--passphrase-file",
                vault_input,
            ]
        )
        == 0
    )
    capsys.readouterr()
    trust = authority / TRUST_BUNDLE_FILENAME
    assert (
        run(
            [
                "registry",
                "add",
                str(genesis),
                "--database",
                str(database),
                "--trust",
                str(trust),
            ]
        )
        == 0
    )
    capsys.readouterr()

    runtime_eid = new_eid()
    assert (
        run(
            [
                "challenge",
                "issue",
                str(genesis),
                "--runtime-eid",
                runtime_eid,
                "--action",
                "mount",
                "--sessions",
                str(sessions),
                "--output",
                str(challenge),
            ]
        )
        == 0
    )
    capsys.readouterr()
    assert (
        run(
            [
                "challenge",
                "sign",
                str(challenge),
                "--key",
                str(subject_key),
                "--output",
                str(proof),
                "--passphrase-file",
                vault_input,
            ]
        )
        == 0
    )
    capsys.readouterr()
    assert (
        run(
            [
                "mount",
                str(genesis),
                "--proof",
                str(proof),
                "--trust",
                str(trust),
                "--registry",
                str(database),
                "--sessions",
                str(sessions),
                "--runtime-eid",
                runtime_eid,
                "--action",
                "mount",
            ]
        )
        == 0
    )
    mounted = json.loads(capsys.readouterr().out)
    assert mounted["lifecycle_state"] == "issued"
    assert mounted["capabilities"] == []

    assert (
        run(
            [
                "suspend",
                str(genesis),
                "--authority",
                str(authority),
                "--output",
                str(suspended),
                "--passphrase-file",
                vault_input,
            ]
        )
        == 0
    )
    capsys.readouterr()
    assert (
        run(
            [
                "lineage",
                "verify",
                str(genesis),
                str(suspended),
                "--trust",
                str(trust),
            ]
        )
        == 0
    )
    lineage = json.loads(capsys.readouterr().out)
    assert [item["revision"] for item in lineage] == [1, 2]

    bundle = load_trust_bundle(trust)
    signer = parse_artifact(genesis.read_bytes()).signatures[0]
    delegated = bundle.find_anchor(signer.kid)
    assert delegated is not None and delegated.delegation_id is not None
    revocation = tmp_path / "issuance-delegation.revocation.cose"
    assert (
        run(
            [
                "revoke",
                "--authority",
                str(authority),
                "--target-type",
                "delegation",
                "--target-id",
                delegated.delegation_id,
                "--reason",
                "security.delegation_compromise",
                "--output",
                str(revocation),
                "--passphrase-file",
                vault_input,
            ]
        )
        == 0
    )
    capsys.readouterr()

    revoked_database = tmp_path / "revoked-registry.db"
    assert (
        run(
            [
                "registry",
                "add",
                str(genesis),
                "--database",
                str(revoked_database),
                "--trust",
                str(trust),
                "--revocation",
                str(revocation),
            ]
        )
        == 1
    )
    assert "artifact is revoked" in capsys.readouterr().err

    rejected_draft = tmp_path / "rejected-agent.json"
    assert (
        run(
            [
                "create",
                "--type",
                "agent",
                "--name",
                "revoked-issuer-attempt",
                "--output",
                str(rejected_draft),
            ]
        )
        == 0
    )
    capsys.readouterr()
    rejected_artifact = tmp_path / "rejected-agent.idm"
    assert (
        run(
            [
                "issue",
                str(rejected_draft),
                "--authority",
                str(authority),
                "--output",
                str(rejected_artifact),
                "--passphrase-file",
                vault_input,
                "--revocation",
                str(revocation),
            ]
        )
        == 1
    )
    assert "artifact is revoked" in capsys.readouterr().err
    assert not rejected_artifact.exists()

    challenge2 = tmp_path / "challenge-revoked.json"
    proof2 = tmp_path / "subject-revoked.proof.cose"
    assert (
        run(
            [
                "challenge",
                "issue",
                str(genesis),
                "--runtime-eid",
                runtime_eid,
                "--action",
                "mount",
                "--sessions",
                str(sessions),
                "--output",
                str(challenge2),
            ]
        )
        == 0
    )
    capsys.readouterr()
    assert (
        run(
            [
                "challenge",
                "sign",
                str(challenge2),
                "--key",
                str(subject_key),
                "--output",
                str(proof2),
                "--passphrase-file",
                vault_input,
            ]
        )
        == 0
    )
    capsys.readouterr()
    assert (
        run(
            [
                "mount",
                str(genesis),
                "--proof",
                str(proof2),
                "--trust",
                str(trust),
                "--registry",
                str(database),
                "--sessions",
                str(sessions),
                "--runtime-eid",
                runtime_eid,
                "--action",
                "mount",
                "--revocation",
                str(revocation),
            ]
        )
        == 1
    )
    assert "artifact is revoked" in capsys.readouterr().err
