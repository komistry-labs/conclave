"""End-to-end authority and CLI workflow."""

from __future__ import annotations

import json
import os

from idm.authority import (
    AUTHORITY_ARTIFACT_FILENAME,
    ROOT_KEY_RELATIVE_PATH,
    TRUST_BUNDLE_FILENAME,
)
from idm.cli import run
from idm.errors import FileSafetyError
from idm.files import write_bytes_exclusive
from idm.manifest import create_draft, write_draft
from idm.models import ManifestDraft


def _secret_file(tmp_path) -> str:
    secret = tmp_path / "passphrase.txt"
    secret.write_text("correct horse battery staple\n", encoding="utf-8")
    secret.chmod(0o600)
    return str(secret)


def test_cli_initializes_issues_and_verifies_offline(tmp_path, capsys) -> None:
    passphrase_file = _secret_file(tmp_path)
    authority = tmp_path / "authority"
    draft = tmp_path / "agent.idm.json"
    artifact = tmp_path / "agent.idm"

    assert (
        run(
            [
                "authority",
                "init",
                "--name",
                "komistry-root",
                "--output",
                str(authority),
                "--passphrase-file",
                passphrase_file,
            ]
        )
        == 0
    )
    bootstrap = json.loads(capsys.readouterr().out)
    assert bootstrap["authority_vid"].startswith("vid:sha256:")
    if os.name != "nt":
        assert (authority / ROOT_KEY_RELATIVE_PATH).stat().st_mode & 0o077 == 0
    assert (authority / TRUST_BUNDLE_FILENAME).is_file()
    assert (authority / AUTHORITY_ARTIFACT_FILENAME).is_file()

    assert (
        run(
            [
                "create",
                "--type",
                "agent",
                "--name",
                "planning-agent",
                "--output",
                str(draft),
            ]
        )
        == 0
    )
    created = json.loads(capsys.readouterr().out)
    assert created["entity_id"].startswith("eid:")

    assert (
        run(
            [
                "issue",
                str(draft),
                "--authority",
                str(authority),
                "--output",
                str(artifact),
                "--passphrase-file",
                passphrase_file,
            ]
        )
        == 0
    )
    issued = json.loads(capsys.readouterr().out)
    assert issued["trusted"] is True

    assert (
        run(
            [
                "verify",
                str(artifact),
                "--trust",
                str(authority / TRUST_BUNDLE_FILENAME),
            ]
        )
        == 0
    )
    verified = json.loads(capsys.readouterr().out)
    assert verified["status"] == "trusted"
    assert verified["entity_id"] == created["entity_id"]

    assert run(["inspect", str(artifact)]) == 0
    inspected = json.loads(capsys.readouterr().out)
    assert inspected["warning"] == "inspection establishes structure, not trust"


def test_cli_refuses_to_overwrite_existing_outputs(tmp_path, capsys) -> None:
    passphrase_file = _secret_file(tmp_path)
    draft = tmp_path / "draft.json"
    assert run(["create", "--type", "lab", "--name", "lab-one", "--output", str(draft)]) == 0
    capsys.readouterr()
    assert run(["create", "--type", "lab", "--name", "lab-two", "--output", str(draft)]) == 1
    assert "refusing to overwrite" in capsys.readouterr().err

    authority = tmp_path / "authority"
    assert (
        run(
            [
                "authority",
                "init",
                "--name",
                "root",
                "--output",
                str(authority),
                "--passphrase-file",
                passphrase_file,
            ]
        )
        == 0
    )
    capsys.readouterr()
    assert (
        run(
            [
                "authority",
                "init",
                "--name",
                "replacement",
                "--output",
                str(authority),
                "--passphrase-file",
                passphrase_file,
            ]
        )
        == 1
    )
    assert "refusing to initialize existing directory" in capsys.readouterr().err


def test_exclusive_writer_raises_for_existing_file(tmp_path) -> None:
    target = tmp_path / "existing"
    write_bytes_exclusive(target, b"first")
    try:
        write_bytes_exclusive(target, b"second")
    except FileSafetyError:
        pass
    else:
        raise AssertionError("exclusive writer overwrote an existing file")
    assert target.read_bytes() == b"first"


def test_authority_issuance_rejects_duplicate_eid_and_mid(tmp_path, capsys) -> None:
    passphrase_file = _secret_file(tmp_path)
    authority = tmp_path / "authority"
    assert (
        run(
            [
                "authority",
                "init",
                "--name",
                "root",
                "--output",
                str(authority),
                "--passphrase-file",
                passphrase_file,
            ]
        )
        == 0
    )
    capsys.readouterr()

    original = create_draft(entity_type="agent", canonical_name="original")
    original_path = tmp_path / "original.json"
    write_draft(original_path, original)
    assert (
        run(
            [
                "issue",
                str(original_path),
                "--authority",
                str(authority),
                "--output",
                str(tmp_path / "original.idm"),
                "--passphrase-file",
                passphrase_file,
            ]
        )
        == 0
    )
    capsys.readouterr()

    distinct = create_draft(entity_type="agent", canonical_name="distinct")
    duplicate_eid_values = distinct.model_dump(mode="python")
    duplicate_eid_values["entity_id"] = original.entity_id
    duplicate_eid = ManifestDraft.model_validate(duplicate_eid_values)
    duplicate_eid_path = tmp_path / "duplicate-eid.json"
    write_draft(duplicate_eid_path, duplicate_eid)
    assert (
        run(
            [
                "issue",
                str(duplicate_eid_path),
                "--authority",
                str(authority),
                "--output",
                str(tmp_path / "duplicate-eid.idm"),
                "--passphrase-file",
                passphrase_file,
            ]
        )
        == 1
    )
    assert "entity ID is already allocated" in capsys.readouterr().err
    assert not (tmp_path / "duplicate-eid.idm").exists()

    duplicate_mid_values = distinct.model_dump(mode="python")
    duplicate_mid_values["manifest_id"] = original.manifest_id
    duplicate_mid = ManifestDraft.model_validate(duplicate_mid_values)
    duplicate_mid_path = tmp_path / "duplicate-mid.json"
    write_draft(duplicate_mid_path, duplicate_mid)
    assert (
        run(
            [
                "issue",
                str(duplicate_mid_path),
                "--authority",
                str(authority),
                "--output",
                str(tmp_path / "duplicate-mid.idm"),
                "--passphrase-file",
                passphrase_file,
            ]
        )
        == 1
    )
    assert "duplicate revision number or divergent fork" in capsys.readouterr().err
    assert not (tmp_path / "duplicate-mid.idm").exists()
