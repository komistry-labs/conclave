"""Signed offline packages, freshness limits, and rollback resistance."""

from __future__ import annotations

import pytest

from idm.authority import (
    ALLOCATION_KEY_RELATIVE_PATH,
    ISSUANCE_KEY_RELATIVE_PATH,
    REGISTRY_KEY_RELATIVE_PATH,
    TRUST_BUNDLE_FILENAME,
    initialize_authority,
    issue_from_authority,
)
from idm.container import parse_artifact
from idm.errors import OfflineError
from idm.files import read_bytes_limited
from idm.identifiers import format_k1_allocation_number, new_rid
from idm.manifest import create_draft, issue_genesis, write_draft
from idm.models import (
    Capabilities,
    CapabilityGrant,
    CapabilityRisk,
    ExternalIdentifierBinding,
    ManifestDraft,
)
from idm.offline import (
    TrustedTimeStore,
    authorize_offline_capability,
    create_offline_bundle,
    verify_offline_bundle,
)
from idm.policy import KOMISTRY_V1_POLICY, PolicyProfile
from idm.trust import load_trust_bundle
from idm.vault import decrypt_key, read_key_file

T0 = "2026-07-22T00:00:00Z"
T30 = "2026-07-22T00:00:30Z"
T61 = "2026-07-22T00:01:01Z"
T2 = "2026-07-22T00:02:00Z"
T10 = "2026-07-22T00:10:00Z"
VAULT_INPUT = "correct horse battery staple"


def _fixture(tmp_path, *, with_capabilities: bool = False):
    authority_dir = tmp_path / "authority"
    initialize_authority(
        authority_dir,
        canonical_name="komistry-root",
        passphrase=VAULT_INPUT,
        timestamp=T0,
    )
    bundle = load_trust_bundle(authority_dir / TRUST_BUNDLE_FILENAME)
    draft = create_draft(entity_type="agent", canonical_name="offline-agent")
    if with_capabilities:
        issuance_key = decrypt_key(
            read_key_file(authority_dir / ISSUANCE_KEY_RELATIVE_PATH), VAULT_INPUT
        )
        issuer = bundle.find_anchor(issuance_key.kid)
        assert issuer is not None
        capabilities = Capabilities(
            declared=["local.read", "external.publish"],
            grants=[
                CapabilityGrant(
                    grant_id="rid:aaaaaaaaaaaaaaaaaaaaaaaaaa",
                    capability="local.read",
                    granted_by_eid=issuer.signer_eid,
                    granted_by_mid=issuer.signer_mid,
                    grantee_eid=draft.entity_id,
                    grantee_mid=draft.manifest_id,
                    resource_scope=["local/*"],
                    valid_from=T0,
                    risk=CapabilityRisk.LOW,
                ),
                CapabilityGrant(
                    grant_id="rid:bbbbbbbbbbbbbbbbbbbbbbbbbb",
                    capability="external.publish",
                    granted_by_eid=issuer.signer_eid,
                    granted_by_mid=issuer.signer_mid,
                    grantee_eid=draft.entity_id,
                    grantee_mid=draft.manifest_id,
                    resource_scope=["external/*"],
                    valid_from=T0,
                    risk=CapabilityRisk.HIGH,
                ),
            ],
        )
        values = draft.model_dump(mode="python")
        values["capabilities"] = capabilities
        draft = ManifestDraft.model_validate(values)
    draft_path = tmp_path / "draft.json"
    artifact_path = tmp_path / "agent.idm"
    write_draft(draft_path, draft)
    issue_from_authority(
        draft_path,
        authority_dir,
        passphrase=VAULT_INPUT,
        output_path=artifact_path,
        timestamp=T0,
    )
    artifact = read_bytes_limited(artifact_path, max_bytes=1024 * 1024)
    registry_key = decrypt_key(
        read_key_file(authority_dir / REGISTRY_KEY_RELATIVE_PATH), VAULT_INPUT
    )
    return bundle, artifact, registry_key


def _offline_bytes(
    bundle,
    artifact: bytes,
    registry_key,
    *,
    sequence: int,
    verified_as_of: str = T0,
) -> bytes:
    return create_offline_bundle(
        trust_bundle=bundle,
        artifact_bytes=[artifact],
        revocation_bytes=[],
        sequence=sequence,
        generated_at=T0,
        verified_as_of=verified_as_of,
        expires_at=T10,
        private_key=registry_key.private_key,
        kid=registry_key.kid,
        max_age_seconds={"low": 60, "medium": 30, "high": 0},
    )


def test_cached_offline_verification_succeeds_without_network(tmp_path) -> None:
    bundle, artifact, registry_key = _fixture(tmp_path)
    package = _offline_bytes(bundle, artifact, registry_key, sequence=1)
    with TrustedTimeStore(tmp_path / "trusted-time.db") as time_store:
        verified = verify_offline_bundle(
            package,
            pinned_trust=bundle,
            evaluation_time=T30,
            time_store=time_store,
        )
    assert verified.payload.heads == {
        parse_artifact(artifact).revision.manifest_id: parse_artifact(artifact).vid
    }
    assert verified.signer_kid == registry_key.kid


def test_offline_bundle_rejects_cross_lineage_kos_identifier_reuse(tmp_path) -> None:
    authority_dir = tmp_path / "authority"
    initialize_authority(
        authority_dir,
        canonical_name="komistry-root",
        passphrase=VAULT_INPUT,
        timestamp=T0,
    )
    bundle = load_trust_bundle(authority_dir / TRUST_BUNDLE_FILENAME)
    allocation_key = decrypt_key(
        read_key_file(authority_dir / ALLOCATION_KEY_RELATIVE_PATH), VAULT_INPUT
    )
    allocator = bundle.find_anchor(allocation_key.kid)
    registry_key = decrypt_key(
        read_key_file(authority_dir / REGISTRY_KEY_RELATIVE_PATH), VAULT_INPUT
    )
    assert allocator is not None
    canonical_id = "urn:uuid:019c2f10-7a01-7b2c-8d3e-4f5061728394"
    artifacts: list[bytes] = []
    for ordinal in (1, 2):
        rid = new_rid()
        bindings = [
            ExternalIdentifierBinding(
                scheme="kos-canonical-id",
                value=canonical_id,
                allocation_event_id=rid,
                allocation_authority_eid=allocator.signer_eid,
                allocation_authority_mid=allocator.signer_mid,
            ),
            ExternalIdentifierBinding(
                scheme="kos-allocation-number",
                value=format_k1_allocation_number(ordinal),
                allocation_event_id=rid,
                allocation_authority_eid=allocator.signer_eid,
                allocation_authority_mid=allocator.signer_mid,
            ),
        ]
        artifacts.append(
            issue_genesis(
                create_draft(
                    entity_type="initiative",
                    canonical_name=f"conflict-{ordinal}",
                    external_identifiers=bindings,
                ),
                private_key=allocation_key.private_key,
                kid=allocation_key.kid,
                signer_eid=allocator.signer_eid,
                signer_mid=allocator.signer_mid,
                issued_at=T0,
                scope=["identity.issue", "identity.allocate"],
            )
        )
    package = create_offline_bundle(
        trust_bundle=bundle,
        artifact_bytes=artifacts,
        revocation_bytes=[],
        sequence=1,
        generated_at=T0,
        verified_as_of=T0,
        expires_at=T10,
        private_key=registry_key.private_key,
        kid=registry_key.kid,
    )

    with pytest.raises(OfflineError, match="reuses a KOS identifier"):
        verify_offline_bundle(package, pinned_trust=bundle, evaluation_time=T30)


def test_expired_and_tampered_packages_are_rejected(tmp_path) -> None:
    bundle, artifact, registry_key = _fixture(tmp_path)
    package = _offline_bytes(bundle, artifact, registry_key, sequence=1)
    with pytest.raises(OfflineError, match="expired"):
        verify_offline_bundle(package, pinned_trust=bundle, evaluation_time="2026-07-23T00:00:00Z")

    tampered = bytearray(package)
    tampered[-1] ^= 1
    with pytest.raises(OfflineError, match="cryptographically invalid"):
        verify_offline_bundle(bytes(tampered), pinned_trust=bundle, evaluation_time=T30)


def test_signed_time_checkpoint_rejects_sequence_and_time_rollback(tmp_path) -> None:
    bundle, artifact, registry_key = _fixture(tmp_path)
    old = _offline_bytes(bundle, artifact, registry_key, sequence=1, verified_as_of=T0)
    newer = _offline_bytes(bundle, artifact, registry_key, sequence=2, verified_as_of=T2)
    high_sequence_old_time = _offline_bytes(
        bundle, artifact, registry_key, sequence=3, verified_as_of=T0
    )
    with TrustedTimeStore(tmp_path / "trusted-time.db") as time_store:
        verify_offline_bundle(newer, pinned_trust=bundle, evaluation_time=T2, time_store=time_store)
        with pytest.raises(OfflineError, match="rollback"):
            verify_offline_bundle(
                old, pinned_trust=bundle, evaluation_time=T2, time_store=time_store
            )
        with pytest.raises(OfflineError, match="rollback"):
            verify_offline_bundle(
                high_sequence_old_time,
                pinned_trust=bundle,
                evaluation_time=T2,
                time_store=time_store,
            )


def test_offline_capability_risk_and_freshness_are_enforced(tmp_path) -> None:
    bundle, artifact, registry_key = _fixture(tmp_path, with_capabilities=True)
    package = _offline_bytes(bundle, artifact, registry_key, sequence=1)
    verified_fresh = verify_offline_bundle(package, pinned_trust=bundle, evaluation_time=T30)
    revision = parse_artifact(artifact).revision
    allowed = authorize_offline_capability(
        verified_fresh,
        revision,
        capability="local.read",
        resource="local/cache",
        operation="read",
        evaluation_time=T30,
    )
    assert allowed.risk is CapabilityRisk.LOW
    with pytest.raises(OfflineError, match="high-risk"):
        authorize_offline_capability(
            verified_fresh,
            revision,
            capability="external.publish",
            resource="external/report",
            operation="publish",
            evaluation_time=T30,
        )

    verified_stale = verify_offline_bundle(package, pinned_trust=bundle, evaluation_time=T61)
    with pytest.raises(OfflineError, match="low-risk"):
        authorize_offline_capability(
            verified_stale,
            revision,
            capability="local.read",
            resource="local/cache",
            operation="read",
            evaluation_time=T61,
        )


def test_offline_package_cannot_replace_locally_pinned_policy(tmp_path) -> None:
    bundle, artifact, registry_key = _fixture(tmp_path)
    values = KOMISTRY_V1_POLICY.model_dump(mode="python")
    values["policy_id"] = "attacker-selected-policy"
    substituted_policy = PolicyProfile.model_validate(values)
    package = create_offline_bundle(
        trust_bundle=bundle,
        artifact_bytes=[artifact],
        revocation_bytes=[],
        sequence=1,
        generated_at=T0,
        verified_as_of=T0,
        expires_at=T10,
        private_key=registry_key.private_key,
        kid=registry_key.kid,
        policy=substituted_policy,
    )
    with pytest.raises(OfflineError, match="locally pinned policy"):
        verify_offline_bundle(package, pinned_trust=bundle, evaluation_time=T30)
