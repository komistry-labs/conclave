"""Subject-control authentication and effective runtime capabilities."""

from __future__ import annotations

from dataclasses import dataclass

import pytest
from conftest import FIXED_TIME, RootFixture

from idm.capabilities import (
    authorize_capability,
    declare_capability_revision,
    deny_capability_revision,
    effective_capabilities,
    grant_capability_revision,
)
from idm.container import Signer, parse_artifact
from idm.errors import RuntimeAuthorizationError, SignatureError
from idm.keybindings import create_public_key_binding
from idm.lifecycle import transition_revision
from idm.lineage import issue_successor
from idm.manifest import create_draft, issue_genesis
from idm.models import CapabilityRisk, KeyPurpose, LifecycleState, SignatureMetadata
from idm.registry import Registry
from idm.revocation import (
    RevocationSet,
    RevocationTargetType,
    create_revocation_statement,
    sign_revocation,
    verify_revocation,
)
from idm.runtime import Runtime, SessionStore, sign_subject_proof
from idm.vault import GeneratedKey, generate_key

T1 = "2026-07-22T00:01:00Z"
T2 = "2026-07-22T00:02:00Z"
T3 = "2026-07-22T00:03:00Z"
T4 = "2026-07-22T00:04:00Z"


@dataclass(frozen=True, slots=True)
class CapabilityChain:
    subject_key: GeneratedKey
    genesis: bytes
    active: bytes
    declared: bytes
    granted: bytes


def _sign(root: RootFixture, timestamp: str, *scopes: str) -> Signer:
    return Signer(
        private_key=root.private_key,
        kid=root.kid,
        metadata=SignatureMetadata(
            signer_eid=root.eid,
            signer_mid=root.mid,
            role="identity_authority",
            scope=["manifest.revise", *scopes],
            signed_at=timestamp,
            policy_ref="komistry-policy-v1",
        ),
    )


def _chain(root: RootFixture) -> CapabilityChain:
    subject_key = generate_key()
    binding = create_public_key_binding(
        subject_key.public_key,
        purposes=[KeyPurpose.SUBJECT_CONTROL, KeyPurpose.OPERATION],
        valid_from=FIXED_TIME,
    )
    genesis = issue_genesis(
        create_draft(entity_type="agent", canonical_name="nova", keys=[binding]),
        private_key=root.private_key,
        kid=root.kid,
        signer_eid=root.eid,
        signer_mid=root.mid,
        issued_at=FIXED_TIME,
    )
    active_revision = transition_revision(
        parse_artifact(genesis),
        target=LifecycleState.ACTIVE,
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        timestamp=T1,
    )
    active = issue_successor(genesis, active_revision, [_sign(root, T1, "lifecycle.change")])
    declared_revision = declare_capability_revision(
        parse_artifact(active),
        capability="research.summarize",
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        timestamp=T2,
    )
    declared = issue_successor(
        active,
        declared_revision,
        [_sign(root, T2, "capability.declare")],
    )
    granted_revision, _grant_id = grant_capability_revision(
        parse_artifact(declared),
        capability="research.summarize",
        granted_by_eid=root.eid,
        granted_by_mid=root.mid,
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        timestamp=T3,
        resource_scope=["project:komistry/*"],
        risk=CapabilityRisk.LOW,
        constraints={"max_input_bytes": 4096, "allowed_operations": ["summarize"]},
    )
    granted = issue_successor(
        declared,
        granted_revision,
        [_sign(root, T3, "capability.grant")],
    )
    return CapabilityChain(subject_key, genesis, active, declared, granted)


def test_declaration_alone_never_becomes_effective(root: RootFixture) -> None:
    chain = _chain(root)
    declared = parse_artifact(chain.declared).revision
    assert declared.capabilities.declared == ["research.summarize"]
    assert effective_capabilities(declared, at_time=T3) == []
    with pytest.raises(RuntimeAuthorizationError, match="not effectively authorized"):
        authorize_capability(
            declared,
            capability="research.summarize",
            resource="project:komistry/report",
            operation="summarize",
            at_time=T3,
            online=True,
        )


def test_valid_grant_activates_and_constraints_fail_closed(root: RootFixture) -> None:
    revision = parse_artifact(_chain(root).granted).revision
    allowed = authorize_capability(
        revision,
        capability="research.summarize",
        resource="project:komistry/report",
        operation="summarize",
        at_time=T3,
        online=True,
        input_bytes=4096,
    )
    assert allowed.capability == "research.summarize"
    for resource, operation, input_bytes in (
        ("project:other/report", "summarize", 1),
        ("project:komistry/report", "delete", 1),
        ("project:komistry/report", "summarize", 4097),
    ):
        with pytest.raises(RuntimeAuthorizationError):
            authorize_capability(
                revision,
                capability="research.summarize",
                resource=resource,
                operation=operation,
                at_time=T3,
                online=True,
                input_bytes=input_bytes,
            )


def test_governed_denial_removes_effective_grant(root: RootFixture) -> None:
    chain = _chain(root)
    denied_revision, _denial_id = deny_capability_revision(
        parse_artifact(chain.granted),
        capability="research.summarize",
        denied_by_eid=root.eid,
        denied_by_mid=root.mid,
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        timestamp=T4,
        reason_code="policy.revoked",
    )
    denied = issue_successor(
        chain.granted,
        denied_revision,
        [_sign(root, T4, "capability.grant")],
    )
    assert effective_capabilities(parse_artifact(denied).revision, at_time=T4) == []


def test_expired_grant_is_not_effective(root: RootFixture) -> None:
    chain = _chain(root)
    expiring_revision, _grant_id = grant_capability_revision(
        parse_artifact(chain.declared),
        capability="research.summarize",
        granted_by_eid=root.eid,
        granted_by_mid=root.mid,
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        timestamp=T3,
        valid_until=T3,
    )
    assert effective_capabilities(expiring_revision, at_time=T4) == []


def test_runtime_requires_current_artifact_fresh_subject_proof_and_prevents_replay(
    root: RootFixture, tmp_path
) -> None:
    chain = _chain(root)
    runtime_eid = parse_artifact(chain.genesis).revision.entity_id.replace("eid:", "eid:", 1)
    with (
        Registry(tmp_path / "registry.db") as registry,
        SessionStore(tmp_path / "sessions.db") as sessions,
    ):
        for artifact in (chain.genesis, chain.active, chain.declared, chain.granted):
            registry.add(artifact, root.bundle)
        runtime = Runtime(
            runtime_eid=runtime_eid,
            registry=registry,
            sessions=sessions,
            clock=lambda: T3,
        )
        challenge = runtime.issue_challenge(
            chain.granted,
            action="research.summarize",
        )
        proof = sign_subject_proof(
            challenge,
            private_key=chain.subject_key.private_key,
            kid=chain.subject_key.kid,
        )
        context = runtime.mount(
            chain.granted,
            trust_bundle=root.bundle,
            subject_proof=proof,
            expected_action="research.summarize",
            capability="research.summarize",
            resource="project:komistry/report",
            operation="summarize",
            input_bytes=1024,
        )
        assert context.authenticated_kid == chain.subject_key.kid
        assert [item.capability for item in context.capabilities] == ["research.summarize"]

        with pytest.raises(RuntimeAuthorizationError, match="already been consumed"):
            runtime.mount(
                chain.granted,
                trust_bundle=root.bundle,
                subject_proof=proof,
                expected_action="research.summarize",
            )


def test_wrong_private_key_and_stale_lineage_cannot_activate(root: RootFixture, tmp_path) -> None:
    chain = _chain(root)
    runtime_eid = parse_artifact(chain.genesis).revision.entity_id
    attacker = generate_key()
    with (
        Registry(tmp_path / "registry.db") as registry,
        SessionStore(tmp_path / "sessions.db") as sessions,
    ):
        for artifact in (chain.genesis, chain.active, chain.declared, chain.granted):
            registry.add(artifact, root.bundle)
        runtime = Runtime(
            runtime_eid=runtime_eid,
            registry=registry,
            sessions=sessions,
            clock=lambda: T3,
        )
        current_challenge = runtime.issue_challenge(chain.granted, action="operate")
        attacker_proof = sign_subject_proof(
            current_challenge,
            private_key=attacker.private_key,
            kid=chain.subject_key.kid,
        )
        with pytest.raises(SignatureError, match="verification failed"):
            runtime.mount(
                chain.granted,
                trust_bundle=root.bundle,
                subject_proof=attacker_proof,
                expected_action="operate",
            )

        stale_challenge = runtime.issue_challenge(chain.declared, action="operate")
        stale_proof = sign_subject_proof(
            stale_challenge,
            private_key=chain.subject_key.private_key,
            kid=chain.subject_key.kid,
        )
        with pytest.raises(RuntimeAuthorizationError, match="current lineage head"):
            runtime.mount(
                chain.declared,
                trust_bundle=root.bundle,
                subject_proof=stale_proof,
                expected_action="operate",
            )


def test_runtime_rejects_expired_challenge_using_trusted_clock(root: RootFixture, tmp_path) -> None:
    chain = _chain(root)
    current_time = [T3]
    with (
        Registry(tmp_path / "registry.db") as registry,
        SessionStore(tmp_path / "sessions.db") as sessions,
    ):
        for artifact in (chain.genesis, chain.active, chain.declared, chain.granted):
            registry.add(artifact, root.bundle)
        runtime = Runtime(
            runtime_eid=parse_artifact(chain.genesis).revision.entity_id,
            registry=registry,
            sessions=sessions,
            clock=lambda: current_time[0],
        )
        challenge = runtime.issue_challenge(chain.granted, action="operate", ttl_seconds=120)
        proof = sign_subject_proof(
            challenge,
            private_key=chain.subject_key.private_key,
            kid=chain.subject_key.kid,
        )
        current_time[0] = "2026-07-22T00:06:00Z"

        with pytest.raises(RuntimeAuthorizationError, match="not currently valid"):
            runtime.mount(
                chain.granted,
                trust_bundle=root.bundle,
                subject_proof=proof,
                expected_action="operate",
            )


def test_revoked_identity_and_retired_head_cannot_operate(root: RootFixture, tmp_path) -> None:
    chain = _chain(root)
    actor = parse_artifact(chain.granted)
    statement = create_revocation_statement(
        target_type=RevocationTargetType.ENTITY,
        target_id=actor.revision.entity_id,
        reason_code="security.compromise",
        effective_at=T4,
        issued_at=T4,
        issuer_eid=root.eid,
        issuer_mid=root.mid,
    )
    revocations = RevocationSet(
        [
            verify_revocation(
                sign_revocation(statement, private_key=root.private_key, kid=root.kid),
                root.bundle,
            )
        ]
    )
    with (
        Registry(tmp_path / "revoked-registry.db") as registry,
        SessionStore(tmp_path / "revoked-sessions.db") as sessions,
    ):
        for artifact in (chain.genesis, chain.active, chain.declared, chain.granted):
            registry.add(artifact, root.bundle)
        runtime = Runtime(
            runtime_eid=actor.revision.entity_id,
            registry=registry,
            sessions=sessions,
            clock=lambda: T4,
        )
        challenge = runtime.issue_challenge(chain.granted, action="operate")
        proof = sign_subject_proof(
            challenge,
            private_key=chain.subject_key.private_key,
            kid=chain.subject_key.kid,
        )
        with pytest.raises(RuntimeAuthorizationError, match="trust verification failed"):
            runtime.mount(
                chain.granted,
                trust_bundle=root.bundle,
                subject_proof=proof,
                expected_action="operate",
                revocations=revocations,
            )

    retired_revision = transition_revision(
        actor,
        target=LifecycleState.RETIRED,
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        timestamp=T4,
    )
    retired = issue_successor(
        chain.granted,
        retired_revision,
        [_sign(root, T4, "lifecycle.change")],
    )
    with (
        Registry(tmp_path / "retired-registry.db") as registry,
        SessionStore(tmp_path / "retired-sessions.db") as sessions,
    ):
        for artifact in (chain.genesis, chain.active, chain.declared, chain.granted, retired):
            registry.add(artifact, root.bundle)
        runtime = Runtime(
            runtime_eid=actor.revision.entity_id,
            registry=registry,
            sessions=sessions,
            clock=lambda: T4,
        )
        challenge = runtime.issue_challenge(retired, action="operate")
        proof = sign_subject_proof(
            challenge,
            private_key=chain.subject_key.private_key,
            kid=chain.subject_key.kid,
        )
        with pytest.raises(RuntimeAuthorizationError, match="does not permit"):
            runtime.mount(
                retired,
                trust_bundle=root.bundle,
                subject_proof=proof,
                expected_action="operate",
            )


def test_unrelated_revocation_does_not_block_mount(root: RootFixture, tmp_path) -> None:
    revoked_chain = _chain(root)
    unaffected_chain = _chain(root)
    revoked_actor = parse_artifact(revoked_chain.granted)
    statement = create_revocation_statement(
        target_type=RevocationTargetType.ENTITY,
        target_id=revoked_actor.revision.entity_id,
        reason_code="security.compromise",
        effective_at=T4,
        issued_at=T4,
        issuer_eid=root.eid,
        issuer_mid=root.mid,
    )
    revocations = RevocationSet(
        [
            verify_revocation(
                sign_revocation(statement, private_key=root.private_key, kid=root.kid),
                root.bundle,
            )
        ]
    )
    with (
        Registry(tmp_path / "registry.db") as registry,
        SessionStore(tmp_path / "sessions.db") as sessions,
    ):
        for artifact in (
            revoked_chain.genesis,
            revoked_chain.active,
            revoked_chain.declared,
            revoked_chain.granted,
            unaffected_chain.genesis,
            unaffected_chain.active,
            unaffected_chain.declared,
            unaffected_chain.granted,
        ):
            registry.add(artifact, root.bundle)
        runtime = Runtime(
            runtime_eid=revoked_actor.revision.entity_id,
            registry=registry,
            sessions=sessions,
            clock=lambda: T4,
        )
        challenge = runtime.issue_challenge(unaffected_chain.granted, action="operate")
        proof = sign_subject_proof(
            challenge,
            private_key=unaffected_chain.subject_key.private_key,
            kid=unaffected_chain.subject_key.kid,
        )

        context = runtime.mount(
            unaffected_chain.granted,
            trust_bundle=root.bundle,
            subject_proof=proof,
            expected_action="operate",
            revocations=revocations,
        )

        assert context.entity_id == parse_artifact(unaffected_chain.granted).revision.entity_id
