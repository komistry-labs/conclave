"""Registry continuity enforcement and evidence-preserving graph resolution."""

from __future__ import annotations

import sqlite3

import pytest
from conftest import FIXED_TIME, RootFixture

from idm.container import Signer, parse_artifact
from idm.errors import GraphError, LineageError, PolicyError, RegistryError
from idm.graph import GraphResolver
from idm.identifiers import format_k1_allocation_number, new_rid
from idm.lifecycle import transition_revision
from idm.lineage import issue_successor
from idm.manifest import create_draft, issue_genesis
from idm.models import ExternalIdentifierBinding, LifecycleState, Revision, SignatureMetadata
from idm.registry import Registry
from idm.relationships import (
    INVERSE_RELATIONSHIPS,
    add_relationship_reference_revision,
    add_relationship_revision,
    inverse_relationship,
    required_relationship_scope,
)
from idm.revocation import (
    RevocationSet,
    RevocationTargetType,
    create_revocation_statement,
    sign_revocation,
    verify_revocation,
)

T1 = "2026-07-22T00:01:00Z"
T2 = "2026-07-22T00:02:00Z"
T3 = "2026-07-22T00:03:00Z"


def test_relationship_inverse_mapping_is_bijective() -> None:
    for relationship_type in INVERSE_RELATIONSHIPS:
        assert inverse_relationship(inverse_relationship(relationship_type)) == relationship_type
    assert inverse_relationship("belongs_to") == "has_member"
    assert inverse_relationship("member_of") == "has_affiliate"


def _genesis(root: RootFixture, entity_type: str, name: str) -> bytes:
    return issue_genesis(
        create_draft(entity_type=entity_type, canonical_name=name),
        private_key=root.private_key,
        kid=root.kid,
        signer_eid=root.eid,
        signer_mid=root.mid,
        issued_at=FIXED_TIME,
    )


def _sign(root: RootFixture, timestamp: str, *scopes: str) -> Signer:
    return Signer(
        private_key=root.private_key,
        kid=root.kid,
        metadata=SignatureMetadata(
            signer_eid=root.eid,
            signer_mid=root.mid,
            role="identity_authority",
            scope=["manifest.revise", *scopes],
            signed_at=timestamp,
            policy_ref="komistry-policy-v1",
        ),
    )


def _add_edge(
    root: RootFixture,
    source: bytes,
    target: bytes,
    relationship_type: str,
    timestamp: str,
) -> tuple[bytes, str]:
    target_parsed = parse_artifact(target)
    revision, rid = add_relationship_revision(
        parse_artifact(source),
        relationship_type=relationship_type,
        target_eid=target_parsed.revision.entity_id,
        target_mid=target_parsed.revision.manifest_id,
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        timestamp=timestamp,
    )
    return issue_successor(
        source,
        revision,
        [
            _sign(
                root,
                timestamp,
                "relationship.manage",
                required_relationship_scope(relationship_type),
            )
        ],
    ), rid


def _add_reference(
    root: RootFixture,
    target: bytes,
    source: bytes,
    rid: str,
    timestamp: str,
) -> bytes:
    revision = add_relationship_reference_revision(
        parse_artifact(target),
        authoritative_artifact=parse_artifact(source),
        relationship_id=rid,
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        timestamp=timestamp,
    )
    reference = revision.relationships.references[-1]
    return issue_successor(
        target,
        revision,
        [
            _sign(
                root,
                timestamp,
                "relationship.manage",
                required_relationship_scope(reference.local_role),
            )
        ],
    )


def test_registry_rejects_duplicate_and_fork(root: RootFixture, tmp_path) -> None:
    genesis = _genesis(root, "agent", "nova")
    active_revision = transition_revision(
        parse_artifact(genesis),
        target=LifecycleState.ACTIVE,
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        timestamp=T1,
    )
    active = issue_successor(genesis, active_revision, [_sign(root, T1, "lifecycle.change")])
    suspended_revision = transition_revision(
        parse_artifact(genesis),
        target=LifecycleState.SUSPENDED,
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        timestamp=T1,
    )
    fork = issue_successor(genesis, suspended_revision, [_sign(root, T1, "lifecycle.change")])

    with Registry(tmp_path / "registry.db") as registry:
        registry.add(genesis, root.bundle)
        registry.add(active, root.bundle)
        with pytest.raises(LineageError, match=r"duplicate revision|fork"):
            registry.add(fork, root.bundle)
        with pytest.raises(LineageError, match="duplicate artifact"):
            registry.add(active, root.bundle)
        assert registry.verify(root.bundle) == []

        registry.connection.execute(
            "UPDATE heads SET vid = ? WHERE mid = ?",
            (parse_artifact(genesis).vid, parse_artifact(genesis).revision.manifest_id),
        )
        registry.connection.commit()
        with pytest.raises(RegistryError, match="greatest admitted revision"):
            registry.latest_artifact(mid=parse_artifact(genesis).revision.manifest_id)
        assert any(
            "not the greatest admitted revision" in error for error in registry.verify(root.bundle)
        )


def test_revision_policy_denies_relationship_without_scope(root: RootFixture, tmp_path) -> None:
    source = _genesis(root, "agent", "source")
    target = _genesis(root, "laboratory", "target")
    target_parsed = parse_artifact(target)
    revision, _rid = add_relationship_revision(
        parse_artifact(source),
        relationship_type="belongs_to",
        target_eid=target_parsed.revision.entity_id,
        target_mid=target_parsed.revision.manifest_id,
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        timestamp=T1,
    )
    underscoped = issue_successor(source, revision, [_sign(root, T1)])
    with Registry(tmp_path / "registry.db") as registry:
        registry.add(source, root.bundle)
        registry.add(target, root.bundle)
        with pytest.raises(PolicyError, match=r"relationship[.]manage"):
            registry.add(underscoped, root.bundle)


def test_graph_resolves_verified_explicit_and_inverse_path(root: RootFixture, tmp_path) -> None:
    arthur = _genesis(root, "human", "arthur")
    lab = _genesis(root, "laboratory", "komistry-labs")
    nova = _genesis(root, "agent", "nova")

    arthur2, owns_rid = _add_edge(root, arthur, lab, "owns", T1)
    lab2 = _add_reference(root, lab, arthur2, owns_rid, T2)
    arthur3_revision = transition_revision(
        parse_artifact(arthur2),
        target=LifecycleState.ACTIVE,
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        timestamp=T3,
    )
    arthur3 = issue_successor(
        arthur2,
        arthur3_revision,
        [_sign(root, T3, "lifecycle.change")],
    )
    nova2, belongs_rid = _add_edge(root, nova, lab2, "belongs_to", T2)
    lab3 = _add_reference(root, lab2, nova2, belongs_rid, T3)

    with Registry(tmp_path / "registry.db") as registry:
        for artifact in (arthur, lab, nova, arthur2, lab2, arthur3, nova2, lab3):
            registry.add(artifact, root.bundle)
        resolver = GraphResolver(registry, root.bundle)
        path = resolver.path(
            parse_artifact(nova2).revision.entity_id,
            parse_artifact(arthur2).revision.entity_id,
        )
        assert [edge.relationship_type for edge in path.edges] == ["belongs_to", "owned_by"]
        assert path.path_length == 2
        assert path.inferred
        assert path.trusted
        assert path.edges[0].explicit
        assert path.edges[1].inverse_derived
        assert all(edge.source_vid for edge in path.edges)


def test_missing_counterparty_reference_is_not_trusted(root: RootFixture, tmp_path) -> None:
    source = _genesis(root, "human", "claimant")
    target = _genesis(root, "laboratory", "unaware-target")
    source2, _rid = _add_edge(root, source, target, "owns", T1)
    with Registry(tmp_path / "registry.db") as registry:
        for artifact in (source, target, source2):
            registry.add(artifact, root.bundle)
        resolver = GraphResolver(registry, root.bundle)
        with pytest.raises(GraphError, match="no permitted"):
            resolver.path(
                parse_artifact(source2).revision.entity_id,
                parse_artifact(target).revision.entity_id,
            )
        unresolved = resolver.edges(trusted_only=False)
        assert any(edge.trust_state == "missing_or_stale_reference" for edge in unresolved)


def test_counterparty_reference_must_use_exact_inverse_role(root: RootFixture, tmp_path) -> None:
    source = _genesis(root, "human", "claimant")
    target = _genesis(root, "laboratory", "target")
    source2, rid = _add_edge(root, source, target, "owns", T1)
    reference_revision = add_relationship_reference_revision(
        parse_artifact(target),
        authoritative_artifact=parse_artifact(source2),
        relationship_id=rid,
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        timestamp=T2,
    )
    values = reference_revision.model_dump(mode="python")
    values["relationships"]["references"][0]["local_role"] = "governed_by"
    mismatched_revision = Revision.model_validate(values)
    target2 = issue_successor(
        target,
        mismatched_revision,
        [_sign(root, T2, "relationship.manage", "relationship.governance")],
    )
    with Registry(tmp_path / "registry.db") as registry:
        for artifact in (source, target, source2, target2):
            registry.add(artifact, root.bundle)
        unresolved = GraphResolver(registry, root.bundle).edges(trusted_only=False)
        assert any(
            edge.relationship_id == rid and edge.trust_state == "missing_or_stale_reference"
            for edge in unresolved
        )


def test_registry_rejects_hierarchy_cycle(root: RootFixture, tmp_path) -> None:
    first = _genesis(root, "laboratory", "first")
    second = _genesis(root, "laboratory", "second")
    first2, _rid = _add_edge(root, first, second, "governs", T1)
    second2, _rid = _add_edge(root, second, first2, "governs", T2)
    with Registry(tmp_path / "registry.db") as registry:
        registry.add(first, root.bundle)
        registry.add(second, root.bundle)
        registry.add(first2, root.bundle)
        with pytest.raises(GraphError, match="circular"):
            registry.add(second2, root.bundle)


def test_registry_audit_rejects_forged_relationship_index(root: RootFixture, tmp_path) -> None:
    source = _genesis(root, "human", "source")
    target = _genesis(root, "laboratory", "target")
    source_parsed = parse_artifact(source)
    target_parsed = parse_artifact(target)

    with Registry(tmp_path / "registry.db") as registry:
        registry.add(source, root.bundle)
        registry.add(target, root.bundle)
        registry.connection.execute(
            """
            INSERT INTO relationships(
                rid, source_eid, source_mid, source_vid, relationship_type,
                target_eid, target_mid, effective_from, effective_until,
                status, edge_hash
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                "rid:zzzzzzzzzzzzzzzzzzzzzzzzzz",
                source_parsed.revision.entity_id,
                source_parsed.revision.manifest_id,
                source_parsed.vid,
                "governs",
                target_parsed.revision.entity_id,
                target_parsed.revision.manifest_id,
                T1,
                None,
                "active",
                source_parsed.vid,
            ),
        )
        registry.connection.execute(
            """
            INSERT INTO relationship_references(
                rid, target_eid, target_mid, target_vid,
                authoritative_mid, authoritative_vid, local_role
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                "rid:zzzzzzzzzzzzzzzzzzzzzzzzzz",
                target_parsed.revision.entity_id,
                target_parsed.revision.manifest_id,
                target_parsed.vid,
                source_parsed.revision.manifest_id,
                source_parsed.vid,
                "governed_by",
            ),
        )
        registry.connection.commit()

        errors = registry.verify(root.bundle)
        assert "relationship index does not match exact signed artifact evidence" in errors
        assert (
            "relationship-reference index does not match exact signed artifact evidence" in errors
        )
        with pytest.raises(GraphError, match="registry integrity audit failed"):
            GraphResolver(registry, root.bundle).edges()
        candidate = _genesis(root, "agent", "admission-candidate")
        with pytest.raises(RegistryError, match="audit failed before admission"):
            registry.add(candidate, root.bundle)
        assert registry.latest_artifact(mid=parse_artifact(candidate).revision.manifest_id) is None


def test_registry_never_reuses_kos_canonical_identifier(root: RootFixture, tmp_path) -> None:
    canonical_id = "urn:uuid:019c2f10-7a01-7b2c-8d3e-4f5061728394"
    allocation_number = format_k1_allocation_number(1)

    def issued(name: str, *, canonical: str, allocation: str) -> bytes:
        allocation_rid = new_rid()
        bindings = [
            ExternalIdentifierBinding(
                scheme="kos-canonical-id",
                value=canonical,
                allocation_event_id=allocation_rid,
                allocation_authority_eid=root.eid,
                allocation_authority_mid=root.mid,
            ),
            ExternalIdentifierBinding(
                scheme="kos-allocation-number",
                value=allocation,
                allocation_event_id=allocation_rid,
                allocation_authority_eid=root.eid,
                allocation_authority_mid=root.mid,
            ),
        ]
        return issue_genesis(
            create_draft(
                entity_type="initiative",
                canonical_name=name,
                external_identifiers=bindings,
            ),
            private_key=root.private_key,
            kid=root.kid,
            signer_eid=root.eid,
            signer_mid=root.mid,
            issued_at=FIXED_TIME,
            scope=["identity.issue", "identity.allocate"],
        )

    with Registry(tmp_path / "registry.db") as registry:
        first = issued("first", canonical=canonical_id, allocation=allocation_number)
        registry.add(first, root.bundle)
        with pytest.raises(RegistryError, match="already allocated"):
            registry.add(
                issued(
                    "canonical-reuse",
                    canonical=canonical_id,
                    allocation=format_k1_allocation_number(2),
                ),
                root.bundle,
            )
        with pytest.raises(RegistryError, match="already allocated"):
            rejected = issued(
                "allocation-reuse",
                canonical="urn:uuid:019c2f10-7a02-7c3d-9e4f-5061728394a5",
                allocation=allocation_number,
            )
            registry.add(rejected, root.bundle)
        assert registry.latest_artifact(mid=parse_artifact(rejected).revision.manifest_id) is None
        allocation_rows = registry.connection.execute(
            "SELECT scheme, value FROM external_identifiers ORDER BY scheme"
        ).fetchall()
        assert [tuple(row) for row in allocation_rows] == [
            ("kos-allocation-number", allocation_number),
            ("kos-canonical-id", canonical_id),
        ]


def test_v2_registry_migration_rebuilds_external_identifier_allocations(
    root: RootFixture, tmp_path
) -> None:
    allocation_rid = new_rid()
    bindings = [
        ExternalIdentifierBinding(
            scheme="kos-canonical-id",
            value="urn:uuid:019c2f10-7a03-7d4e-af50-61728394a5b6",
            allocation_event_id=allocation_rid,
            allocation_authority_eid=root.eid,
            allocation_authority_mid=root.mid,
        ),
        ExternalIdentifierBinding(
            scheme="kos-allocation-number",
            value=format_k1_allocation_number(1),
            allocation_event_id=allocation_rid,
            allocation_authority_eid=root.eid,
            allocation_authority_mid=root.mid,
        ),
    ]
    artifact = issue_genesis(
        create_draft(
            entity_type="initiative",
            canonical_name="migrated",
            external_identifiers=bindings,
        ),
        private_key=root.private_key,
        kid=root.kid,
        signer_eid=root.eid,
        signer_mid=root.mid,
        issued_at=FIXED_TIME,
        scope=["identity.issue", "identity.allocate"],
    )
    database = tmp_path / "registry.db"
    with Registry(database) as registry:
        registry.add(artifact, root.bundle)
    with sqlite3.connect(database) as connection:
        connection.execute("DROP TABLE allocation_events")
        connection.execute("DROP TABLE allocation_state")
        connection.execute("DROP TABLE registry_identity")
        connection.execute("DROP TABLE external_identifiers")
        connection.execute("PRAGMA user_version = 2")
    with Registry(database) as migrated:
        migrated.pin_trust_domain(root.bundle)
        allocations = migrated.connection.execute(
            "SELECT eid, mid, first_vid FROM external_identifiers ORDER BY scheme"
        ).fetchall()
        assert len(allocations) == 2
        expected = (
            parse_artifact(artifact).revision.entity_id,
            parse_artifact(artifact).revision.manifest_id,
            parse_artifact(artifact).vid,
        )
        assert all(tuple(allocation) == expected for allocation in allocations)
        assert migrated.verify(root.bundle) == []


def test_revocation_is_scoped_to_affected_lineage(root: RootFixture, tmp_path) -> None:
    revoked_source = _genesis(root, "human", "revoked-source")
    relationship_target = _genesis(root, "laboratory", "relationship-target")
    revoked_source2, rid = _add_edge(
        root,
        revoked_source,
        relationship_target,
        "owns",
        T1,
    )
    relationship_target2 = _add_reference(
        root,
        relationship_target,
        revoked_source2,
        rid,
        T2,
    )
    unaffected = _genesis(root, "agent", "unaffected")
    candidate = _genesis(root, "agent", "new-candidate")
    statement = create_revocation_statement(
        target_type=RevocationTargetType.ENTITY,
        target_id=parse_artifact(revoked_source2).revision.entity_id,
        reason_code="security.compromise",
        effective_at=T3,
        issued_at=T3,
        issuer_eid=root.eid,
        issuer_mid=root.mid,
    )
    revocations = RevocationSet(
        [
            verify_revocation(
                sign_revocation(statement, private_key=root.private_key, kid=root.kid),
                root.bundle,
            )
        ]
    )

    with Registry(tmp_path / "registry.db") as registry:
        for artifact in (
            revoked_source,
            relationship_target,
            revoked_source2,
            relationship_target2,
            unaffected,
        ):
            registry.add(artifact, root.bundle)

        registry.add(
            candidate,
            root.bundle,
            revocations=revocations,
            evaluation_time=T3,
        )
        assert registry.verify(root.bundle, evaluation_time=T3) == []
        assert registry.revoked_lineages(
            root.bundle,
            revocations=revocations,
            evaluation_time=T3,
        ) == {parse_artifact(revoked_source2).revision.manifest_id}

        resolver = GraphResolver(
            registry,
            root.bundle,
            revocations=revocations,
            evaluation_time=T3,
        )
        assert resolver.edges() == []
        assert any(
            edge.trust_state == "revoked_lineage" for edge in resolver.edges(trusted_only=False)
        )
