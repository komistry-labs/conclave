"""Signed hash-linked offline events and synchronization conflict detection."""

from __future__ import annotations

import pytest

from idm.authority import (
    REGISTRY_KEY_RELATIVE_PATH,
    TRUST_BUNDLE_FILENAME,
    initialize_authority,
    issue_from_authority,
    sign_successor_from_authority,
)
from idm.container import parse_artifact
from idm.errors import OfflineError
from idm.events import OfflineEventJournal
from idm.files import read_bytes_limited
from idm.identifiers import new_rid
from idm.keybindings import create_public_key_binding
from idm.lifecycle import transition_revision
from idm.manifest import create_draft, write_draft
from idm.models import (
    Capabilities,
    CapabilityGrant,
    CapabilityRisk,
    KeyPurpose,
    LifecycleState,
    ManifestDraft,
)
from idm.offline import create_offline_bundle, verify_offline_bundle
from idm.registry import Registry
from idm.trust import load_trust_bundle
from idm.vault import decrypt_key, generate_key, read_key_file

T0 = "2026-07-22T00:00:00Z"
T1 = "2026-07-22T00:01:00Z"
T2 = "2026-07-22T00:02:00Z"
T3 = "2026-07-22T00:03:00Z"
T10 = "2026-07-22T00:10:00Z"
VAULT_INPUT = "correct horse battery staple"


def _fixture(tmp_path):
    authority_dir = tmp_path / "authority"
    initialize_authority(
        authority_dir,
        canonical_name="root",
        passphrase=VAULT_INPUT,
        timestamp=T0,
    )
    bundle = load_trust_bundle(authority_dir / TRUST_BUNDLE_FILENAME)
    subject_key = generate_key()
    binding = create_public_key_binding(
        subject_key.public_key,
        purposes=[KeyPurpose.SUBJECT_CONTROL, KeyPurpose.OPERATION],
        valid_from=T0,
    )
    draft = create_draft(entity_type="agent", canonical_name="offline-worker", keys=[binding])
    issuer = bundle.anchors[0]
    capabilities = Capabilities(
        declared=["local.write"],
        grants=[
            CapabilityGrant(
                grant_id="rid:cccccccccccccccccccccccccc",
                capability="local.write",
                granted_by_eid=issuer.signer_eid,
                granted_by_mid=issuer.signer_mid,
                grantee_eid=draft.entity_id,
                grantee_mid=draft.manifest_id,
                resource_scope=["local/*"],
                valid_from=T0,
                risk=CapabilityRisk.LOW,
            )
        ],
    )
    values = draft.model_dump(mode="python")
    values["capabilities"] = capabilities
    draft = ManifestDraft.model_validate(values)
    draft_path = tmp_path / "agent.json"
    genesis_path = tmp_path / "agent-r1.idm"
    active_path = tmp_path / "agent-r2.idm"
    write_draft(draft_path, draft)
    issue_from_authority(
        draft_path,
        authority_dir,
        passphrase=VAULT_INPUT,
        output_path=genesis_path,
        timestamp=T0,
    )
    genesis = read_bytes_limited(genesis_path, max_bytes=1024 * 1024)
    signer = bundle.find_anchor(read_key_file(authority_dir / "keys/issuance.idmk").kid)
    assert signer is not None
    active_revision = transition_revision(
        parse_artifact(genesis),
        target=LifecycleState.ACTIVE,
        issued_by_eid=signer.signer_eid,
        issued_by_mid=signer.signer_mid,
        timestamp=T1,
    )
    sign_successor_from_authority(
        genesis,
        active_revision,
        authority_dir,
        passphrase=VAULT_INPUT,
        required_scopes=["lifecycle.change"],
        output_path=active_path,
    )
    active = read_bytes_limited(active_path, max_bytes=1024 * 1024)
    registry_key = decrypt_key(
        read_key_file(authority_dir / REGISTRY_KEY_RELATIVE_PATH), VAULT_INPUT
    )
    package = create_offline_bundle(
        trust_bundle=bundle,
        artifact_bytes=[genesis, active],
        revocation_bytes=[],
        sequence=1,
        generated_at=T1,
        verified_as_of=T1,
        expires_at=T10,
        private_key=registry_key.private_key,
        kid=registry_key.kid,
        max_age_seconds={"low": 600, "medium": 120, "high": 0},
    )
    verified_bundle = verify_offline_bundle(package, pinned_trust=bundle, evaluation_time=T2)
    return authority_dir, bundle, subject_key, genesis, active, verified_bundle


def test_signed_journal_chain_and_sync_conflict(tmp_path) -> None:
    authority_dir, bundle, subject_key, genesis, active, offline_bundle = _fixture(tmp_path)
    actor = parse_artifact(active)
    journal = OfflineEventJournal(tmp_path / "journal")
    first = journal.append(
        bundle=offline_bundle,
        actor=actor,
        private_key=subject_key.private_key,
        kid=subject_key.kid,
        session_id=new_rid(),
        action="write-cache",
        capability="local.write",
        resource="local/cache/a",
        operation="write",
        event_data=b"first payload",
        signed_at=T2,
    )
    second = journal.append(
        bundle=offline_bundle,
        actor=actor,
        private_key=subject_key.private_key,
        kid=subject_key.kid,
        session_id=new_rid(),
        action="write-cache",
        capability="local.write",
        resource="local/cache/b",
        operation="write",
        event_data=b"second payload",
        signed_at=T2,
    )
    assert second.payload.previous_evidence_id == first.evidence_id
    assert [item.payload.sequence for item in journal.verify(offline_bundle)] == [1, 2]

    with Registry(tmp_path / "registry.db") as registry:
        registry.add(genesis, bundle)
        registry.add(active, bundle)
        assert journal.synchronization_status(offline_bundle, registry)["conflicts"] == []

        signer = bundle.find_anchor(read_key_file(authority_dir / "keys/issuance.idmk").kid)
        assert signer is not None
        suspended_revision = transition_revision(
            actor,
            target=LifecycleState.SUSPENDED,
            issued_by_eid=signer.signer_eid,
            issued_by_mid=signer.signer_mid,
            timestamp=T3,
        )
        suspended_path = tmp_path / "agent-r3.idm"
        sign_successor_from_authority(
            active,
            suspended_revision,
            authority_dir,
            passphrase=VAULT_INPUT,
            required_scopes=["lifecycle.change"],
            output_path=suspended_path,
        )
        registry.add(read_bytes_limited(suspended_path, max_bytes=1024 * 1024), bundle)
        status = journal.synchronization_status(offline_bundle, registry)
        assert status["ready"] == []
        assert len(status["conflicts"]) == 2


def test_journal_byte_tampering_breaks_verification(tmp_path) -> None:
    _authority, _bundle, subject_key, _genesis, active, offline_bundle = _fixture(tmp_path)
    journal = OfflineEventJournal(tmp_path / "journal")
    journal.append(
        bundle=offline_bundle,
        actor=parse_artifact(active),
        private_key=subject_key.private_key,
        kid=subject_key.kid,
        session_id=new_rid(),
        action="write-cache",
        capability="local.write",
        resource="local/cache/a",
        operation="write",
        event_data=b"payload",
        signed_at=T2,
    )
    path = next((tmp_path / "journal").glob("*.event.cose"))
    tampered = bytearray(path.read_bytes())
    tampered[-1] ^= 1
    path.write_bytes(tampered)
    with pytest.raises(OfflineError, match="invalid signature"):
        journal.verify(offline_bundle)
