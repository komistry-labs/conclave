"""Separated authority custody and least-privilege KOS allocation issuance."""

from __future__ import annotations

import pytest
from conftest import FIXED_TIME

from idm.authority import (
    ALLOCATION_KEY_RELATIVE_PATH,
    ISSUANCE_KEY_RELATIVE_PATH,
    AuthorityPassphrases,
    initialize_authority,
    issue_from_authority,
)
from idm.container import parse_artifact
from idm.errors import TrustError
from idm.identifiers import new_rid, parse_k1_allocation_number
from idm.manifest import create_draft, write_draft
from idm.models import ExternalIdentifierBinding
from idm.trust import load_trust_bundle
from idm.vault import decrypt_key, read_key_file


def _passphrases() -> AuthorityPassphrases:
    return AuthorityPassphrases(
        root="root custody phrase 0000000000000001",
        issuance="issuance custody phrase 00000000002",
        allocation="allocation custody phrase 0000000003",
        revocation="revocation custody phrase 0000000004",
        registry="registry custody phrase 000000000005",
    )


def test_separated_custody_uses_a_minimal_allocation_key(tmp_path) -> None:
    authority = tmp_path / "authority"
    passphrases = _passphrases()
    initialize_authority(
        authority,
        canonical_name="rehearsal-authority",
        passphrases=passphrases,
        timestamp=FIXED_TIME,
    )

    allocation_key = decrypt_key(
        read_key_file(authority / ALLOCATION_KEY_RELATIVE_PATH),
        passphrases.allocation,
    )
    issuance_key = decrypt_key(
        read_key_file(authority / ISSUANCE_KEY_RELATIVE_PATH),
        passphrases.issuance,
    )
    bundle = load_trust_bundle(authority / "trust-bundle.json")
    allocation_delegation = bundle.find_anchor(allocation_key.kid)
    issuance_delegation = bundle.find_anchor(issuance_key.kid)

    assert allocation_delegation is not None
    assert allocation_delegation.scopes == ["identity.issue", "identity.allocate"]
    assert issuance_delegation is not None
    assert "identity.allocate" not in issuance_delegation.scopes


def test_authority_allocates_monotonic_kos_pairs_with_dedicated_key(tmp_path) -> None:
    authority = tmp_path / "authority"
    passphrases = _passphrases()
    initialize_authority(
        authority,
        canonical_name="rehearsal-authority",
        passphrases=passphrases,
        timestamp=FIXED_TIME,
    )

    ordinals: list[int] = []
    allocation_rids: set[str] = set()
    for index in (1, 2):
        draft_path = tmp_path / f"object-{index}.json"
        output_path = tmp_path / f"object-{index}.idm"
        write_draft(
            draft_path,
            create_draft(entity_type="initiative", canonical_name=f"object-{index}"),
        )
        report = issue_from_authority(
            draft_path,
            authority,
            passphrase=passphrases.allocation,
            output_path=output_path,
            timestamp=f"2026-07-22T00:00:0{index}Z",
            allocate_kos=True,
        )
        assert report.trusted
        artifact = parse_artifact(output_path.read_bytes())
        bindings = {item.scheme: item for item in artifact.revision.entity.external_identifiers}
        ordinals.append(parse_k1_allocation_number(bindings["kos-allocation-number"].value))
        allocation_rids.add(bindings["kos-canonical-id"].allocation_event_id)
        assert (
            bindings["kos-canonical-id"].allocation_event_id
            == bindings["kos-allocation-number"].allocation_event_id
        )

    assert ordinals == [1, 2]
    assert len(allocation_rids) == 2


def test_committed_allocation_is_idempotently_recovered_after_output_loss(tmp_path) -> None:
    authority = tmp_path / "authority"
    passphrases = _passphrases()
    initialize_authority(
        authority,
        canonical_name="rehearsal-authority",
        passphrases=passphrases,
        timestamp=FIXED_TIME,
    )
    draft_path = tmp_path / "recoverable.json"
    output_path = tmp_path / "recoverable.idm"
    write_draft(
        draft_path,
        create_draft(entity_type="initiative", canonical_name="recoverable"),
    )
    first = issue_from_authority(
        draft_path,
        authority,
        passphrase=passphrases.allocation,
        output_path=output_path,
        timestamp="2026-07-22T00:00:01Z",
        allocate_kos=True,
    )
    output_path.unlink()
    recovered = issue_from_authority(
        draft_path,
        authority,
        passphrase=passphrases.allocation,
        output_path=output_path,
        timestamp="2026-07-22T00:00:02Z",
        allocate_kos=True,
    )

    assert recovered.vid == first.vid
    assert parse_artifact(output_path.read_bytes()).vid == first.vid


def test_allocation_recovery_rejects_changed_non_entity_intent(tmp_path) -> None:
    authority = tmp_path / "authority"
    passphrases = _passphrases()
    initialize_authority(
        authority,
        canonical_name="rehearsal-authority",
        passphrases=passphrases,
        timestamp=FIXED_TIME,
    )
    draft_path = tmp_path / "intent.json"
    output_path = tmp_path / "intent.idm"
    draft = create_draft(entity_type="initiative", canonical_name="intent")
    write_draft(draft_path, draft)
    issue_from_authority(
        draft_path,
        authority,
        passphrase=passphrases.allocation,
        output_path=output_path,
        timestamp="2026-07-22T00:00:01Z",
        allocate_kos=True,
    )
    changed_draft_path = tmp_path / "intent-changed.json"
    write_draft(
        changed_draft_path,
        draft.model_copy(update={"extensions": {"changed": True}}),
    )
    with pytest.raises(TrustError, match="conflicting identity"):
        issue_from_authority(
            changed_draft_path,
            authority,
            passphrase=passphrases.allocation,
            output_path=tmp_path / "must-not-write.idm",
            timestamp="2026-07-22T00:00:02Z",
            allocate_kos=True,
        )


def test_allocation_recovery_rejects_prior_non_kos_genesis(tmp_path) -> None:
    authority = tmp_path / "authority"
    passphrases = _passphrases()
    initialize_authority(
        authority,
        canonical_name="rehearsal-authority",
        passphrases=passphrases,
        timestamp=FIXED_TIME,
    )
    draft_path = tmp_path / "prior.json"
    write_draft(draft_path, create_draft(entity_type="initiative", canonical_name="prior"))
    issue_from_authority(
        draft_path,
        authority,
        passphrase=passphrases.issuance,
        output_path=tmp_path / "prior.idm",
        timestamp="2026-07-22T00:00:01Z",
    )
    with pytest.raises(TrustError, match="no KOS UUIDv7/K1 allocation pair"):
        issue_from_authority(
            draft_path,
            authority,
            passphrase=passphrases.allocation,
            output_path=tmp_path / "must-not-write.idm",
            timestamp="2026-07-22T00:00:02Z",
            allocate_kos=True,
        )


def test_convenience_issuance_rejects_caller_supplied_external_identifiers(tmp_path) -> None:
    authority = tmp_path / "authority"
    passphrases = _passphrases()
    initialization = initialize_authority(
        authority,
        canonical_name="rehearsal-authority",
        passphrases=passphrases,
        timestamp=FIXED_TIME,
    )
    rid = new_rid()
    draft = create_draft(
        entity_type="initiative",
        canonical_name="caller-binding",
        external_identifiers=[
            ExternalIdentifierBinding(
                scheme="example-id",
                value="caller-controlled",
                allocation_event_id=rid,
                allocation_authority_eid=initialization.authority_eid,
                allocation_authority_mid=initialization.authority_mid,
            )
        ],
    )
    draft_path = tmp_path / "caller-binding.json"
    write_draft(draft_path, draft)
    with pytest.raises(TrustError, match="rejects caller-supplied"):
        issue_from_authority(
            draft_path,
            authority,
            passphrase=passphrases.issuance,
            output_path=tmp_path / "must-not-write.idm",
            timestamp="2026-07-22T00:00:01Z",
        )
