"""Operational KOS allocation ledger, trust pinning, and checkpoint gates."""

from __future__ import annotations

import sqlite3

import pytest
from conftest import FIXED_TIME, RootFixture

from idm.container import parse_artifact
from idm.errors import RegistryError
from idm.identifiers import (
    format_k1_allocation_number,
    new_rid,
    new_trust_domain_id,
)
from idm.manifest import create_draft, issue_genesis
from idm.models import ExternalIdentifierBinding
from idm.registry import Registry


def _canonical(ordinal: int) -> str:
    return f"urn:uuid:019c2f10-7a01-7b2c-8d3e-{ordinal:012x}"


def _kos_artifact(
    root: RootFixture,
    ordinal: int,
    *,
    name: str | None = None,
    allocation_rid: str | None = None,
    canonical_id: str | None = None,
    entity_type: str = "initiative",
) -> bytes:
    rid = allocation_rid or new_rid()
    bindings = [
        ExternalIdentifierBinding(
            scheme="kos-canonical-id",
            value=canonical_id or _canonical(ordinal),
            allocation_event_id=rid,
            allocation_authority_eid=root.eid,
            allocation_authority_mid=root.mid,
        ),
        ExternalIdentifierBinding(
            scheme="kos-allocation-number",
            value=format_k1_allocation_number(ordinal),
            allocation_event_id=rid,
            allocation_authority_eid=root.eid,
            allocation_authority_mid=root.mid,
        ),
    ]
    return issue_genesis(
        create_draft(
            entity_type=entity_type,
            canonical_name=name or f"allocation-{ordinal}",
            external_identifiers=bindings,
        ),
        private_key=root.private_key,
        kid=root.kid,
        signer_eid=root.eid,
        signer_mid=root.mid,
        issued_at=FIXED_TIME,
        scope=["identity.issue", "identity.allocate"],
    )


def test_k1_admission_is_contiguous_and_rolls_back_rejected_gaps(
    root: RootFixture, tmp_path
) -> None:
    with Registry(tmp_path / "registry.db") as registry:
        assert registry.next_k1_ordinal() == 1
        with pytest.raises(RegistryError, match="next ordinal 1"):
            registry.add(_kos_artifact(root, 2), root.bundle)
        assert registry.next_k1_ordinal() == 1
        assert registry.connection.execute("SELECT COUNT(*) FROM artifacts").fetchone()[0] == 0

        registry.add(_kos_artifact(root, 1), root.bundle)
        assert registry.next_k1_ordinal() == 2
        with pytest.raises(RegistryError, match="next ordinal 2"):
            registry.add(_kos_artifact(root, 3, name="second-gap"), root.bundle)
        with pytest.raises(RegistryError, match="already allocated"):
            registry.add(
                _kos_artifact(root, 1, canonical_id=_canonical(99), name="backward"),
                root.bundle,
            )
        assert registry.next_k1_ordinal() == 2
        registry.add(_kos_artifact(root, 2), root.bundle)
        assert registry.next_k1_ordinal() == 3
        assert registry.verify(root.bundle) == []


def test_allocation_rid_identifies_exactly_one_event(root: RootFixture, tmp_path) -> None:
    shared_rid = new_rid()
    with Registry(tmp_path / "registry.db") as registry:
        registry.add(_kos_artifact(root, 1, allocation_rid=shared_rid), root.bundle)
        with pytest.raises(RegistryError, match="RID is already bound"):
            registry.add(
                _kos_artifact(root, 2, allocation_rid=shared_rid, name="rid-reuse"),
                root.bundle,
            )
        assert registry.next_k1_ordinal() == 2
        assert (
            registry.connection.execute("SELECT COUNT(*) FROM allocation_events").fetchone()[0] == 1
        )


def test_concurrent_stale_allocation_hint_cannot_commit_twice(root: RootFixture, tmp_path) -> None:
    database = tmp_path / "registry.db"
    with Registry(database) as first, Registry(database) as second:
        assert first.next_k1_ordinal() == second.next_k1_ordinal() == 1
        first.add(_kos_artifact(root, 1, name="winner"), root.bundle)
        with pytest.raises(RegistryError, match="already allocated"):
            second.add(
                _kos_artifact(root, 1, canonical_id=_canonical(50), name="stale"),
                root.bundle,
            )
        assert second.next_k1_ordinal() == 2


def test_kos_profile_rejects_unknown_object_type(root: RootFixture, tmp_path) -> None:
    with Registry(tmp_path / "registry.db") as registry:
        with pytest.raises(RegistryError, match=r"outside kos-adr-0002\+0009-v1\.0"):
            registry.add(
                _kos_artifact(root, 1, entity_type="invented_object_type"),
                root.bundle,
            )
        assert registry.next_k1_ordinal() == 1


def test_exact_twenty_object_rehearsal_profile_is_admissible(root: RootFixture, tmp_path) -> None:
    object_types = (
        ["decision"] * 9 + ["constitutional_charter"] + ["relationship"] * 9 + ["approval"]
    )
    with Registry(tmp_path / "registry.db") as registry:
        for ordinal, object_type in enumerate(object_types, start=1):
            registry.add(
                _kos_artifact(root, ordinal, entity_type=object_type),
                root.bundle,
            )
        checkpoint = registry.checkpoint(root.bundle)
    assert checkpoint.allocation_high_water == 20
    assert checkpoint.allocation_count == 20
    assert checkpoint.lineage_count == 20


def test_registry_pins_trust_domain_genesis(root: RootFixture, tmp_path) -> None:
    other_bundle = root.bundle.model_copy(update={"trust_domain_id": new_trust_domain_id()})
    with Registry(tmp_path / "registry.db") as registry:
        registry.add(_kos_artifact(root, 1), root.bundle)
        errors = registry.verify(other_bundle)
        assert "registry trust-domain genesis does not match the supplied bundle" in errors
        with pytest.raises(RegistryError, match="another trust-domain genesis"):
            registry.add(_kos_artifact(root, 2), other_bundle)


def test_checkpoint_detects_stale_restored_registry(root: RootFixture, tmp_path) -> None:
    current_path = tmp_path / "registry.db"
    stale_path = tmp_path / "stale.db"
    with Registry(current_path) as registry:
        registry.add(_kos_artifact(root, 1), root.bundle)
        first = registry.checkpoint(root.bundle)
        with sqlite3.connect(stale_path) as backup:
            registry.connection.backup(backup)
        registry.add(_kos_artifact(root, 2), root.bundle)
        current = registry.checkpoint(root.bundle)

    with Registry(stale_path) as stale:
        restored = stale.checkpoint(root.bundle)

    assert first.digest == restored.digest
    assert current.digest != restored.digest
    assert current.allocation_high_water == 2
    assert restored.allocation_high_water == 1


def test_checkpoint_can_fail_closed_against_retained_evidence(root: RootFixture, tmp_path) -> None:
    with Registry(tmp_path / "registry.db") as registry:
        registry.add(_kos_artifact(root, 1), root.bundle)
        expected = registry.checkpoint(root.bundle)
        assert registry.assert_checkpoint(root.bundle, expected.digest) == expected
        registry.add(_kos_artifact(root, 2), root.bundle)
        with pytest.raises(RegistryError, match="does not match expected"):
            registry.assert_checkpoint(root.bundle, expected.digest)


def test_checkpoint_uses_one_consistent_read_snapshot(
    root: RootFixture, tmp_path, monkeypatch
) -> None:
    database = tmp_path / "registry.db"
    with Registry(database) as reader, Registry(database) as writer:
        reader.add(_kos_artifact(root, 1), root.bundle)
        before = reader.checkpoint(root.bundle)
        original_verify = reader.verify
        inserted = False

        def interleaved_verify(bundle, *, evaluation_time=None):
            nonlocal inserted
            errors = original_verify(bundle, evaluation_time=evaluation_time)
            if not inserted:
                writer.add(_kos_artifact(root, 2), root.bundle)
                inserted = True
            return errors

        monkeypatch.setattr(reader, "verify", interleaved_verify)
        during_write = reader.checkpoint(root.bundle)
        monkeypatch.setattr(reader, "verify", original_verify)
        after = reader.checkpoint(root.bundle)

    assert during_write.digest == before.digest
    assert after.allocation_high_water == 2
    assert after.digest != before.digest


def test_sync_is_atomic_when_a_later_candidate_fails(root: RootFixture, tmp_path) -> None:
    first = tmp_path / "first.idm"
    gap = tmp_path / "gap.idm"
    first.write_bytes(_kos_artifact(root, 1))
    gap.write_bytes(_kos_artifact(root, 3))
    with Registry(tmp_path / "registry.db") as registry:
        with pytest.raises(RegistryError, match="next ordinal 2"):
            registry.sync([first, gap], root.bundle)
        assert registry.next_k1_ordinal() == 1
        assert registry.connection.execute("SELECT COUNT(*) FROM artifacts").fetchone()[0] == 0


def test_v3_to_v4_migration_is_failure_atomic_and_retryable(root: RootFixture, tmp_path) -> None:
    database = tmp_path / "registry.db"
    first = _kos_artifact(root, 1)
    second = _kos_artifact(root, 2)
    first_mid = parse_artifact(first).revision.manifest_id
    with Registry(database) as registry:
        registry.add(first, root.bundle)
        registry.add(second, root.bundle)
    with sqlite3.connect(database) as connection:
        connection.execute("DROP TABLE allocation_events")
        connection.execute("DROP TABLE allocation_state")
        connection.execute("DROP TABLE registry_identity")
        connection.execute("DELETE FROM external_identifiers WHERE mid = ?", (first_mid,))
        connection.execute("DELETE FROM heads WHERE mid = ?", (first_mid,))
        connection.execute("DELETE FROM artifacts WHERE mid = ?", (first_mid,))
        connection.execute("PRAGMA user_version = 3")

    with pytest.raises(RegistryError, match="non-contiguous K1"):
        Registry(database)
    with sqlite3.connect(database) as connection:
        assert connection.execute("PRAGMA user_version").fetchone()[0] == 3
        assert (
            connection.execute(
                "SELECT COUNT(*) FROM sqlite_master WHERE name = 'allocation_events'"
            ).fetchone()[0]
            == 0
        )
        connection.execute("DELETE FROM external_identifiers")
        connection.execute("DELETE FROM heads")
        connection.execute("DELETE FROM artifacts")

    with Registry(database) as recovered:
        assert recovered.next_k1_ordinal() == 1
