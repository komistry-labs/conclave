"""Operational-key separation and external revocation security tests."""

from __future__ import annotations

import base64

import pytest

from idm.authority import (
    ISSUANCE_KEY_RELATIVE_PATH,
    ROOT_KEY_RELATIVE_PATH,
    TRUST_BUNDLE_FILENAME,
    create_revocation_from_authority,
    initialize_authority,
    issue_from_authority,
)
from idm.container import parse_artifact
from idm.errors import RevocationError, TrustError
from idm.files import read_bytes_limited
from idm.identifiers import new_rid
from idm.manifest import create_draft, issue_genesis, write_draft
from idm.revocation import (
    RevocationSet,
    RevocationTargetType,
    create_revocation_statement,
    sign_revocation,
    verify_revocation,
)
from idm.trust import (
    KeyDelegation,
    TrustAnchor,
    TrustBundle,
    encode_delegation,
    encode_public_key,
    load_trust_bundle,
)
from idm.vault import decrypt_key, generate_key, read_key_file
from idm.verification import VerificationStatus, verify_artifact

T0 = "2026-07-22T00:00:00Z"
T1 = "2026-07-22T00:01:00Z"
T2 = "2026-07-22T00:02:00Z"
VAULT_INPUT = "correct horse battery staple"


def _issued_fixture(tmp_path):
    authority_dir = tmp_path / "authority"
    initialize_authority(
        authority_dir,
        canonical_name="komistry-root",
        passphrase=VAULT_INPUT,
        timestamp=T0,
    )
    draft_path = tmp_path / "agent.json"
    artifact_path = tmp_path / "agent.idm"
    write_draft(draft_path, create_draft(entity_type="agent", canonical_name="nova"))
    issue_from_authority(
        draft_path,
        authority_dir,
        passphrase=VAULT_INPUT,
        output_path=artifact_path,
        timestamp=T1,
    )
    bundle = load_trust_bundle(authority_dir / TRUST_BUNDLE_FILENAME)
    artifact = read_bytes_limited(artifact_path, max_bytes=1024 * 1024)
    return authority_dir, bundle, artifact


def test_routine_issuance_uses_root_delegated_key_not_root(tmp_path) -> None:
    authority_dir, bundle, artifact = _issued_fixture(tmp_path)
    root_key = decrypt_key(read_key_file(authority_dir / ROOT_KEY_RELATIVE_PATH), VAULT_INPUT)
    issuance_key = decrypt_key(
        read_key_file(authority_dir / ISSUANCE_KEY_RELATIVE_PATH), VAULT_INPUT
    )
    parsed = parse_artifact(artifact)

    assert parsed.signatures[0].kid == issuance_key.kid
    assert parsed.signatures[0].kid != root_key.kid
    delegated = bundle.find_anchor(issuance_key.kid)
    assert delegated is not None
    assert "identity.issue" in delegated.scopes
    assert verify_artifact(artifact, bundle).trusted


def test_tampered_root_delegation_is_rejected(tmp_path) -> None:
    _authority_dir, bundle, artifact = _issued_fixture(tmp_path)
    signer_kid = parse_artifact(artifact).signatures[0].kid
    raw = bytearray(base64.b64decode(bundle.delegations[0]))
    raw[-1] ^= 1
    tampered_delegations = [base64.b64encode(raw).decode("ascii"), *bundle.delegations[1:]]
    tampered_bundle = TrustBundle.model_validate(
        {**bundle.model_dump(mode="json"), "delegations": tampered_delegations}
    )
    with pytest.raises(TrustError, match="invalid signed delegation"):
        tampered_bundle.find_anchor(signer_kid)


def test_external_vid_revocation_blocks_otherwise_valid_artifact(tmp_path) -> None:
    authority_dir, bundle, artifact = _issued_fixture(tmp_path)
    vid = parse_artifact(artifact).vid
    revocation_path = tmp_path / "agent.revocation.cose"
    verified = create_revocation_from_authority(
        authority_dir,
        passphrase=VAULT_INPUT,
        target_type=RevocationTargetType.REVISION,
        target_id=vid,
        reason_code="security.key_compromise",
        output_path=revocation_path,
        timestamp=T2,
    )
    revocations = RevocationSet([verified])
    report = verify_artifact(artifact, bundle, revocations=revocations, evaluation_time=T2)

    assert report.status is VerificationStatus.REVOKED
    assert report.revoked
    assert not report.trusted
    assert report.revocation_ids == [verified.statement.revocation_id]


def test_future_revocation_is_not_applied_early(tmp_path) -> None:
    authority_dir, bundle, artifact = _issued_fixture(tmp_path)
    revocation_path = tmp_path / "future.revocation.cose"
    verified = create_revocation_from_authority(
        authority_dir,
        passphrase=VAULT_INPUT,
        target_type=RevocationTargetType.ENTITY,
        target_id=parse_artifact(artifact).revision.entity_id,
        reason_code="administrative.retirement",
        output_path=revocation_path,
        effective_at="2026-07-23T00:00:00Z",
        timestamp=T2,
    )
    report = verify_artifact(
        artifact,
        bundle,
        revocations=RevocationSet([verified]),
        evaluation_time=T2,
    )
    assert report.status is VerificationStatus.TRUSTED


def test_issuance_key_cannot_issue_revocations(tmp_path) -> None:
    authority_dir, bundle, artifact = _issued_fixture(tmp_path)
    issuance_key = decrypt_key(
        read_key_file(authority_dir / ISSUANCE_KEY_RELATIVE_PATH), VAULT_INPUT
    )
    authority = bundle.find_anchor(issuance_key.kid)
    assert authority is not None
    statement = create_revocation_statement(
        target_type=RevocationTargetType.REVISION,
        target_id=parse_artifact(artifact).vid,
        reason_code="malicious.attempt",
        effective_at=T2,
        issued_at=T2,
        issuer_eid=authority.signer_eid,
        issuer_mid=authority.signer_mid,
    )
    forged = sign_revocation(statement, private_key=issuance_key.private_key, kid=issuance_key.kid)
    with pytest.raises(RevocationError, match="lacks authority"):
        verify_revocation(forged, bundle)


def test_tampered_revocation_signature_is_rejected(tmp_path) -> None:
    authority_dir, bundle, artifact = _issued_fixture(tmp_path)
    revocation_path = tmp_path / "agent.revocation.cose"
    create_revocation_from_authority(
        authority_dir,
        passphrase=VAULT_INPUT,
        target_type=RevocationTargetType.REVISION,
        target_id=parse_artifact(artifact).vid,
        reason_code="security.key_compromise",
        output_path=revocation_path,
        timestamp=T2,
    )
    tampered = bytearray(read_bytes_limited(revocation_path, max_bytes=1024 * 1024))
    tampered[-1] ^= 1
    with pytest.raises(RevocationError, match="invalid signature"):
        verify_revocation(bytes(tampered), bundle)


def test_delegation_revocation_disables_delegated_signer(root) -> None:
    root_anchor = TrustAnchor.model_validate(
        {
            **root.bundle.anchors[0].model_dump(mode="python"),
            "scopes": [*root.bundle.anchors[0].scopes, "trust.delegate"],
        }
    )
    delegated = generate_key()
    delegation = KeyDelegation(
        delegation_id=new_rid(),
        issuer_eid=root.eid,
        issuer_mid=root.mid,
        issuer_kid=root.kid,
        delegated_kid=delegated.kid,
        delegated_public_key=encode_public_key(delegated.public_key),
        signer_eid=root.eid,
        signer_mid=root.mid,
        roles=["identity_authority"],
        scopes=["identity.issue"],
        valid_from=T0,
        issued_at=T0,
    )
    bundle = TrustBundle(
        trust_domain_id=root.bundle.trust_domain_id,
        generated_at=T0,
        anchors=[root_anchor],
        delegations=[
            encode_delegation(
                delegation,
                root_private_key=root.private_key,
                root_kid=root.kid,
            )
        ],
    )
    artifact = issue_genesis(
        create_draft(entity_type="agent", canonical_name="delegated-agent"),
        private_key=delegated.private_key,
        kid=delegated.kid,
        signer_eid=root.eid,
        signer_mid=root.mid,
        issued_at=T1,
    )
    statement = create_revocation_statement(
        target_type=RevocationTargetType.DELEGATION,
        target_id=delegation.delegation_id,
        reason_code="security.delegation_compromise",
        effective_at=T2,
        issued_at=T2,
        issuer_eid=root.eid,
        issuer_mid=root.mid,
    )
    revocation = verify_revocation(
        sign_revocation(statement, private_key=root.private_key, kid=root.kid),
        bundle,
    )
    report = verify_artifact(
        artifact,
        bundle,
        revocations=RevocationSet([revocation]),
        evaluation_time=T2,
    )

    assert report.status is VerificationStatus.REVOKED
    assert not report.trusted
    assert report.signatures[0].delegation_id == delegation.delegation_id
