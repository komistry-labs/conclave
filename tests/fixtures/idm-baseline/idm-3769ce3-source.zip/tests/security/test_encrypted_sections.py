"""Authenticated section encryption and encrypted section-key vault tests."""

from __future__ import annotations

import json
import os

import pytest
from conftest import FIXED_TIME, RootFixture

from idm.container import Signer, parse_artifact
from idm.encryption import decrypt_section, encrypt_section, protect_section_revision
from idm.errors import VaultError
from idm.lineage import issue_successor
from idm.manifest import create_draft, issue_genesis
from idm.models import SignatureMetadata
from idm.vault import (
    decrypt_section_key,
    encrypt_section_key,
    generate_section_key,
    read_section_key_file,
    write_section_key_file,
)
from idm.verification import verify_artifact

T1 = "2026-07-22T00:01:00Z"
VAULT_INPUT = "correct horse battery staple"


def test_section_key_vault_round_trip_and_wrong_passphrase(tmp_path) -> None:
    generated = generate_section_key()
    encrypted = encrypt_section_key(generated, VAULT_INPUT)
    path = tmp_path / "private-memory.idmsk"
    write_section_key_file(path, encrypted)
    if os.name != "nt":
        assert path.stat().st_mode & 0o077 == 0
    assert decrypt_section_key(read_section_key_file(path), VAULT_INPUT) == generated
    with pytest.raises(VaultError, match="authentication failed"):
        decrypt_section_key(read_section_key_file(path), "incorrect but long enough")


def test_section_ciphertext_is_bound_to_entity_manifest_and_section_name(
    root: RootFixture,
) -> None:
    draft = create_draft(entity_type="human", canonical_name="arthur")
    key = generate_section_key()
    section = encrypt_section(
        b"sensitive memory",
        entity_id=draft.entity_id,
        manifest_id=draft.manifest_id,
        section_name="private_memory",
        section_key=key,
    )
    assert (
        decrypt_section(
            section,
            entity_id=draft.entity_id,
            manifest_id=draft.manifest_id,
            section_name="private_memory",
            section_key=key,
        )
        == b"sensitive memory"
    )
    for entity_id, manifest_id, section_name in (
        (root.eid, draft.manifest_id, "private_memory"),
        (draft.entity_id, root.mid, "private_memory"),
        (draft.entity_id, draft.manifest_id, "credentials"),
    ):
        with pytest.raises(VaultError, match="authentication failed"):
            decrypt_section(
                section,
                entity_id=entity_id,
                manifest_id=manifest_id,
                section_name=section_name,
                section_key=key,
            )


def test_protected_section_is_signed_and_diagnostic_json_is_base64(root: RootFixture) -> None:
    genesis = issue_genesis(
        create_draft(entity_type="agent", canonical_name="private-agent"),
        private_key=root.private_key,
        kid=root.kid,
        signer_eid=root.eid,
        signer_mid=root.mid,
        issued_at=FIXED_TIME,
    )
    key = generate_section_key()
    revision = protect_section_revision(
        parse_artifact(genesis),
        section_name="private_memory",
        plaintext=b"binary\x00secret\xff",
        section_key=key,
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        timestamp=T1,
    )
    signer = Signer(
        private_key=root.private_key,
        kid=root.kid,
        metadata=SignatureMetadata(
            signer_eid=root.eid,
            signer_mid=root.mid,
            role="identity_authority",
            scope=["manifest.revise", "protected.write"],
            signed_at=T1,
            policy_ref="komistry-policy-v1",
        ),
    )
    artifact = issue_successor(genesis, revision, [signer])
    parsed = parse_artifact(artifact)
    assert verify_artifact(artifact, root.bundle).trusted
    diagnostic = parsed.revision.model_dump_json()
    decoded = json.loads(diagnostic)
    assert isinstance(decoded["protected_sections"]["private_memory"]["ciphertext"], str)
    assert (
        decrypt_section(
            parsed.revision.protected_sections["private_memory"],
            entity_id=parsed.revision.entity_id,
            manifest_id=parsed.revision.manifest_id,
            section_name="private_memory",
            section_key=key,
        )
        == b"binary\x00secret\xff"
    )


def test_ciphertext_bit_flip_is_detected(root: RootFixture) -> None:
    draft = create_draft(entity_type="agent", canonical_name="agent")
    key = generate_section_key()
    section = encrypt_section(
        b"secret",
        entity_id=draft.entity_id,
        manifest_id=draft.manifest_id,
        section_name="credentials",
        section_key=key,
    )
    values = section.model_dump(mode="python")
    tampered = bytearray(section.ciphertext)
    tampered[-1] ^= 1
    values["ciphertext"] = bytes(tampered)
    with pytest.raises(VaultError, match="authentication failed"):
        decrypt_section(
            section.model_validate(values),
            entity_id=draft.entity_id,
            manifest_id=draft.manifest_id,
            section_name="credentials",
            section_key=key,
        )
