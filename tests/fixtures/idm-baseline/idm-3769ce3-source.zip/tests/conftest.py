"""Shared fixtures for IDM tests."""

from __future__ import annotations

from dataclasses import dataclass

import pytest

from idm.crypto import public_key_from_private
from idm.identifiers import derive_kid, new_eid, new_mid, new_trust_domain_id
from idm.trust import TrustAnchor, TrustBundle, encode_public_key
from idm.vault import generate_key

FIXED_TIME = "2026-07-22T00:00:00Z"


@dataclass(frozen=True, slots=True)
class RootFixture:
    private_key: bytes
    public_key: bytes
    kid: str
    eid: str
    mid: str
    bundle: TrustBundle


@pytest.fixture
def root() -> RootFixture:
    key = generate_key()
    eid = new_eid()
    mid = new_mid()
    anchor = TrustAnchor(
        kid=key.kid,
        public_key=encode_public_key(key.public_key),
        signer_eid=eid,
        signer_mid=mid,
        roles=["identity_authority"],
        scopes=[
            "identity.issue",
            "identity.allocate",
            "identity.core.change",
            "manifest.revise",
            "relationship.manage",
            "relationship.ownership",
            "relationship.provenance",
            "relationship.governance",
            "relationship.stewardship",
            "relationship.supervision",
            "relationship.affiliation",
            "relationship.operations",
            "relationship.custody",
            "relationship.hosting",
            "relationship.authorization",
            "relationship.dependency",
            "capability.declare",
            "capability.grant",
            "lifecycle.change",
            "protected.write",
            "policy.manage",
            "revocation.issue",
        ],
        valid_from=FIXED_TIME,
    )
    bundle = TrustBundle(
        trust_domain_id=new_trust_domain_id(),
        generated_at=FIXED_TIME,
        anchors=[anchor],
    )
    assert public_key_from_private(key.private_key) == key.public_key
    assert derive_kid(key.public_key) == key.kid
    return RootFixture(key.private_key, key.public_key, key.kid, eid, mid, bundle)
