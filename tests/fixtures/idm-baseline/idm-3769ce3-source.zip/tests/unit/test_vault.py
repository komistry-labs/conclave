"""Encrypted development-vault tests."""

from __future__ import annotations

import json
import os

import pytest

from idm.errors import FileSafetyError, VaultError
from idm.secretsio import read_secret_file
from idm.vault import (
    EncryptedKeyRecord,
    decrypt_key,
    encrypt_key,
    encrypt_section_key,
    generate_key,
    generate_section_key,
    read_key_file,
    read_section_key_file,
    write_key_file,
    write_section_key_file,
)


def test_key_round_trip_and_wrong_passphrase() -> None:
    original = generate_key()
    record = encrypt_key(original, "correct horse battery staple")
    recovered = decrypt_key(record, "correct horse battery staple")
    assert recovered == original

    with pytest.raises(VaultError, match="authentication failed"):
        decrypt_key(record, "incorrect but long enough")


def test_authenticated_metadata_detects_kid_tampering() -> None:
    original = generate_key()
    other = generate_key()
    record = encrypt_key(original, "correct horse battery staple")
    tampered = EncryptedKeyRecord.model_validate(
        {**record.model_dump(mode="json"), "kid": other.kid}
    )
    with pytest.raises(VaultError, match="authentication failed"):
        decrypt_key(tampered, "correct horse battery staple")


def test_secret_file_must_be_private(tmp_path) -> None:
    secret = tmp_path / "passphrase"
    secret.write_text("correct horse battery staple\n", encoding="utf-8")
    secret.chmod(0o644)
    if os.name == "nt":
        assert read_secret_file(secret) == "correct horse battery staple"
    else:
        with pytest.raises(FileSafetyError, match="group or others"):
            read_secret_file(secret)

    secret.chmod(0o600)
    assert read_secret_file(secret) == "correct horse battery staple"


def test_vault_record_contains_no_plaintext_private_key() -> None:
    original = generate_key()
    record = encrypt_key(original, "correct horse battery staple")
    serialized = json.dumps(record.model_dump(mode="json"))
    assert original.private_key.hex() not in serialized


def test_vault_reader_rejects_permissive_permissions_and_symlinks(tmp_path) -> None:
    record = encrypt_key(generate_key(), "correct horse battery staple")
    exposed = tmp_path / "exposed.idmk"
    write_key_file(exposed, record)
    exposed.chmod(0o644)
    if os.name == "nt":
        assert read_key_file(exposed) == record
    else:
        with pytest.raises(VaultError, match="permissions expose"):
            read_key_file(exposed)

    protected = tmp_path / "protected.idmk"
    write_key_file(protected, record)
    link = tmp_path / "linked.idmk"
    try:
        link.symlink_to(protected)
    except OSError:
        pytest.skip("symbolic-link creation is not available to this Windows user")
    with pytest.raises(VaultError, match="safely open"):
        read_key_file(link)


def test_section_key_vault_reader_rejects_symlinks(tmp_path) -> None:
    record = encrypt_section_key(generate_section_key(), "correct horse battery staple")
    protected = tmp_path / "protected-section.idmk"
    write_section_key_file(protected, record)
    link = tmp_path / "linked-section.idmk"
    try:
        link.symlink_to(protected)
    except OSError:
        pytest.skip("symbolic-link creation is not available to this Windows user")
    with pytest.raises(VaultError, match="safely open"):
        read_section_key_file(link)


def test_vault_reader_rejects_hostile_kdf_cost_before_derivation(tmp_path) -> None:
    record = encrypt_key(generate_key(), "correct horse battery staple")
    values = record.model_dump(mode="json")
    values["n"] = 2**24
    path = tmp_path / "hostile.idmk"
    path.write_text(json.dumps(values), encoding="utf-8")
    path.chmod(0o600)
    with pytest.raises(VaultError, match="invalid key-vault record"):
        read_key_file(path)
