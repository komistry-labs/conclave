"""Repository authoring examples remain strict, loadable IDM drafts."""

from __future__ import annotations

from pathlib import Path

from idm.manifest import load_draft


def test_all_example_drafts_are_strict_and_self_consistent() -> None:
    root = Path(__file__).parents[2]
    paths = sorted((root / "examples").glob("*.idm.json"))
    paths.append(root / "schemas" / "examples" / "idm-v1-minimal-draft.json")
    assert len(paths) == 6
    for path in paths:
        draft = load_draft(path)
        for edge in draft.relationships.authoritative:
            assert edge.source_eid == draft.entity_id
            assert edge.source_mid == draft.manifest_id
