"""Trusted issuance and adversarial artifact verification."""

from __future__ import annotations

import cbor2
import pytest
from conftest import FIXED_TIME, RootFixture
from hypothesis import given, settings
from hypothesis import strategies as st

from idm.canonical import dumps
from idm.container import COSE_SIGN_TAG, parse_artifact
from idm.errors import IDMError, SignatureError
from idm.manifest import create_draft, issue_genesis
from idm.vault import generate_key
from idm.verification import VerificationStatus, verify_artifact


def _issue(root: RootFixture) -> bytes:
    draft = create_draft(entity_type="agent", canonical_name="research-agent-1")
    return issue_genesis(
        draft,
        private_key=root.private_key,
        kid=root.kid,
        signer_eid=root.eid,
        signer_mid=root.mid,
        issued_at=FIXED_TIME,
    )


def test_trusted_genesis_round_trip(root: RootFixture) -> None:
    artifact = _issue(root)
    parsed = parse_artifact(artifact)
    report = verify_artifact(artifact, root.bundle)

    assert parsed.exact_bytes == artifact
    assert report.status is VerificationStatus.TRUSTED
    assert report.trusted
    assert report.vid == parsed.vid
    assert report.signatures[0].cryptographically_valid
    assert report.signatures[0].issuer_authorized


def test_payload_tampering_survives_parsing_but_fails_signature(root: RootFixture) -> None:
    artifact = _issue(root)
    outer = cbor2.loads(artifact)
    values = list(outer.value)
    payload = cbor2.loads(values[2])
    payload["entity"]["display_name"] = "spoofed-agent"
    values[2] = dumps(payload)
    tampered = dumps(cbor2.CBORTag(COSE_SIGN_TAG, values))

    parse_artifact(tampered)
    report = verify_artifact(tampered, root.bundle)
    assert report.status is VerificationStatus.UNTRUSTED
    assert not report.trusted
    assert not report.signatures[0].cryptographically_valid


def test_fake_key_claiming_real_authority_is_rejected(root: RootFixture) -> None:
    attacker = generate_key()
    draft = create_draft(entity_type="human", canonical_name="fake-profile")
    forged = issue_genesis(
        draft,
        private_key=attacker.private_key,
        kid=root.kid,
        signer_eid=root.eid,
        signer_mid=root.mid,
        issued_at=FIXED_TIME,
    )
    report = verify_artifact(forged, root.bundle)
    assert report.status is VerificationStatus.UNTRUSTED
    assert not report.signatures[0].cryptographically_valid


def test_unknown_attacker_key_is_not_a_trust_anchor(root: RootFixture) -> None:
    attacker = generate_key()
    draft = create_draft(entity_type="company", canonical_name="lookalike-company")
    forged = issue_genesis(
        draft,
        private_key=attacker.private_key,
        kid=attacker.kid,
        signer_eid=root.eid,
        signer_mid=root.mid,
        issued_at=FIXED_TIME,
    )
    report = verify_artifact(forged, root.bundle)
    assert report.status is VerificationStatus.UNTRUSTED
    assert not report.signatures[0].anchor_recognized


def test_duplicate_signature_identity_is_rejected(root: RootFixture) -> None:
    outer = cbor2.loads(_issue(root))
    values = list(outer.value)
    signatures = list(values[3])
    signatures.append(signatures[0])
    values[3] = signatures
    duplicated = dumps(cbor2.CBORTag(COSE_SIGN_TAG, values))
    with pytest.raises(SignatureError, match="duplicate signature identity"):
        parse_artifact(duplicated)


def test_signer_outside_anchor_validity_is_unauthorized(root: RootFixture) -> None:
    draft = create_draft(entity_type="agent", canonical_name="time-traveler")
    artifact = issue_genesis(
        draft,
        private_key=root.private_key,
        kid=root.kid,
        signer_eid=root.eid,
        signer_mid=root.mid,
        issued_at="2026-07-21T23:59:59Z",
    )
    report = verify_artifact(artifact, root.bundle)
    assert report.signatures[0].cryptographically_valid
    assert not report.signatures[0].issuer_authorized
    assert not report.trusted


def test_future_issued_artifact_is_not_trusted_early(root: RootFixture) -> None:
    artifact = issue_genesis(
        create_draft(entity_type="agent", canonical_name="future-agent"),
        private_key=root.private_key,
        kid=root.kid,
        signer_eid=root.eid,
        signer_mid=root.mid,
        issued_at="2026-07-23T00:00:00Z",
    )
    report = verify_artifact(
        artifact,
        root.bundle,
        evaluation_time=FIXED_TIME,
    )

    assert not report.trusted
    assert any("issuance time is later" in error for error in report.errors)
    assert any("signature time is later" in error for error in report.errors)


def test_invalid_trusted_evaluation_time_fails_closed(root: RootFixture) -> None:
    report = verify_artifact(
        _issue(root),
        root.bundle,
        evaluation_time="not-a-protocol-timestamp",
    )

    assert report.status is VerificationStatus.INVALID
    assert not report.trusted
    assert report.errors == ["timestamp must use normalized UTC form YYYY-MM-DDTHH:MM:SSZ"]


def test_outer_tag_is_mandatory(root: RootFixture) -> None:
    outer = cbor2.loads(_issue(root))
    assert isinstance(outer, cbor2.CBORTag) and outer.tag == COSE_SIGN_TAG
    with pytest.raises(SignatureError, match="tagged COSE_Sign"):
        parse_artifact(dumps(outer.value))


@settings(max_examples=300, deadline=None)
@given(st.binary(max_size=2048))
def test_parser_fails_closed_for_arbitrary_bytes(data: bytes) -> None:
    try:
        parse_artifact(data)
    except IDMError:
        pass
