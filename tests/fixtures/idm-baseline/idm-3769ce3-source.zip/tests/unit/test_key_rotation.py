"""Governed public-key rotation with independent role-diverse approval."""

from __future__ import annotations

from conftest import FIXED_TIME, RootFixture

from idm.container import Signer, parse_artifact
from idm.keybindings import create_public_key_binding, rotate_public_key_revision
from idm.lineage import issue_successor
from idm.manifest import create_draft, issue_genesis
from idm.models import KeyPurpose, SignatureMetadata
from idm.policy import ChangeClass, evaluate_revision_policy
from idm.trust import TrustAnchor, TrustBundle, encode_public_key
from idm.vault import generate_key
from idm.verification import verify_artifact

T1 = "2026-07-22T00:01:00Z"


def test_key_rotation_requires_and_accepts_independent_role_quorum(root: RootFixture) -> None:
    old_subject_key = generate_key()
    new_subject_key = generate_key()
    steward_key = generate_key()
    binding = create_public_key_binding(
        old_subject_key.public_key,
        purposes=[KeyPurpose.SUBJECT_CONTROL, KeyPurpose.OPERATION],
        valid_from=FIXED_TIME,
    )
    genesis = issue_genesis(
        create_draft(entity_type="agent", canonical_name="rotating-agent", keys=[binding]),
        private_key=root.private_key,
        kid=root.kid,
        signer_eid=root.eid,
        signer_mid=root.mid,
        issued_at=FIXED_TIME,
    )
    successor = rotate_public_key_revision(
        parse_artifact(genesis),
        retiring_kid=old_subject_key.kid,
        replacement_public_key=new_subject_key.public_key,
        purposes=[KeyPurpose.SUBJECT_CONTROL, KeyPurpose.OPERATION],
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        timestamp=T1,
    )
    steward_eid = "eid:ssssssssssssssssssssssssss"
    steward_mid = "mid:tttttttttttttttttttttttttt"
    root_anchor_values = root.bundle.anchors[0].model_dump(mode="python")
    root_anchor_values["scopes"] = [*root_anchor_values["scopes"], "key.rotate"]
    bundle = TrustBundle(
        trust_domain_id=root.bundle.trust_domain_id,
        generated_at=FIXED_TIME,
        anchors=[
            TrustAnchor.model_validate(root_anchor_values),
            TrustAnchor(
                kid=steward_key.kid,
                public_key=encode_public_key(steward_key.public_key),
                signer_eid=steward_eid,
                signer_mid=steward_mid,
                roles=["steward"],
                scopes=["manifest.revise", "key.rotate"],
                valid_from=FIXED_TIME,
            ),
        ],
    )
    artifact = issue_successor(
        genesis,
        successor,
        [
            Signer(
                private_key=root.private_key,
                kid=root.kid,
                metadata=SignatureMetadata(
                    signer_eid=root.eid,
                    signer_mid=root.mid,
                    role="identity_authority",
                    scope=["manifest.revise", "key.rotate"],
                    signed_at=T1,
                ),
            ),
            Signer(
                private_key=steward_key.private_key,
                kid=steward_key.kid,
                metadata=SignatureMetadata(
                    signer_eid=steward_eid,
                    signer_mid=steward_mid,
                    role="steward",
                    scope=["manifest.revise", "key.rotate"],
                    signed_at=T1,
                ),
            ),
        ],
    )
    parsed = parse_artifact(artifact)
    report = verify_artifact(artifact, bundle)
    decision = evaluate_revision_policy(parse_artifact(genesis), parsed, report)
    assert report.trusted
    assert decision.allowed
    assert decision.changes == [ChangeClass.KEYS]
    assert parsed.revision.keys[0].valid_until == T1
    assert parsed.revision.keys[1].kid == new_subject_key.kid
