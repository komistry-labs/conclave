"""Identifier behavior."""

from __future__ import annotations

import re
import uuid

import pytest
from hypothesis import given
from hypothesis import strategies as st

from idm.errors import IdentifierError
from idm.identifiers import (
    derive_checkpoint_id,
    derive_kid,
    derive_root_fingerprint,
    derive_vid,
    format_k1_allocation_number,
    new_eid,
    new_mid,
    new_rid,
    new_uuid7_urn,
    parse_k1_allocation_number,
    validate_uuid7_urn,
)


def test_opaque_identifiers_have_type_prefix_and_entropy() -> None:
    eids = {new_eid() for _ in range(100)}
    mids = {new_mid() for _ in range(100)}
    rids = {new_rid() for _ in range(100)}

    assert len(eids) == len(mids) == len(rids) == 100
    assert all(re.fullmatch(r"eid:[a-z2-7]{26}", value) for value in eids)
    assert all(re.fullmatch(r"mid:[a-z2-7]{26}", value) for value in mids)
    assert all(re.fullmatch(r"rid:[a-z2-7]{26}", value) for value in rids)


def test_content_identifiers_are_deterministic_and_domain_separated() -> None:
    payload = b"same bytes"
    assert derive_vid(payload) == derive_vid(payload)
    assert derive_kid(payload) == derive_kid(payload)
    assert derive_vid(payload).removeprefix("vid:") == derive_kid(payload).removeprefix("kid:")


def test_registry_evidence_has_domain_separated_non_vid_identifiers() -> None:
    payload = b"same registry bytes"
    checkpoint = derive_checkpoint_id(payload)
    root = derive_root_fingerprint(payload)

    assert checkpoint.startswith("checkpoint:sha256:")
    assert root.startswith("rootfp:sha256:")
    assert checkpoint.removeprefix("checkpoint:sha256:") != root.removeprefix("rootfp:sha256:")
    assert not checkpoint.startswith("vid:")
    assert not root.startswith("vid:")


def test_uuidv7_urn_requires_canonical_version_variant_and_case() -> None:
    value = "urn:uuid:019c2f10-7a01-7b2c-8d3e-4f5061728394"
    assert validate_uuid7_urn(value) == value

    for invalid in (
        "urn:uuid:019c2f10-7a01-4b2c-8d3e-4f5061728394",
        "urn:uuid:019c2f10-7a01-7b2c-7d3e-4f5061728394",
        "urn:uuid:019C2F10-7A01-7B2C-8D3E-4F5061728394",
        "019c2f10-7a01-7b2c-8d3e-4f5061728394",
    ):
        with pytest.raises(IdentifierError, match="UUIDv7 URN"):
            validate_uuid7_urn(invalid)


def test_uuidv7_generator_sets_timestamp_version_variant_and_unique_randomness() -> None:
    timestamp_ms = 0x0123456789AB
    values = {new_uuid7_urn(timestamp_ms=timestamp_ms) for _ in range(100)}

    assert len(values) == 100
    for value in values:
        assert validate_uuid7_urn(value) == value
        parsed = uuid.UUID(value.removeprefix("urn:uuid:"))
        assert parsed.version == 7
        assert parsed.variant == uuid.RFC_4122
        assert parsed.int >> 80 == timestamp_ms

    for invalid in (True, -1, 1 << 48):
        with pytest.raises(IdentifierError, match="timestamp"):
            new_uuid7_urn(timestamp_ms=invalid)  # type: ignore[arg-type]


def test_k1_allocation_numbers_round_trip_full_unsigned_128_bit_range() -> None:
    for ordinal in (1, 31, 32, 37, 2**64, 2**128 - 1):
        encoded = format_k1_allocation_number(ordinal)
        assert re.fullmatch(r"K1-[0-9A-HJKMNP-TV-Z]{26}-[0-9A-HJKMNP-TV-Z*~$=U]", encoded)
        assert parse_k1_allocation_number(encoded) == ordinal

    assert format_k1_allocation_number(1) == "K1-00000000000000000000000001-1"


@pytest.mark.parametrize(
    "value,error",
    [
        ("K1-00000000000000000000000000-0", "unsigned non-zero"),
        ("K1-80000000000000000000000000-0", "unsigned non-zero"),
        ("K1-00000000000000000000000001-2", "check symbol"),
        ("k1-00000000000000000000000001-1", "canonical K1"),
        ("K1-0000000000000000000000000I-1", "canonical K1"),
        ("K1-1-1", "canonical K1"),
    ],
)
def test_k1_allocation_numbers_fail_closed(value: str, error: str) -> None:
    with pytest.raises(IdentifierError, match=error):
        parse_k1_allocation_number(value)


def test_k1_formatter_rejects_invalid_ordinals() -> None:
    for invalid in (True, 1.0, 0, -1, 2**128):
        with pytest.raises(IdentifierError):
            format_k1_allocation_number(invalid)  # type: ignore[arg-type]


@given(st.integers(min_value=1, max_value=2**128 - 1))
def test_k1_randomized_round_trip(ordinal: int) -> None:
    assert parse_k1_allocation_number(format_k1_allocation_number(ordinal)) == ordinal
