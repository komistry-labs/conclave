"""Keep the diagnostic JSON schema's object shapes aligned with domain models."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from idm.models import (
    AuthorityRefs,
    Capabilities,
    CapabilityDenial,
    CapabilityGrant,
    Entity,
    Lifecycle,
    Origin,
    ProtectedSection,
    PublicKeyBinding,
    Relationship,
    RelationshipReference,
    Relationships,
    Revision,
    StrictModel,
)


def _field_names(model: type[StrictModel]) -> set[str]:
    return {field.alias or name for name, field in model.model_fields.items()}


def _assert_object_shape(model: type[StrictModel], schema: dict[str, Any]) -> None:
    names = _field_names(model)
    assert set(schema["properties"]) == names
    assert set(schema["required"]) == names
    assert schema["additionalProperties"] is False


def test_json_schema_object_shapes_match_runtime_models() -> None:
    schema_path = Path(__file__).parents[2] / "schemas" / "idm-v1.schema.json"
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    _assert_object_shape(Revision, schema)
    definitions = schema["$defs"]
    for name, model in (
        ("entity", Entity),
        ("publicKeyBinding", PublicKeyBinding),
        ("origin", Origin),
        ("relationship", Relationship),
        ("relationshipReference", RelationshipReference),
        ("relationships", Relationships),
        ("authority", AuthorityRefs),
        ("capabilityGrant", CapabilityGrant),
        ("capabilityDenial", CapabilityDenial),
        ("capabilities", Capabilities),
        ("lifecycle", Lifecycle),
        ("protectedSection", ProtectedSection),
    ):
        _assert_object_shape(model, definitions[name])
