"""Stable public interoperability vectors for the normative wire profile."""

from __future__ import annotations

import base64
import json
from pathlib import Path

from idm.container import parse_artifact
from idm.identifiers import derive_vid
from idm.trust import TrustAnchor, TrustBundle
from idm.verification import VerificationStatus, verify_artifact


def test_idm_v1_genesis_golden_vector() -> None:
    fixture_path = Path(__file__).parents[1] / "fixtures" / "golden" / "idm-v1-genesis.json"
    vector = json.loads(fixture_path.read_text(encoding="utf-8"))
    artifact = base64.b64decode(vector["artifact_base64"], validate=True)
    assert len(artifact) == vector["artifact_length"]
    assert derive_vid(artifact) == vector["vid"]

    parsed = parse_artifact(artifact)
    assert parsed.vid == vector["vid"]
    assert parsed.revision.entity_id == vector["entity_id"]
    assert parsed.revision.manifest_id == vector["manifest_id"]
    assert parsed.revision.issued_at == vector["issued_at"]

    anchor = TrustAnchor(
        kid=vector["kid"],
        public_key=vector["public_key_base64"],
        signer_eid=vector["signer_eid"],
        signer_mid=vector["signer_mid"],
        roles=["identity_authority"],
        scopes=["identity.issue"],
        valid_from=vector["issued_at"],
    )
    bundle = TrustBundle(
        trust_domain_id="tdid:gggggggggggggggggggggggggg",
        generated_at=vector["issued_at"],
        anchors=[anchor],
    )
    report = verify_artifact(artifact, bundle)
    assert report.status is VerificationStatus.TRUSTED
    assert report.trusted
