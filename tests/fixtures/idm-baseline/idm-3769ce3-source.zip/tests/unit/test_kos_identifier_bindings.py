"""KOS UUIDv7 and K1 binding invariants."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from idm.errors import IdentifierError
from idm.identifiers import format_k1_allocation_number, new_eid, new_mid, new_rid
from idm.models import Entity, ExternalIdentifierBinding

UUID_1 = "urn:uuid:019c2f10-7a01-7b2c-8d3e-4f5061728394"


def _binding(
    scheme: str,
    value: str,
    *,
    rid: str,
    authority_eid: str,
    authority_mid: str,
) -> ExternalIdentifierBinding:
    return ExternalIdentifierBinding(
        scheme=scheme,
        value=value,
        allocation_event_id=rid,
        allocation_authority_eid=authority_eid,
        allocation_authority_mid=authority_mid,
    )


def _entity(bindings: list[ExternalIdentifierBinding]) -> Entity:
    return Entity(
        type="initiative",
        canonical_name="candidate",
        display_name="Candidate",
        external_identifiers=bindings,
    )


def test_kos_binding_requires_one_complete_atomic_pair() -> None:
    rid = new_rid()
    eid = new_eid()
    mid = new_mid()
    canonical = _binding("kos-canonical-id", UUID_1, rid=rid, authority_eid=eid, authority_mid=mid)
    allocation = _binding(
        "kos-allocation-number",
        format_k1_allocation_number(1),
        rid=rid,
        authority_eid=eid,
        authority_mid=mid,
    )

    assert len(_entity([canonical, allocation]).external_identifiers) == 2
    with pytest.raises(ValidationError, match="exactly one canonical ID"):
        _entity([canonical])
    with pytest.raises(ValidationError, match="exactly one canonical ID"):
        _entity([allocation])
    with pytest.raises(ValidationError, match="exactly one canonical ID"):
        _entity([canonical, canonical.model_copy(update={"value": UUID_1[:-1] + "5"}), allocation])


def test_kos_pair_must_share_allocation_record_and_authority() -> None:
    rid = new_rid()
    eid = new_eid()
    mid = new_mid()
    canonical = _binding("kos-canonical-id", UUID_1, rid=rid, authority_eid=eid, authority_mid=mid)

    for allocation in (
        _binding(
            "kos-allocation-number",
            format_k1_allocation_number(1),
            rid=new_rid(),
            authority_eid=eid,
            authority_mid=mid,
        ),
        _binding(
            "kos-allocation-number",
            format_k1_allocation_number(1),
            rid=rid,
            authority_eid=new_eid(),
            authority_mid=mid,
        ),
    ):
        with pytest.raises(ValidationError, match="share one allocation record"):
            _entity([canonical, allocation])


def test_kos_binding_values_use_strict_profiles() -> None:
    rid = new_rid()
    eid = new_eid()
    mid = new_mid()
    with pytest.raises(IdentifierError, match="UUIDv7 URN"):
        _binding(
            "kos-canonical-id",
            "kos:initiative:000001",
            rid=rid,
            authority_eid=eid,
            authority_mid=mid,
        )
    with pytest.raises(IdentifierError, match="canonical K1"):
        _binding(
            "kos-allocation-number",
            "K1-1-1",
            rid=rid,
            authority_eid=eid,
            authority_mid=mid,
        )


def test_non_kos_external_identifiers_remain_independent() -> None:
    binding = _binding(
        "customer-reference",
        "regional-account-42",
        rid=new_rid(),
        authority_eid=new_eid(),
        authority_mid=new_mid(),
    )
    assert _entity([binding]).external_identifiers == [binding]
