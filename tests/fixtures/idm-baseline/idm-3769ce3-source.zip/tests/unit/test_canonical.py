"""Deterministic CBOR profile tests."""

from __future__ import annotations

import cbor2
import pytest

from idm.canonical import dumps, load_canonical, validate_profile
from idm.errors import CanonicalEncodingError


def test_map_encoding_is_deterministic() -> None:
    first = {"z": 1, "aa": 2, "a": 3}
    second = {"a": 3, "z": 1, "aa": 2}
    assert dumps(first) == dumps(second)
    assert load_canonical(dumps(first)) == first


def test_rejects_valid_but_noncanonical_integer_encoding() -> None:
    noncanonical = b"\xa1\x61a\x18\x01"
    assert cbor2.loads(noncanonical) == {"a": 1}
    with pytest.raises(CanonicalEncodingError, match="not deterministically encoded"):
        load_canonical(noncanonical)


@pytest.mark.parametrize(
    "value, message",
    [
        ({"temperature": 1.5}, "floating-point"),
        ({"name": "e\u0301"}, "NFC"),
        ({1: "integer key"}, "map keys"),
        (cbor2.CBORTag(42, "value"), "tag 42"),
    ],
)
def test_rejects_values_outside_profile(value: object, message: str) -> None:
    with pytest.raises(CanonicalEncodingError, match=message):
        validate_profile(value)


def test_rejects_trailing_data() -> None:
    with pytest.raises(CanonicalEncodingError, match="trailing bytes"):
        load_canonical(dumps({"ok": True}) + b"\x00")
