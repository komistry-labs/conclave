"""Lineage, lifecycle, and deterministic revision policy tests."""

from __future__ import annotations

import pytest
from conftest import FIXED_TIME, RootFixture

from idm.container import Signer, parse_artifact
from idm.errors import LifecycleError, LineageError
from idm.identifiers import format_k1_allocation_number, new_eid, new_mid, new_rid
from idm.lifecycle import transition_revision
from idm.lineage import build_successor, issue_successor, validate_successor
from idm.manifest import create_draft, issue_genesis
from idm.models import (
    Capabilities,
    CapabilityGrant,
    Entity,
    ExternalIdentifierBinding,
    LifecycleState,
    ManifestDraft,
    SignatureMetadata,
)
from idm.policy import ChangeClass, evaluate_revision_policy
from idm.verification import verify_artifact

LATER = "2026-07-22T00:01:00Z"


def _genesis(root: RootFixture) -> bytes:
    return issue_genesis(
        create_draft(entity_type="agent", canonical_name="nova"),
        private_key=root.private_key,
        kid=root.kid,
        signer_eid=root.eid,
        signer_mid=root.mid,
        issued_at=FIXED_TIME,
    )


def _signer(root: RootFixture, *scopes: str) -> Signer:
    return Signer(
        private_key=root.private_key,
        kid=root.kid,
        metadata=SignatureMetadata(
            signer_eid=root.eid,
            signer_mid=root.mid,
            role="identity_authority",
            scope=["manifest.revise", *scopes],
            signed_at=LATER,
            policy_ref="komistry-policy-v1",
        ),
    )


def test_valid_successor_preserves_identity_and_exact_predecessor(root: RootFixture) -> None:
    genesis = _genesis(root)
    predecessor = parse_artifact(genesis)
    successor = transition_revision(
        predecessor,
        target=LifecycleState.ACTIVE,
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        timestamp=LATER,
    )
    artifact = issue_successor(genesis, successor, [_signer(root, "lifecycle.change")])
    parsed = parse_artifact(artifact)
    report = verify_artifact(artifact, root.bundle)
    decision = evaluate_revision_policy(predecessor, parsed, report)

    assert parsed.revision.entity_id == predecessor.revision.entity_id
    assert parsed.revision.manifest_id == predecessor.revision.manifest_id
    assert parsed.revision.predecessor_vid == predecessor.vid
    assert parsed.revision.revision == 2
    assert report.trusted
    assert decision.allowed
    assert decision.changes == [ChangeClass.LIFECYCLE]


def test_broken_predecessor_and_revision_jump_are_rejected(root: RootFixture) -> None:
    predecessor = parse_artifact(_genesis(root))
    valid = transition_revision(
        predecessor,
        target=LifecycleState.ACTIVE,
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        timestamp=LATER,
    )
    broken_values = valid.model_dump(mode="python")
    broken_values["predecessor_vid"] = "vid:sha256:" + "A" * 43
    with pytest.raises(LineageError, match="exact predecessor"):
        validate_successor(predecessor, valid.model_validate(broken_values))

    jumped_values = valid.model_dump(mode="python")
    jumped_values["revision"] = 3
    with pytest.raises(LineageError, match="increment exactly once"):
        validate_successor(predecessor, valid.model_validate(jumped_values))


def test_successor_preserves_atomic_kos_identifier_pair(root: RootFixture) -> None:
    allocation_rid = new_rid()
    bindings = [
        ExternalIdentifierBinding(
            scheme="kos-canonical-id",
            value="urn:uuid:019c2f10-7a01-7b2c-8d3e-4f5061728394",
            allocation_event_id=allocation_rid,
            allocation_authority_eid=root.eid,
            allocation_authority_mid=root.mid,
        ),
        ExternalIdentifierBinding(
            scheme="kos-allocation-number",
            value=format_k1_allocation_number(1),
            allocation_event_id=allocation_rid,
            allocation_authority_eid=root.eid,
            allocation_authority_mid=root.mid,
        ),
    ]
    genesis = issue_genesis(
        create_draft(
            entity_type="initiative",
            canonical_name="governed",
            external_identifiers=bindings,
        ),
        private_key=root.private_key,
        kid=root.kid,
        signer_eid=root.eid,
        signer_mid=root.mid,
        issued_at=FIXED_TIME,
        scope=["identity.issue", "identity.allocate"],
    )
    predecessor = parse_artifact(genesis)

    unchanged = build_successor(
        predecessor,
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        issued_at=LATER,
    )
    assert unchanged.entity.external_identifiers == predecessor.revision.entity.external_identifiers

    replacement_rid = new_rid()
    changed_entity = Entity(
        type=predecessor.revision.entity.type,
        canonical_name=predecessor.revision.entity.canonical_name,
        display_name=predecessor.revision.entity.display_name,
        external_identifiers=[
            ExternalIdentifierBinding(
                scheme="kos-canonical-id",
                value="urn:uuid:019c2f10-7a02-7c3d-9e4f-5061728394a5",
                allocation_event_id=replacement_rid,
                allocation_authority_eid=root.eid,
                allocation_authority_mid=root.mid,
            ),
            ExternalIdentifierBinding(
                scheme="kos-allocation-number",
                value=format_k1_allocation_number(2),
                allocation_event_id=replacement_rid,
                allocation_authority_eid=root.eid,
                allocation_authority_mid=root.mid,
            ),
        ],
    )
    with pytest.raises(LineageError, match="atomic KOS identifier binding"):
        build_successor(
            predecessor,
            issued_by_eid=root.eid,
            issued_by_mid=root.mid,
            issued_at=LATER,
            updates={"entity": changed_entity},
        )

    removed_entity = Entity(
        type=predecessor.revision.entity.type,
        canonical_name=predecessor.revision.entity.canonical_name,
        display_name=predecessor.revision.entity.display_name,
    )
    with pytest.raises(LineageError, match="atomic KOS identifier binding"):
        build_successor(
            predecessor,
            issued_by_eid=root.eid,
            issued_by_mid=root.mid,
            issued_at=LATER,
            updates={"entity": removed_entity},
        )


def test_invalid_lifecycle_transition_is_rejected(root: RootFixture) -> None:
    predecessor = parse_artifact(_genesis(root))
    with pytest.raises(LifecycleError, match="issued -> archived"):
        transition_revision(
            predecessor,
            target=LifecycleState.ARCHIVED,
            issued_by_eid=root.eid,
            issued_by_mid=root.mid,
            timestamp=LATER,
        )


def test_identity_core_change_requires_role_diverse_quorum(root: RootFixture) -> None:
    genesis = _genesis(root)
    predecessor = parse_artifact(genesis)
    prior_entity = predecessor.revision.entity
    changed_entity = Entity(
        type=prior_entity.type,
        canonical_name="nova-renamed-core",
        display_name=prior_entity.display_name,
        description=prior_entity.description,
        aliases=prior_entity.aliases,
    )
    successor = build_successor(
        predecessor,
        issued_by_eid=root.eid,
        issued_by_mid=root.mid,
        issued_at=LATER,
        updates={"entity": changed_entity},
    )
    artifact = issue_successor(genesis, successor, [_signer(root, "identity.core.change")])
    parsed = parse_artifact(artifact)
    report = verify_artifact(artifact, root.bundle)
    decision = evaluate_revision_policy(predecessor, parsed, report)
    assert report.trusted
    assert not decision.allowed
    assert any("2 independent" in error for error in decision.errors)
    assert any("steward" in error for error in decision.errors)


def test_capability_grant_must_be_signed_by_its_named_grantor(root: RootFixture) -> None:
    draft = create_draft(entity_type="agent", canonical_name="spoof-attempt")
    capabilities = Capabilities(
        declared=["system.read"],
        grants=[
            CapabilityGrant(
                grant_id="rid:dddddddddddddddddddddddddd",
                capability="system.read",
                granted_by_eid=new_eid(),
                granted_by_mid=new_mid(),
                grantee_eid=draft.entity_id,
                grantee_mid=draft.manifest_id,
                valid_from=FIXED_TIME,
            )
        ],
    )
    values = draft.model_dump(mode="python")
    values["capabilities"] = capabilities
    governed_draft = ManifestDraft.model_validate(values)
    artifact = issue_genesis(
        governed_draft,
        private_key=root.private_key,
        kid=root.kid,
        signer_eid=root.eid,
        signer_mid=root.mid,
        issued_at=FIXED_TIME,
        scope=["identity.issue", "capability.declare", "capability.grant"],
    )
    parsed = parse_artifact(artifact)
    report = verify_artifact(artifact, root.bundle)
    decision = evaluate_revision_policy(None, parsed, report)
    assert report.trusted
    assert not decision.allowed
    assert any("not signed by its named grantor" in error for error in decision.errors)
