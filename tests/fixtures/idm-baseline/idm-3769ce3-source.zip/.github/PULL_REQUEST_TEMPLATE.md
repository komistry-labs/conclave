## Summary

Describe the change and why it is needed.

## Security and protocol impact

- Security impact:
- Wire-format or schema impact:
- Migration or interoperability impact:

## Validation

- [ ] Formatting, linting, and strict type checks pass.
- [ ] Unit, integration, and security tests pass.
- [ ] New behavior includes an intended-success case and a relevant failure case.
- [ ] No real keys, passphrases, identity evidence, private data, or production artifacts are included.
- [ ] Protocol changes include the required ADR, schema, migration, and vector updates.
