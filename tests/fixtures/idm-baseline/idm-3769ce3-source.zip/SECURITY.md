# Security Policy

## Security status

This project is under active protocol development. It has not received an independent cryptographic review or penetration test. Do not use it with real authority keys, personal identity evidence, production credentials, or safety-critical systems.

## Security invariants

- Issued artifacts are immutable.
- Verification fails closed.
- A mathematically valid signature is not trusted without an authorized chain to a pinned anchor.
- Manifest possession is not authentication.
- AI-generated content is untrusted data and cannot authorize an operation.
- Private keys are never stored in an IDM artifact or repository fixture.
- Revocation is external signed evidence, not a self-declared field alone.
- Unknown critical fields and unsupported algorithms are rejected.

## Reporting vulnerabilities

Until a private reporting channel is established, do not publish exploit details against a deployed instance. Contact the repository owner directly with:

- affected version and component;
- reproduction steps or proof of concept;
- expected impact;
- suggested mitigation if known.

No production security-response SLA is currently offered.
