# Lifecycle

Signed revisions may be `issued`, `active`, `suspended`, `retired`, or `archived`. `draft` exists only before signing. `revoked` is a verification overlay established by external signed revocation evidence; an immutable artifact cannot be trusted to revoke itself.

Allowed transitions are:

```text
issued -> active | suspended | retired
active -> suspended | retired | archived
suspended -> active | retired
retired -> archived
archived -> terminal
revoked -> terminal
```

Mounting permits issued or active identities. Operation requires active. Suspension blocks operation, retirement ends operation, and archive preserves verification history. Every transition creates a successor with the same EID and MID, revision incremented once, and the exact predecessor VID. Deletion is not a lifecycle operation.

Verification and runtime decisions use a trusted evaluation clock. Artifacts, signatures, and challenges dated later than that clock are rejected; callers cannot override mount time.
