# Migration and Versioning

`schema_version` identifies revision-payload semantics. `idm_format` and `idm_context` identify envelope behavior. Unsupported versions and unknown protected headers fail closed.

Any byte-level wire change requires a new profile, updated CDDL, test vectors, and an ADR. Existing signed artifacts are immutable and are never rewritten during migration; a semantic migration creates a governed successor.

The registry uses SQLite `user_version`. Schema v2 added stable relationship-evidence hashes and migrates v1 rows by re-reading their exact signed source artifacts. A registry may always be discarded and rebuilt from trusted evidence.

Diagnostic JSON is not round-tripped into a signed revision. `import-json` accepts only unsigned drafts; `export-json` is explicitly diagnostic.
