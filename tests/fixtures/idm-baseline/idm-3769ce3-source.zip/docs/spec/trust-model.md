# IDM v1 Trust and Issuance Model

**Status:** normative v1 reference profile

## Root trust

The first profile uses one private trust domain with an out-of-band pinned Ed25519 root public key. The root is a trust anchor because of provisioning, not because its authority manifest signs itself.

The root key is encrypted at rest and SHOULD remain offline. The reference profile uses root-signed, time-bounded operational-key delegations for routine issuance, relationship approval, capability grant, lifecycle changes, revocation, and registry snapshot signing. A delegated key never becomes a root anchor.

## Genesis issuance

A trusted genesis artifact requires:

1. schema-valid deterministic payload;
2. a valid Ed25519 signature;
3. signer identity matching a configured trust anchor or valid delegation chain;
4. signature role and scope authorizing `identity.issue` plus every governed claim present at genesis;
5. payload `origin.issued_by` matching the authorized issuer;
6. acceptable enrollment profile, entity type, namespace, and conflict checks;
7. current signer, pinned policy, and revocation evidence;
8. each initial capability grant or denial attributed to an authorized signature from its named governor.
9. each external identifier binding attributed to an `identity.allocate`
   signature from its named allocation authority and admitted to the authority
   allocation registry; the KOS UUIDv7 and K1 bindings additionally form one
   complete atomic pair naming the same allocation RID and authority EID/MID.

Routine issuance uses an operational key whose delegation evidence is signed directly by an out-of-band pinned root. The reference implementation deliberately supports one delegation hop in v1. Delegation metadata without valid root-signed evidence carries no authority.

## Governed successors

Every successor binds the exact predecessor VID, preserves EID and MID, increments the revision by one, and is evaluated against a locally trusted policy. The policy classifies semantic changes and requires scoped, role-qualified signatures. High-impact changes may require independent role-diverse approval; one key declaring two roles does not satisfy independent-key quorum.

A delegation is effective only while its signed delegation evidence remains valid and unrevoked. Revoking the delegation RID invalidates signatures that rely on it even when the delegated key itself has not been separately revoked.

Revocation evidence is external to immutable artifacts and trust bundles.
Operational verification therefore accepts an explicit verified revocation
set. Registry admission and audit, graph resolution, authority signing, lineage
verification, and runtime mount all propagate that set to the same verifier.
An omitted set means the caller asserts that the authoritative set is empty.

Structural registry integrity and revocation state are distinct. Structural
audit verifies bytes, metadata, lineage, policy, heads, and derived indexes
without treating a valid revocation as corruption. A separate overlay scans
every admitted revision and marks only affected MIDs as revoked. This catches
revocation of an earlier revision while allowing unrelated lineages to remain
available.

Artifact and signature timestamps cannot be later than the verifier's trusted evaluation time. Runtime challenges and mount decisions obtain time from the runtime's injected trusted clock rather than caller-supplied timestamps.

## Derived registry state

SQLite relationship, reference, head, external-identifier and KOS allocation
tables are rebuildable indexes, not independent authority. Registry audit
reconstructs them from admitted signed artifacts and rejects any extra,
missing, altered or non-contiguous derived rows before graph resolution. The
registry separately pins the trust-domain ID and root fingerprint; a migrated
registry requires an explicit pin before it may pass audit.

Registry admission performs this audit inside the admission transaction before
using derived relationship rows for hierarchy-cycle checks. A poisoned index
therefore blocks admission rather than influencing the decision.

KOS allocation admission binds one unique allocation RID to one
UUIDv7/K1/EID/MID/authority tuple and advances the K1 high-water mark in the
same transaction as signed-artifact admission. Sorted registry synchronization
admits a complete batch or rolls the complete batch back. Deterministic,
snapshot-atomic checkpoints cover the pin, allocation ledger, artifact lineage
and heads. A checkpoint prevents stale restoration only when its
`checkpoint:sha256:` digest is retained independently and supplied for an exact
fail-closed comparison; it is not a substitute for a production transparency
log or witness. Offline bundles do not contain the complete allocation ledger
or checkpoint and cannot serve as registry-recovery evidence.

## Trust is not a boolean

Implementations report independent states for parsing, deterministic encoding, schema, cryptographic signatures, anchor recognition, issuer authorization, lineage, revocation, freshness, and subject authentication.

## Manifest possession

Public `.idm` bytes are not a bearer credential. Inspection and record verification do not prove control of the subject. Activation and operation require a fresh, action-bound proof from an authorized subject or operation key in the runtime gate.

## AI boundary

AI models are untrusted proposers. They never hold root or unrestricted signing keys and cannot approve their own request. Natural-language manifest fields are data. A deterministic authorization broker outside the model validates typed requests, computes semantic changes, evaluates policy, obtains approvals, and invokes only scoped key operations.
