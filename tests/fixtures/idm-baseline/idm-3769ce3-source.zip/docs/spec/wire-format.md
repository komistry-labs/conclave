# IDM v1 Wire Format

**Status:** normative draft for implementation gate 1

## 1. Artifact

An `.idm` file is one RFC 8949 deterministic-CBOR item: a tagged COSE_Sign structure using CBOR tag 98.

```text
98([
  body_protected : bstr,
  body_unprotected : {},
  payload : bstr,
  signatures : [ + COSE_Signature ]
])

COSE_Signature = [
  sign_protected : bstr,
  sign_unprotected : {},
  signature : bstr
]
```

Both unprotected maps MUST be empty in v1. Security-relevant metadata MUST be protected.

## 2. Deterministic encoding profile

Encoders and verifiers MUST apply RFC 8949 core deterministic encoding requirements. This profile additionally requires:

- definite-length byte strings, text strings, arrays, and maps;
- shortest integer and length encodings;
- deterministic map ordering;
- valid UTF-8 text normalized to Unicode NFC;
- no floating-point values, tags inside the revision payload, undefined values, or duplicate map keys;
- normalized UTC timestamps formatted `YYYY-MM-DDTHH:MM:SSZ`;
- maximum artifact size of 1 MiB for v1;
- maximum eight signatures per artifact in the reference profile.

A verifier MUST decode and deterministically re-encode every protected map and the revision payload and reject byte inequality. Structural and semantic resource limits apply before activation.

## 3. Body protected headers

The protected body map uses the standard COSE content-type label and IDM text labels:

```text
{
  3: "application/idm+cbor",
  "idm_format": 1,
  "idm_context": "idm/v1/revision"
}
```

Unknown body headers are rejected in v1.

## 4. Signature protected headers

```text
{
  1: -8,                         / EdDSA /
  4: bstr,                       / KID lookup hint /
  "signer_eid": tstr,
  "signer_mid": tstr,
  "role": tstr,
  "scope": [ + tstr ],
  "signed_at": tstr,
  "policy_ref": tstr / null
}
```

The first implementation permits Ed25519 only. KID never establishes trust by itself.

Signature entries are sorted lexicographically by canonical `(signer_eid, role, kid)` bytes before the final container is encoded.

## 5. Signature input

Each signature uses the RFC 9052 COSE_Sign `Sig_structure`:

```text
[
  "Signature",
  body_protected,
  sign_protected,
  external_aad,
  payload
]
```

`external_aad` is an empty byte string in the file profile. Protocol adapters MAY define nonempty external AAD only in a later versioned profile.

## 6. Version identifier

After all required signatures are collected and sorted:

```text
VID = "vid:sha256:" + base64url_no_padding(SHA-256(exact_artifact_bytes))
```

VID is derived and is not stored inside the artifact it identifies. Adding, removing, or changing a signature changes VID.

## 7. Revision payload

The payload is a deterministic CBOR map conforming to `schemas/idm-v1.cddl`. Genesis has `revision = 1` and `predecessor_vid = null`. A successor keeps EID and MID stable, increments revision exactly once, and names one verified predecessor VID.

## 8. Failure behavior

Malformed, non-deterministic, unsupported, untrusted, unauthorized, revoked, stale, or conflicting inputs are distinct verification states. None may activate. Diagnostic inspection MUST NOT imply trust.
