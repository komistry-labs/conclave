# ADR 0002: Private Komistry Trust Domain for v1

- Status: accepted for implementation progression
- Date: 2026-07-22

## Decision

V1 initializes one private trust domain with an out-of-band pinned root key. Cross-domain federation, public ledgers, transfer, and global trust discovery remain non-goals.

The reference implementation starts with direct root issuance and adds scoped delegation only after the root artifact path is verified end to end.

## Consequences

- Offline verification is tractable.
- Registry contents do not create trust.
- Federation can be added only through an explicit later trust protocol.
