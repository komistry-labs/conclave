# ADR 0001: Deterministic CBOR and a Strict COSE_Sign Profile

- Status: accepted for implementation gate 1
- Date: 2026-07-22

## Decision

Encode each `.idm` as one deterministic CBOR item containing a tagged COSE_Sign structure. Use Ed25519 signatures and SHA-256 artifact identifiers. JSON is diagnostic only.

Implement the narrow COSE structures and signature input required by the IDM profile directly over maintained `cbor2` and `cryptography` libraries. Do not depend on the currently stale general-purpose `pycose` package. Do not implement cryptographic algorithms.

## Consequences

- The exact signed bytes are specified and testable.
- Multi-signature evidence is supported without a custom cryptographic primitive.
- The implementation must maintain RFC vectors and strict negative tests.
- Expanding algorithms or COSE structures requires a new reviewed profile.
