# ADR 0005: Stage B Allocation Ledger and Custody Controls

- Status: proposed implementation candidate pending exact Arthur approval
- Governing KOS decisions: ADR-0009 and ADR-0010
- Compatible ancestor: `1d7c73d56e91d49527e413576b9fae3c0f9799af`

## Context

The UUIDv7/K1 compatibility increment validates atomic caller-supplied
bindings, but Stage B allocation rehearsal additionally requires authoritative
sequence issuance, unique allocation events, trust-domain recovery boundaries,
KOS type enforcement and separated key custody.

## Decision

For the private KOS trust-domain profile:

1. Registry schema v4 pins the trust-domain ID and canonical root-anchor
   fingerprint.
2. One allocation RID is the primary key for exactly one
   UUIDv7/K1/EID/MID/authority/time/first-VID event.
3. A successful new allocation must carry exactly the current high-water mark
   plus one. Artifact admission, event insertion and high-water advancement
   commit or roll back together under `BEGIN IMMEDIATE`.
4. Caller-visible next-K1 values are hints. Concurrent stale candidates fail
   closed and must be rebuilt and re-signed.
5. KOS-bound artifacts use the closed ADR-0002 v1.0 type profile as extended
   by ADR-0009 to include `constitutional_charter`.
6. General issuance cannot allocate external identifiers. A dedicated key has
   only `identity.issue` and `identity.allocate` scopes.
7. Rehearsal authority initialization supports five distinct passphrases for
   root, issuance, allocation, revocation and registry duties.
8. Offline packages reject cross-lineage KOS value or allocation-RID reuse.
9. A deterministic registry checkpoint covers trust pin, allocation state,
   allocation events, admitted artifact lineage and heads.
10. `registry sync` is one all-or-nothing admission transaction. Checkpoint
    creation uses one consistent read snapshot, and recovery compares an
    independently retained `checkpoint:sha256:` value exactly.

## Boundaries

The compatibility path using one development passphrase remains available for
existing tests and non-governed development. It does not satisfy Stage B
custody. Physical offline root custody, independently retained checkpoint
digests and prohibition on AI access remain operational requirements.
Offline bundles are not allocation-ledger backups. The current trusted-time
store is rehearsal evidence only and is not a production authoritative-time
service.

The checkpoint is bounded rehearsal rollback evidence. Production still
requires independently witnessed signed checkpoints, supply-chain controls,
penetration testing, backup/recovery approval and the remaining gates in KOS
ADR-0009 and ADR-0010.
