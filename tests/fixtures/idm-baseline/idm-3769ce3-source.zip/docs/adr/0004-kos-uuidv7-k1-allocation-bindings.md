# ADR 0004: Atomic KOS UUIDv7 and K1 Allocation Bindings

- Status: accepted for implementation progression under KOS ADR-0010
- Date: 2026-08-04
- Governing KOS decision: ADR-0010 version 1.0

## Decision

Preserve IDM EID, MID, RID and VID formats and responsibilities. Represent KOS
identity through two external bindings:

- `kos-canonical-id` containing one canonical lowercase RFC 9562 UUIDv7 URN;
- `kos-allocation-number` containing one strict K1 unsigned 128-bit allocation
  number.

Both bindings must exist together and name the same allocation RID and
allocation-authority EID/MID. Registry admission remains transactional and
permanently rejects reuse of either value by another EID/MID lineage.

Successors preserve the complete KOS pair, EID and MID while advancing the
exact predecessor VID and deriving a new VID from the finalized signed bytes.

RID means a governed record identifier. An allocation RID does not substitute
for a relationship RID or any constitutional relationship object.

## Consequences

- KOS object identity remains independent from IDM identity and lineage.
- A partial or split UUIDv7/K1 claim is structurally invalid.
- Identifier syntax establishes no trust, approval, membership, or authority.
- Legacy illustrative `kos:<type>:<tail>` values no longer satisfy the KOS
  binding profile.
- A later allocation service must govern monotonic K1 issuance; registry
  admission proves signed binding and non-reuse, not chronological issuance.
