# ADR 0003: AI Models Are Outside the Trust Boundary

- Status: accepted for implementation progression
- Date: 2026-07-22

## Decision

An AI may propose a typed intent but cannot decide authorization, access authority keys, sign arbitrary bytes, grant itself capability, or approve a high-impact operation. Deterministic code validates, authorizes, signs, verifies, and audits all privileged actions.

## Consequences

- Prompt injection is contained by system boundaries rather than prompt filtering alone.
- Natural-language fields cannot become executable policy.
- Tool, key, network, and secret access require explicit capability-specific brokers.
