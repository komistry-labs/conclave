# Security Operations Guide

The reference implementation is not production-ready. Before real issuance, commission independent protocol, implementation, dependency, and operational reviews.

Provision the root fingerprint out of band. Keep the root vault offline and use it only for delegation, rotation, and recovery ceremonies. Place issuance, revocation, registry, recovery, and content-encryption keys in distinct hardware or administrative boundaries. The bundled encrypted-file vault is for development.

Human approvals should use phishing-resistant authenticators at key unlock. A quorum is independent only when credentials, devices, administrators, recovery paths, and vault backends are genuinely separate. Monitor signed events and protect checkpoints outside the same failure domain.

Distribute revocation snapshots frequently enough for the permitted risk. Treat loss of trusted-time state, a registry integrity failure, key exposure, fork detection, or unexpected delegation as an incident. Suspend activation, preserve evidence, revoke affected keys or identities with an independent revocation key, rotate through a governed ceremony, and rebuild indexes from signed artifacts.

Do not place legal names, contacts, recovery data, credentials, memory, or private relationships in public sections. Use separately encrypted sections or a purpose-built private store. Log identifiers and decisions, not plaintext secrets.
