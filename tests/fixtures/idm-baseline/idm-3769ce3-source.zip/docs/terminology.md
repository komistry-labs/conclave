# Terminology

- **EID:** stable identifier of one enduring entity.
- **MID:** stable identifier of that entity's governed manifest lineage.
- **RID:** stable opaque identifier of one governed record, event, or claim;
  the signed record class determines whether it is an allocation, relationship,
  delegation, revocation, grant, or another governed record.
- **VID:** SHA-256 identifier of one exact finalized signed artifact.
- **Identity Authority:** role permitted to issue identities under a named enrollment profile.
- **Founder / Originator:** immutable provenance, not automatic administrative power.
- **Steward:** entity authorized to govern specified semantic changes.
- **Operator:** entity or key authorized for specified runtime operations.
- **Custodian:** entity responsible for storage or decryption, without implicit semantic authority.
- **Runtime:** verifier and authorization broker that mounts a read-only identity context.
- **Registry:** rebuildable index of verified evidence; never the source of identity truth.
- **Vault:** protected private-key or section-key storage backend.
- **Explicit edge:** relationship written in an authoritative signed revision.
- **Derived inverse:** inverse view produced from one explicit edge.
- **Inferred path:** multi-edge or inverse-derived graph path; never presented as a new explicit claim.
