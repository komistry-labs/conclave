# Cryptographic Profile

- Deterministic CBOR follows RFC 8949 core deterministic encoding plus the restrictions in `docs/spec/wire-format.md`.
- Manifest revisions use RFC 9052 COSE_Sign tag 98 with Ed25519 (`alg = -8`).
- Delegation, revocation, offline bundles, runtime proofs, and events use strict COSE_Sign1 tag 18 profiles with domain-separated contexts.
- KID is SHA-256 of raw public-key bytes and is only a lookup hint. VID is SHA-256 of exact finalized artifact bytes.
- Protected sections use random 256-bit keys and AES-256-GCM with a 96-bit nonce. EID, MID, section name, and protocol context are authenticated associated data.
- The development vault uses scrypt (`N=32768, r=8, p=1`) and AES-256-GCM. It is an adapter demonstration, not an HSM.

All primitives come from `cryptography`; the project implements protocol composition, not cryptographic algorithms. Private keys never enter `.idm` artifacts.
