# CLI map

The `idm` executable is a reference administration and verification tool. Run `idm --help` or `idm <group> --help` for exact arguments.

| Area | Commands | Purpose |
|---|---|---|
| Trust | `authority init`, `key generate`, `key rotate` | Bootstrap a private trust domain and prepare development-vault keys |
| Identity | `create`, `issue`, `inspect`, `verify` | Draft, issue, diagnose, and verify manifests |
| Lifecycle | `suspend`, `resume`, `retire`, `archive` | Produce policy-governed successor revisions |
| Relationships | `relationship add`, `add-reference`, `remove`, `list` | Maintain signed direct edges and counterparty evidence |
| Capability | `capability declare`, `grant`, `revoke` | Separate claimed functionality from governed authorization |
| Evidence | `revoke`, `lineage show`, `lineage verify` | Create revocations and audit immutable lineages |
| Registry | `registry add`, `sync`, `verify` | Maintain and audit a verified local index |
| Graph | `graph parents`, `children`, `path`, `authority` | Resolve evidence-preserving identity paths |
| Runtime | `challenge issue`, `challenge sign`, `mount` | Prove subject-key control and mount current identity state |
| Offline | `offline pack`, `offline verify` | Distribute signed, expiring trust snapshots |
| Exchange | `export-json`, `import-json` | Use non-authoritative diagnostic JSON or strict unsigned drafts |

Secret-bearing commands use an interactive prompt by default. `--passphrase-file` exists for controlled automation; the file must be a private, regular, non-symlinked file. Output creation is exclusive and does not silently overwrite an existing artifact or key.

Every graph command requires `--trust`. Before resolving a path, the graph layer verifies the registry's derived indexes against the exact signed artifacts they claim to represent. Runtime `mount` uses runtime-owned trusted time and therefore has no caller-provided evaluation-time option.

Trust-sensitive operational commands accept repeatable `--revocation` evidence:
issuance and successor signing, revocation issuance, registry admission/audit,
graph resolution, lineage verification, and runtime mount. The evidence is
verified against the selected trust bundle and applied at trusted evaluation
time. Omitting it asserts that the operator's authoritative revocation set is
currently empty; it must not be used as a shortcut when revocation evidence is
known or expected.

`registry verify` reports structural `errors` separately from
`revoked_lineages`. A valid revocation does not make unrelated registry
evidence corrupt. Admission, graph queries, and runtime mount continue for
unaffected lineages while the affected lineage is rejected or excluded.

`key rotate` creates the replacement private-key material only. It does not silently install that key into an identity or trust bundle. Subject-key replacement uses the library's governed key-binding successor and requires the policy's independent Identity Authority and Steward approvals. Authority-key replacement requires a separate root-controlled delegation ceremony.
