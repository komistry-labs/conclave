# Golden interoperability vectors

The public vectors under `tests/fixtures/golden/` freeze complete signed `.idm` bytes, their exact-byte VID, signer public key, and expected identity fields. They contain no reusable production private key.

An implementation conforms to a vector only when it:

1. decodes the base64 artifact to the exact recorded byte length;
2. derives the recorded VID from those bytes;
3. accepts the deterministic CBOR and tagged COSE_Sign structure without normalization;
4. validates the Ed25519 signature using the recorded public key; and
5. recovers the recorded revision fields.

Changing any normative encoding rule requires a new versioned vector. Existing vector bytes must never be silently regenerated in place after release.
