# Relationship Model

Every relationship has one canonical source claim with RID, typed predicate, source and target EID/MID, validity interval, state, and constraints. The target can carry a compact reference to the authoritative RID and evidence VID. Governance-sensitive relationships are trusted by graph queries only when the target exists and its reference matches the exact authoritative VID and inverse local role.

Supported predicates include owns, founded, originated, belongs_to, governs, stewards, operates, custodies, issued_by, member_of, depends_on, hosts, authorized_by, supervises, and their defined inverses. Inverses are derived; they are not duplicated semantic claims. Governing `belongs_to` uses `has_member` as its inverse. Non-governing `member_of` uses the distinct inverse `has_affiliate`.

The registry retains the VID at which an unchanged edge was established, even when its source later receives unrelated revisions. A semantic edge change advances that evidence VID. Ownership and governance families are normalized to parent-to-child arcs for cycle detection.

`belongs_to` is a primary governance home and is limited to one active relationship per manifest. `member_of` is a non-governing affiliation. Reachability alone never creates authority: graph paths include evidence, trust state, length, and explicit/inverse markers.
