# Architecture

IDM v1 is a local-first identity control plane for one private trust domain. Its signed artifacts are authoritative; every database, graph, JSON export, cache, and mounted context is a derived view.

The implementation has four layers:

1. A deterministic CBOR revision inside a strict, tagged COSE_Sign envelope. EID and MID remain stable; VID hashes the exact finalized signed bytes.
2. A trust and policy layer. An out-of-band pinned root signs narrowly scoped operational-key delegations. Artifact signatures carry signer, role, scope, time, and policy metadata. Deterministic rules authorize concrete semantic change classes.
3. A rebuildable SQLite registry and relationship graph. Admission re-verifies trust, policy, lineage, rollback, forks, and hierarchy cycles. Graph results retain relationship ID and source evidence VID.
4. A fail-closed runtime. It audits registry evidence and revision policy, requires the greatest admitted lineage head, enforces lifecycle and revocation state, verifies a fresh runtime-issued challenge and bound subject-key proof, consumes replay state, and grants only effective capabilities.

External signed evidence covers delegation, revocation, offline snapshots, and hash-linked local events. AES-256-GCM protected sections bind ciphertext to EID, MID, and section name through associated data.

The Python modules intentionally point inward: models and canonical encoding have no storage policy; signature envelopes use audited library primitives; trust and policy feed verification; registry and runtime consume verified artifacts. No AI model, descriptive text, KID lookup hint, registry row, or possession of `.idm` bytes can authorize an operation.
