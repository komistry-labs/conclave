# Deferred Design Topics

V1 does not define federation between peer trust domains, public trust discovery, sale or legal ownership transfer, licensing, cloning, deployment replicas, institutional replication, public blockchain consensus, biometric proofing, a global registry, a GUI, or a cloud control plane.

Hardware-backed keys, WebAuthn ceremonies, HSM/KMS adapters, transparency-log witnesses, formal policy verification, legal human assurance profiles, recovery quorum ceremonies, and cross-domain conflict rules need separate specifications and threat reviews.

Extension fields reserve syntax; they do not authorize a deferred operation. Unknown semantics remain inert data and cannot change policy behavior.
