# Authority and Policy Model

Roles are independent duties, not a total privilege hierarchy. The built-in profile recognizes root authority, Identity Authority, Founder, Steward, Operator, Custodian, and registry authority roles through explicit action scopes.

The pinned root is used for bootstrap and `trust.delegate`. Routine issuance,
KOS allocation, revocation, and registry snapshots use separate encrypted
Ed25519 keys whose public keys, roles, scopes, and validity windows are
contained in root-signed COSE delegations. The KOS allocation key is limited to
`identity.issue` and `identity.allocate`; the general issuance key cannot
allocate an external identifier. Rehearsal initialization requires five
distinct role passphrases. The root key remains offline after delegation, and
AI processes never receive any private key or passphrase.

Revision policy classifies the actual difference from its verified predecessor. Relationships require both `relationship.manage` and a relationship-family scope: `relationship.ownership`, `relationship.provenance`, `relationship.governance`, `relationship.stewardship`, `relationship.supervision`, `relationship.affiliation`, `relationship.operations`, `relationship.custody`, `relationship.hosting`, `relationship.authorization`, or `relationship.dependency`. Capability declarations and grants use distinct scopes; lifecycle uses `lifecycle.change`; protected sections use `protected.write`. Identity-core, authority-policy, and key-binding changes require stronger policy rules. The reference profile models role-diverse approval but the convenience authority CLI deliberately cannot manufacture a missing independent Steward approval.

KOS canonical identifiers are external bindings, not IDM identity keys. The KOS
profile requires one `kos-canonical-id` UUIDv7 URN and one
`kos-allocation-number` K1 value. Both bindings name the same allocation RID
and allocating EID/MID, require an `identity.allocate` signature from that
authority, and are admitted atomically to the authority's persistent allocation
registry before the resulting artifact is released. The registry never
reallocates either scheme/value pair to another entity or lineage.

The registry pins its trust-domain ID and root fingerprint, records one unique
allocation event for each allocation RID, and admits only the next contiguous
K1 ordinal under a SQLite `BEGIN IMMEDIATE` transaction. A precomputed next
value is a non-authoritative hint: concurrent losers must rebuild and retry.
The KOS admission profile also rejects types outside ADR-0002 v1.0 as extended
by ADR-0009's `constitutional_charter` type.

Human MFA belongs at the signer or key-unlock boundary. Independent multi-party signatures govern high-impact changes. Signed journals provide tamper evidence. A blockchain is not part of the v1 trust boundary.
