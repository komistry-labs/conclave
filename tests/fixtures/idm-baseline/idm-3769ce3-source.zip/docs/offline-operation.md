# Offline Operation

An offline package is signed by a root-delegated registry key and contains a trust bundle, deterministic policy, complete included lineages, head map, revocation evidence, freshness limits, and exact artifact bytes. Verification still starts from separately pinned roots, requires the embedded policy to equal the locally pinned policy, checks registry-signer validity and revocation, and re-evaluates every included revision.

Packages have generated, verified-as-of, and hard-expiry times. A protected local checkpoint records the greatest signed time and sequence. Older time or sequence is rejected, and one sequence cannot silently identify a different bundle. Losing this local state weakens rollback assurance and must be treated as a recovery event.

Low- and medium-risk capabilities have policy-defined maximum snapshot ages. High-risk capabilities deny offline in the reference profile. Per-grant constraints such as `requires_online` still apply.

Offline actions can be recorded as subject-key-signed COSE events. Each event names its base VID and previous evidence ID. Synchronization reports an explicit conflict if the registry head advanced; it never overwrites the newer lineage.
