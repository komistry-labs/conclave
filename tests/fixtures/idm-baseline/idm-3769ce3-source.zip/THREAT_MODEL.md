# IDM v1 Threat Model

## Status

This is a living threat model for the reference implementation. It defines design requirements; passing tests is necessary but not sufficient evidence of production security.

## Protected assets

- enduring EID and MID bindings;
- exact revision bytes and lineage;
- trust anchors and delegated authority;
- private signing, encryption, recovery, and revocation keys;
- relationship and capability authorization;
- protected identity sections;
- registry, transparency, revocation, and offline evidence;
- deterministic policy and runtime decisions.

## Adversaries

- an unauthenticated author of malformed or fabricated artifacts;
- an entity with a valid but unauthorized signing key;
- a malicious or compromised Steward, Operator, Custodian, or issuer;
- an attacker who copies a genuine public manifest;
- a registry or cache operator who omits, rewrites, reorders, or replays evidence;
- an attacker controlling stale offline data or the local clock;
- a compromised dependency, build environment, AI model, peer agent, document, or tool response;
- an attacker with local filesystem or process access;
- colluding actors who control fewer than the required independent approvals.

## Trust assumptions

- At least one configured root trust anchor was provisioned out of band correctly.
- Required approval keys are independently controlled where policy claims signer diversity.
- Cryptographic libraries and the host random-number generator operate correctly.
- The host can enforce the claimed key-vault and process-isolation boundary.
- Offline verification cannot know about revocations newer than its signed snapshot.

## Primary threats and controls

| Threat | Required controls |
|---|---|
| Fabricated identity | Anchored issuer trust, issuance scope, enrollment profile, registry admission |
| Tampered artifact | Deterministic CBOR, exact-byte VID, Ed25519 signatures |
| Copied genuine artifact | Fresh action-bound proof of possession |
| Unauthorized signer | Key purpose, role, field/action scope, delegation, validity, revocation |
| Duplicate or conflicting identity | Authority-allocated IDs, uniqueness constraints, quarantine, transparency monitoring |
| Relationship spoofing | Canonical source edge, typed relationship-family authorization, scoped counterparty reference |
| Rollback, replay, or fork | Predecessor chain, trusted heads, nonce/session binding, explicit fork state |
| Registry poisoning | Audit before admission or graph use, exact reconstruction of derived rows from signed artifacts, evidence-linked results |
| Key theft | Separation, encrypted/non-exportable storage, MFA, quorum, rotation, revocation |
| Prompt injection or AI hijacking | Untrusted-model boundary, typed broker, deterministic policy, key/tool isolation |
| Ciphertext substitution | AEAD with EID/MID/section-path associated data |
| Parser exhaustion | Artifact, depth, collection, integer, and text limits; fuzzing |
| Supply-chain compromise | Minimal pinned dependencies, provenance, reproducible build, review |

## Residual risks

The protocol cannot guarantee the truth of bad enrollment evidence, detect a malicious action signed by a fully compromised required quorum before external evidence appears, know online revocations while completely offline, or remain secure after compromise of the root and recovery boundary. On Windows, the development vault depends on the containing directory's inherited ACL because the reference implementation does not yet perform a full discretionary-ACL audit equivalent to its POSIX ownership and mode checks. Those risks require operational controls, monitoring, response, and recovery.
